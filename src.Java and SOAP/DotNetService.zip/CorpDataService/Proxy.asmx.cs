using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace CorpDataService
{
	[WebService(Namespace="http://mindstrm.com/CorpDataService")]
	[SoapRpcService()]
	public class Proxy : System.Web.Services.WebService
	{
		public Proxy()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}
		#endregion

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
		}

		[WebMethod(Description="This method is used to retrieve stock quotes for a company, based on its stock symbol.")]
		public com.mindstrm.Quote getQuote(string symbol)
		{
			com.mindstrm.CorpDataService s = new com.mindstrm.CorpDataService();
			return s.getQuote(symbol);
		}

		[WebMethod(Description="This method is used to retrieve recent Headlines for News stories related to a company, based on its stock symbol.")]
		public string[] getHeadlines(string symbol)
		{
			com.mindstrm.CorpDataService s = new com.mindstrm.CorpDataService();
			return s.getHeadlines(symbol);
		}

	}
}
