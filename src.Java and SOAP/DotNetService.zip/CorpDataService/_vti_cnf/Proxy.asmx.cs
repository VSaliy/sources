vti_encoding:SR|utf8-nl
vti_author:SR|MINDSTREAM\\rob
vti_modifiedby:SR|MINDSTREAM\\rob
vti_timecreated:TR|05 Dec 2001 17:58:49 -0000
vti_timelastmodified:TR|27 Dec 2001 15:31:43 -0000
vti_backlinkinfo:VX|
vti_extenderversion:SR|4.0.2.3228
vti_nexttolasttimemodified:TR|07 Dec 2001 17:49:39 -0000
