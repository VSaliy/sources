vti_encoding:SR|utf8-nl
vti_author:SR|MINDSTREAM\\rob
vti_modifiedby:SR|MINDSTREAM\\rob
vti_timecreated:TR|05 Dec 2001 16:40:27 -0000
vti_timelastmodified:TR|05 Dec 2001 16:40:27 -0000
vti_backlinkinfo:VX|
