vti_encoding:SR|utf8-nl
vti_author:SR|MINDSTREAM\\rob
vti_modifiedby:SR|MINDSTREAM\\rob
vti_timecreated:TR|05 Dec 2001 16:40:28 -0000
vti_timelastmodified:TR|07 Dec 2001 17:25:59 -0000
vti_backlinkinfo:VX|
vti_extenderversion:SR|4.0.2.3228
vti_nexttolasttimemodified:TR|05 Dec 2001 16:40:28 -0000
