package javasoap.book.ch6;
public interface IAnotherFeedService {
  java.util.Hashtable sendMessage(java.util.Hashtable msg);
}
