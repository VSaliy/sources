package javasoap.book.ch5;
public class BasicTradingService {
   
   public BasicTradingService() {}

   public int getTotalVolume(String[] stocks) {
      
      // get the volumes for each stock from some
      // data feed and return the total
      int total = 345000; 
      return total;
   }
}
