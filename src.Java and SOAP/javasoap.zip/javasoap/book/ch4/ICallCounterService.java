package javasoap.book.ch4;
public interface ICallCounterService {
  int getCount();
  boolean doSomething();
}
