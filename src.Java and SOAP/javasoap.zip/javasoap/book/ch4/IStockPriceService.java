package javasoap.book.ch4;
public interface IStockPriceService {
  float getPrice(String stock, String currency);
}
