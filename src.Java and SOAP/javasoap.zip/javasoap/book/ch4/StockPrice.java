package javasoap.book.ch4;
public class StockPrice {
   public float getPrice(String stock, String currency) {
      float result;
      // determine the price for stock and return it
      // in the specified currency
      result = (float)75.33;
      return result;
   }
}
