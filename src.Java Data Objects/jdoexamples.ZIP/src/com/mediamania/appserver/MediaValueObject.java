package com.mediamania.appserver;

import java.io.Serializable;

public class MediaValueObject implements Serializable {
    public String title;
}