package com.mediamania.appserver;

public class RentalValueObject extends MediaValueObject {
     public String serialNumber;
}