package com.mediamania.appserver;

public class PurchaseValueObject extends MediaValueObject {
    public String format;
}