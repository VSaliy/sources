/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packt.ch06.jms;

import javax.ejb.Local;

/**
 *
 * @author Administrator
 */
@Local
public interface JmsImprovementLocal {
    
}
