/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packt.ch06;

/**
 *
 * @author Administrator
 */
public interface IMyEJB {
    public String getHelloWorld();
}
