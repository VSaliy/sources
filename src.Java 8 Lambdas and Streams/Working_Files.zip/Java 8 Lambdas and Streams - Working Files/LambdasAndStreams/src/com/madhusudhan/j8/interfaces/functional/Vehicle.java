package com.madhusudhan.j8.interfaces.functional;

public class Vehicle {

}
