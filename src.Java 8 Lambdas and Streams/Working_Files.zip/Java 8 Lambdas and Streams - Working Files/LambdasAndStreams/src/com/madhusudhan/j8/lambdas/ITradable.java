package com.madhusudhan.j8.lambdas;


public interface ITradable<T> {

	boolean check(T t);
}
