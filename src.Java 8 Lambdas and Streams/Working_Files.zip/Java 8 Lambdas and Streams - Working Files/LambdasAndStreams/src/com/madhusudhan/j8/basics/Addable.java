package com.madhusudhan.j8.basics;

/**
 *  Interface to operate on given strings 
 **/
public interface Addable {
	 public String operate(String s1, String s2);
}
