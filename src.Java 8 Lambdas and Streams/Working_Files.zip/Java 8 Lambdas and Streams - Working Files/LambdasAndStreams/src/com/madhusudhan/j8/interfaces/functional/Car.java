package com.madhusudhan.j8.interfaces.functional;

public class Car {

	public Car(int id) {
		// TODO Auto-generated constructor stub
	}

}
