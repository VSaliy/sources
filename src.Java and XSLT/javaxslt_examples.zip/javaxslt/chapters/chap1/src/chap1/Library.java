package chap1;

import java.util.*;

/**
 * A helper class used by LibraryDOMCreator and LibraryJDOMCreator,
 * presented as Examples 1-4 and 1-5 in Chapter 1.
 *
 * @author Eric M. Burke
 */
public class Library {
    private List publishers = new ArrayList();
    private List books = new ArrayList();

    public List getPublishers() {
        return this.publishers;
    }

    public List getBooks() {
        return this.books;
    }


    /**
     * Construct a new instance of the library.  This is a hard-coded
     * example. In a real app, the books and publishers would come
     * from a database.
     */
    public Library() {
        Publisher oreilly = new Publisher("oreilly", "O'Reilly",
                "101 Morris Street", "Sebastopol", "CA", "95472");
        this.publishers.add(oreilly);

        this.books.add(new Book(oreilly, "XML Pocket Reference", 1,
                "Robert Eckstein", "1-56592-709-5", 10, 1999));
        this.books.add(new Book(oreilly, "Java and XML", 1,
                "Brett McLaughlin", "0-596-00016-2", 6, 2000));
    }
}
