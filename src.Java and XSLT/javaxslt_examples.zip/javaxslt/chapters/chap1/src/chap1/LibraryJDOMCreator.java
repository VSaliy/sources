package chap1;

import java.io.*;
import java.util.*;
import org.jdom.DocType;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;

/**
 * An example from Chapter 1. Creates the library XML file using JDOM.
 */
public class LibraryJDOMCreator {

    public Document createDocument(Library library) {
        Element root = new Element("library");
        // JDOM supports the <!DOCTYPE...>
        DocType dt = new DocType("library", "library.dtd");
        Document doc = new Document(root, dt);

        // add <publisher> children to the <library> element
        Iterator publisherIter = library.getPublishers().iterator();
        while (publisherIter.hasNext()) {
            Publisher pub = (Publisher) publisherIter.next();
            Element pubElem = createPublisherElement(pub);
            root.addContent(pubElem);
        }

        // now add <book> children to the <library> element
        Iterator bookIter = library.getBooks().iterator();
        while (bookIter.hasNext()) {
            Book book = (Book) bookIter.next();
            Element bookElem = createBookElement(book);
            root.addContent(bookElem);
        }

        return doc;
    }

    private Element createPublisherElement(Publisher pub) {
        Element pubElem = new Element("publisher");

        pubElem.addAttribute("id", pub.getId());
        pubElem.addContent(new Element("name").setText(pub.getName()));
        pubElem.addContent(new Element("street").setText(pub.getStreet()));
        pubElem.addContent(new Element("city").setText(pub.getCity()));
        pubElem.addContent(new Element("state").setText(pub.getState()));
        pubElem.addContent(new Element("postal").setText(pub.getPostal()));

        return pubElem;
    }

    private Element createBookElement(Book book) {
        Element bookElem = new Element("book");

        // add publisher="oreilly" and isbn="1234567" attributes
        // to the <book> element
        bookElem.addAttribute("publisher", book.getPublisher().getId())
                .addAttribute("isbn", book.getISBN());

        // now add an <edition> element to <book>
        bookElem.addContent(new Element("edition").setText(
                Integer.toString(book.getEdition())));

        Element pubDate = new Element("publicationDate");
        pubDate.addAttribute("mm",
                Integer.toString(book.getPublicationMonth()));
        pubDate.addAttribute("yy",
                Integer.toString(book.getPublicationYear()));
        bookElem.addContent(pubDate);

        bookElem.addContent(new Element("title").setText(book.getTitle()));
        bookElem.addContent(new Element("author").setText(book.getAuthor()));

        return bookElem;
    }

    public static void main(String[] args) throws IOException {
        Library lib = new Library();
        LibraryJDOMCreator ljc = new LibraryJDOMCreator();
        Document doc = ljc.createDocument(lib);

        // Write the XML to System.out, indent two spaces, include
        // newlines after each element
        new XMLOutputter("  ", true, "UTF-8").output(doc, System.out);
    }
}

