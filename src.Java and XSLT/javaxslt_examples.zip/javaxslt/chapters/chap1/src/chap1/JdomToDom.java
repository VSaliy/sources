package chap1;

/**
 * A small portion of this code is presented in Chapter 1. Demonstrates
 * how to convert JDOM to DOM using DOMOutputter.
 *
 * @author Eric M. Burke
 */
public class JdomToDom {
    public static void main(String[] args) throws Exception {
        LibraryJDOMCreator ljc = new LibraryJDOMCreator();
        Library lib = new Library();

        // create a JDOM Document
        org.jdom.Document jdomDoc = ljc.createDocument(lib);

        // convert the JDOM Document to a DOM Document
        org.jdom.output.DOMOutputter outputter =
                new org.jdom.output.DOMOutputter();
        org.w3c.dom.Document domDoc = outputter.output(jdomDoc);

        /* NOTE: this is commented out because Xerces is not included
                 in the downloads for this book.
        // write the document using Apache Xerces
        // output the document with UTF-8 encoding; indent each line
        org.apache.xml.serialize.OutputFormat fmt =
            new org.apache.xml.serialize.OutputFormat(domDoc, "UTF-8", true);
        org.apache.xml.serialize.XMLSerializer serial =
            new org.apache.xml.serialize.XMLSerializer(System.out, fmt);
        serial.serialize(domDoc.getDocumentElement());
        */

        try {
            System.out.println(
                com.oreilly.javaxslt.util.DOMUtil.domToString(domDoc));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
