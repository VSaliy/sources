package chap1;

/**
 * A helper class used by LibraryDOMCreator and LibraryJDOMCreator,
 * presented as Examples 1-4 and 1-5 in Chapter 1.
 *
 * @author Eric M. Burke
 */
public class Book {
    private Publisher publisher;
    private String title;
    private int edition;
    private String author;
    private String isbn;
    private int publicationMonth;
    private int publicationYear;

    public Book(Publisher publisher, String title, int edition,
            String author, String isbn, int publicationMonth,
            int publicationYear) {
        this.publisher = publisher;
        this.title = title;
        this.edition = edition;
        this.author = author;
        this.isbn = isbn;
        this.publicationMonth = publicationMonth;
        this.publicationYear = publicationYear;
    }

    public Publisher getPublisher() {
        return this.publisher;
    }

    public String getTitle() {
        return this.title;
    }

    public int getEdition() {
        return this.edition;
    }

    public String getAuthor() {
        return this.author;
    }

    public String getISBN() {
        return this.isbn;
    }

    public int getPublicationYear() {
        return this.publicationYear;
    }

    public int getPublicationMonth() {
        return this.publicationMonth;
    }
}
