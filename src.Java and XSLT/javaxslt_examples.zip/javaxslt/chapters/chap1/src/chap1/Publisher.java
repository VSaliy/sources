package chap1;

/**
 * A helper class used by LibraryDOMCreator and LibraryJDOMCreator,
 * presented as Examples 1-4 and 1-5 in Chapter 1.
 *
 * @author Eric M. Burke
 */
public class Publisher {
    private String id;
    private String name;
    private String street;
    private String city;
    private String state;
    private String postal;

    public Publisher(String id, String name, String street,
            String city, String state, String postal) {
        this.id = id;
        this.name = name;
        this.street = street;
        this.city = city;
        this.state = state;
        this.postal = postal;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getStreet() {
        return this.street;
    }

    public String getCity() {
        return this.city;
    }

    public String getState() {
        return this.state;
    }

    public String getPostal() {
        return this.postal;
    }
}

