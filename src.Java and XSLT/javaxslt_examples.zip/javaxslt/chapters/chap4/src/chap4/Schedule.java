package chap4;

import java.util.*;

public class Schedule {
    private static Schedule instance = new Schedule();

    // fake data for example purpose only
    static String[] titles = new String[] {
        "Local News", "Paid Programming", "National News", "Music Videos",
        "Home Improvement 101", "Auto Racing", "Olympic Coverage",
        "Football", "Basketball", "Hockey", "Baseball", "Entertainment News",
        "Bass Fishing", "Travel Highlights", "News of the Weird",
        "Bowling", "Golfing", "International News", "Weather",
        "Local Access", "Stand up Comedy", "Movie Reviews", "Soap Opera",
        "Game Show", "Tennis", "Computer Tips", "Advanced Computing"
    };


    public static Schedule getInstance() {
        return instance;
    }

    public static void main(String[] args) {
        Show[] shows = Schedule.getInstance().getTodaysShows();
        for (int i=0; i<shows.length; i++) {
            System.out.println(shows[i]);
        }
    }

    public Show[] getTodaysShows() {
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 6);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        int duration = 30;

        List shows = new ArrayList();
        Random rand = new Random();

        Calendar startTime = Calendar.getInstance();
        Calendar endTime = Calendar.getInstance();

        // make up some random shows
        for (int channel=2; channel<6; channel++) {
            startTime.setTime(today.getTime());
            endTime.setTime(today.getTime());

            do {
                duration = (1 + rand.nextInt(4)) * 30;
                endTime.add(Calendar.MINUTE, duration);

                String curTitle = titles[rand.nextInt(titles.length)];

                shows.add(new Show(curTitle, channel,
                        startTime.getTime(), endTime.getTime()));
                startTime.setTime(endTime.getTime());
            } while (endTime.get(Calendar.DATE) == today.get(Calendar.DATE));
        }

        Collections.sort(shows);
        return (Show[]) shows.toArray(new Show[0]);
    }

    private Schedule() {
    }
}