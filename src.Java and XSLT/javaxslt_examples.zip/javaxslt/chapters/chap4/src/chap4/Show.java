package chap4;

import java.text.SimpleDateFormat;
import java.util.*;

public class Show implements Comparable {

    private String title;
    private int channel;
    private Date startTime;
    private Date endTime;

    public Show(String title, int channel, Date startTime, Date endTime) {
        this.title = title;
        this.channel = channel;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public String getTitle() {
        return this.title;
    }

    public int getChannel() {
        return this.channel;
    }

    public Date getStartTime() {
        return this.startTime;
    }

    public Date getEndTime() {
        return this.endTime;
    }

    public int compareTo(Object obj) {
        Show rhs = (Show) obj;
        int comparison = this.startTime.compareTo(rhs.startTime);
        if (comparison == 0) {
            if (this.channel < rhs.channel) {
                comparison = -1;
            } else if (this.channel > rhs.channel) {
                comparison = 1;
            }
        }
        return comparison;
    }

    public boolean equals(Object obj) {
        if (obj instanceof Show) {
            Show rhs = (Show) obj;
            return this.startTime.equals(rhs.startTime)
                    && this.channel == rhs.channel;
        }
        return false;
    }

    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
        return "Channel " + this.channel
                + " from "
                + sdf.format(this.startTime) + " to "
                + sdf.format(this.endTime)
                + ": " + this.title;
    }
}