package chap4;

import java.io.*;
import java.text.SimpleDateFormat;
import javax.servlet.*;
import javax.servlet.http.*;

public class ScheduleServlet extends HttpServlet {
    public void doGet(HttpServletRequest request,
            HttpServletResponse response) throws IOException,
            ServletException {

        SimpleDateFormat dateFmt = new SimpleDateFormat("hh:mm a");

        Show[] shows = Schedule.getInstance().getTodaysShows();

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        pw.println("<html><head><title>Today's Shows</title></head><body>");
        pw.println("<h1>Today's Shows</h1>");
        pw.println("<table border=\"1\" cellpadding=\"3\"");
        pw.println(" cellspacing=\"0\">");

        pw.println("<tr><th>Channel</th><th>From</th>");
        pw.println("<th>To</th><th>Title</th></tr>");

        for (int i=0; i<shows.length; i++) {
            pw.println("<tr>");
            pw.print("<td>");
            pw.print(shows[i].getChannel());
            pw.println("</td>");
            pw.print("<td>");
            pw.print(dateFmt.format(shows[i].getStartTime()));
            pw.println("</td>");
            pw.print("<td>");
            pw.print(dateFmt.format(shows[i].getEndTime()));
            pw.println("</td>");
            pw.print("<td>");
            pw.print(shows[i].getTitle());
            pw.println("</td>");
            pw.println("</tr>");
        }
        pw.println("</table>");
        pw.println("</body>");
        pw.println("</html>");
    }
}