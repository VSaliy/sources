package chap5;

import java.io.*;

import javax.xml.transform.OutputKeys;

/**
 * Pass a parameter to a stylesheet using JAXP 1.1.
 */
public class JaxpParameter {

    public static void main(String[] args)
            throws javax.xml.transform.TransformerException {

        File xmlFile = new File("stylesheetParameter.xml");
        File xsltFile = new File("stylesheetParameter.xslt");

        javax.xml.transform.Source xmlSource =
                new javax.xml.transform.stream.StreamSource(xmlFile);
        javax.xml.transform.Source xsltSource =
                new javax.xml.transform.stream.StreamSource(xsltFile);
        javax.xml.transform.Result result =
                new javax.xml.transform.stream.StreamResult(System.out);

        // create an instance of TransformerFactory
        javax.xml.transform.TransformerFactory transFact =
                javax.xml.transform.TransformerFactory.newInstance();

        javax.xml.transform.Transformer trans =
                transFact.newTransformer(xsltSource);

        // set the parameter
        trans.setParameter("image_dir", "images2");
        trans.setOutputProperty(OutputKeys.METHOD, "xml");
        trans.setOutputProperty(OutputKeys.STANDALONE, "no");
        trans.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "my.dtd");
        trans.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "their.dtd");


        trans.transform(xmlSource, result);
    }
}

