package chap5;

import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;

/**
 * A simple demo of JAXP 1.1 StreamSource and StreamResult. This 
 * program downloads the XML specification from the W3C and prints
 * it to a temporary file.
 */
public class Streams {

    // an identity copy stylesheet
    private static final String IDENTITY_XSLT =
        "<xsl:stylesheet xmlns:xsl='http://www.w3.org/1999/XSL/Transform'"
        + " version='1.0'>"
        + "<xsl:template match='/'><xsl:copy-of select='.'/>"
        + "</xsl:template></xsl:stylesheet>";

    // the XML spec in XML format
    private static String xmlSystemId =
            "http://www.w3.org/TR/2000/REC-xml-20001006.xml";


    public static void main(String[] args) throws IOException,
            TransformerException {

        // show how to read from a system identifier and a Reader
        Source xmlSource = new StreamSource(xmlSystemId);
        Source xsltSource = new StreamSource(
                new StringReader(IDENTITY_XSLT));

        // send the result to a file
        File resultFile = File.createTempFile("Streams", ".xml");
        Result result = new StreamResult(resultFile);

        System.out.println("Results will go to: "
                + resultFile.getAbsolutePath());

        // get the factory
        TransformerFactory transFact = TransformerFactory.newInstance();

        // get a transformer for this particular stylesheet
        Transformer trans = transFact.newTransformer(xsltSource);

        // the next line will also perform an identity copy
//        Transformer trans = transFact.newTransformer();

        // do the transformation
        trans.transform(xmlSource, result);
    }
}
