package chap6;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * A simple Servlet example that displays a "Splash Screen"
 * for a web application.
 */
public class SplashScreenServlet extends HttpServlet {
  public String getServletInfo() {
    return "Shows an application splash screen.";
  }

  protected void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws IOException, ServletException {

    // demonstrate how to get parameters from the request
    String nextURL = request.getParameter("nextURL");
    if (nextURL == null) {
      nextURL = "/";
    }

    response.setContentType("text/html");
    PrintWriter pw = response.getWriter();
    pw.println("<html>");
    pw.println("<head><title>Splash Screen</title></head>");
    pw.println("<body>");

    pw.println("<div align='center' style='border: 1px navy solid;'>");
    pw.println("<h1>Welcome to Java and XSLT</h1>");
    pw.println("<h3>O'Reilly and Associates</h3>");
    pw.println("<p>First Edition, 2001</p><hr>");
    pw.println("<a href='" + nextURL + "'>Click here to continue...</a>");
    pw.println("</div>");
    pw.println("</body>");
    pw.println("</html>");
  }
}
