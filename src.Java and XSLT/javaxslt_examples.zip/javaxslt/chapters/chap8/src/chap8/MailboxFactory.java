package chap8;

import java.util.*;

/**
 * Produces Mailboxes from some back-end database.
 */
public class MailboxFactory {

    /**
     * Get a mailbox for a particular user.
     */
    public static Mailbox getMailbox(String username) {

        // this implementation is completely fake. It could be swapped
        // out with an EJB implementation, for example
        Map folders = new HashMap();

        // build new folders
        List messages = new ArrayList();
        messages.add(new MessageHeader(
                0, "dexter@yahoo.com", "burke_e@ociweb.com",
                "[no subject]",
                createDate(2001, Calendar.JANUARY, 1, 8, 0, 23)));
        messages.add(new MessageHeader(
                1, "spammer@hidden.net", "burke_e@yahoo.com",
                "Get rich quick!",
                createDate(2001, Calendar.JANUARY, 3, 8, 16, 45)));
        messages.add(new MessageHeader(
                2, "a3947k@hotmail.com", "burke_e@yahoo.com",
                "Here's an offer you can't refuse",
                createDate(2001, Calendar.JANUARY, 4, 6, 32, 25)));
        messages.add(new MessageHeader(
                3, "sally123@mindspring.com", "burke_e@ociweb.com",
                "A friend referred you to me",
                createDate(2001, Calendar.JANUARY, 6, 12, 20, 14)));
        messages.add(new MessageHeader(
                4, "joe001", "burke_e@ociweb.com",
                "Did you hear about this?",
                createDate(2001, Calendar.JANUARY, 9, 3, 45, 20)));
        messages.add(new MessageHeader(
                5, "jill0393@mindspring.com", "burke_e@ociweb.com",
                "Let me tell you about this",
                createDate(2001, Calendar.FEBRUARY, 2, 3, 10, 57)));
        messages.add(new MessageHeader(
                6, "autoreply@nospam.com", "burke_e@ociweb.com",
                "How's it going?",
                createDate(2001, Calendar.FEBRUARY, 3, 5, 45, 20)));

        folders.put(Mailbox.INBOX, new MailFolder(Mailbox.INBOX, messages));


        // create another dummy folder
        messages = new ArrayList();
        messages.add(new MessageHeader(
                7, "jen@yahoo.com", "burke_e@ociweb.com",
                "How's it going?",
                createDate(2001, Calendar.FEBRUARY, 3, 5, 45, 20)));
        folders.put("Personal", new MailFolder("Personal", messages));

        return new Mailbox(username, folders);
    }

    // prevent instantiation of this class
    private MailboxFactory() {
    }

    // a simple helper method to create fake dates
    private static Date createDate(int year, int month, int date,
            int hour, int minute, int second) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, date, hour, minute, second);
        return cal.getTime();
    }
}

