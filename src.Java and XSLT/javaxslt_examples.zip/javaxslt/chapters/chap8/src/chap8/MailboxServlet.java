package chap8;

import com.oreilly.javaxslt.util.StylesheetCache;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

/**
 * Demonstrates how to perform session tracking without cookies.
 */
public class MailboxServlet extends HttpServlet {
    private String xsltFileName;

    /**
     * Locate the XSLT stylesheet.
     */
    public void init() throws UnavailableException {
        this.xsltFileName = getServletContext().getRealPath(
                "/WEB-INF/xslt/mailbox.xslt");
        if (!new File(this.xsltFileName).exists()) {
            throw new UnavailableException("XSLT stylesheet not found: "
                    + this.xsltFileName, 30);
        }
    }

    /**
     * Display the mailbox.
     */
    public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        try {
            // retrieve current settings from the session
            HttpSession session = req.getSession(true);
            Mailbox mbox = (Mailbox) session.getAttribute("mailbox");
            String curFolderName =
                    (String) session.getAttribute("curFolderName");
            String curSortColumn =
                    (String) session.getAttribute("curSortColumn");

            // produce the DOM tree
            Document doc = MailboxDOMProducer.createMailboxDocument(
                    mbox, curFolderName);

            // prepare the XSLT transformation
            Transformer trans = StylesheetCache.newTransformer(
                    this.xsltFileName);

            // tell the XSLT what column to sort on
            if (curSortColumn != null) {
                trans.setParameter("global.curSortColumn", curSortColumn);
            }

            // allow cookieless session tracking
            if (!req.isRequestedSessionIdFromCookie()) {
                String sessionID = session.getId();
                trans.setParameter("global.sessionID", 
                        ";jsessionid=" + sessionID);
            }

            // send the web page back to the user
            res.setContentType("text/html");
            trans.transform(new javax.xml.transform.dom.DOMSource(doc),
                    new StreamResult(res.getWriter()));

        } catch (ParserConfigurationException pce) {
            throw new ServletException(pce);
        } catch (TransformerConfigurationException tce) {
            throw new ServletException(tce);
        } catch (TransformerException te) {
            throw new ServletException(te);
        }
    }


    /**
     * Allow users to POST changes to mailbox settings.
     */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // locate the session for the current user
        HttpSession session = req.getSession(true);

        // if the client changed the current folder, store the new
        // value in the session
        String curFolderName = req.getParameter("changeCurrentFolder");
        if (curFolderName != null) {
            session.setAttribute("curFolderName", curFolderName);
        }

        // if the client changed the sort column, store the new value
        // in the session. The parameter naming convention
        // is: "sortOn[column]". For example, "sortOnfrom" or "sortOnto".
        Enumeration paramNames = req.getParameterNames();
        while (paramNames.hasMoreElements()) {
            String curName = (String) paramNames.nextElement();
            if (curName.startsWith("sortOn")) {
                session.setAttribute("curSortColumn",
                        curName.substring("sortOn".length()));
                break;
            }
        }

        // see if the user submitted a new username
        String username = req.getParameter("username");
        if (username != null) {
            // store the new mailbox in the session
            Mailbox mbox = MailboxFactory.getMailbox(username);
            session.setAttribute("mailbox", mbox);
        }

        // utilize the doGet method to show the page
        doGet(req, res);
    }
}
