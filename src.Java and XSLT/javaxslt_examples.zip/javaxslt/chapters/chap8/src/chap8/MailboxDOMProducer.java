package chap8;

import java.util.Iterator;
import java.text.SimpleDateFormat;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/**
 * Converts a Mailbox into a DOM tree.
 */
public class MailboxDOMProducer {
    // controls how dates are formatted
    private static SimpleDateFormat sdFmt = new SimpleDateFormat(
            "MMM dd, yyyy HH:mm:ss a");

    /**
     * A simple unit test that produces XML for a Mailbox to System.out.
     */
    public static void main(String[] args) throws Exception {
        Mailbox mbox = MailboxFactory.getMailbox("burke_e");
        Document doc = createMailboxDocument(mbox, Mailbox.INBOX);

        System.out.println(
                com.oreilly.javaxslt.util.DOMUtil.domToString(doc));
    }

    /**
     * @param mailbox the Mailbox to produce DOM for.
     * @param curFolderName the currently selected folder.
     * @return DOM for a Mailbox object.
     */
    public static Document createMailboxDocument(Mailbox mailbox,
            String curFolderName) throws ParserConfigurationException {
        // use JAXP to create a DOM Document
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.newDocument();

        // the root element is <mailbox>
        Element mailboxElem = doc.createElement("mailbox");
        doc.appendChild(mailboxElem);

        // <mailbox> contains <username>
        Element usernameElem = doc.createElement("username");
        mailboxElem.appendChild(usernameElem);

        // the mailbox may be null. In this case, we are done.
        if (mailbox != null) {
            usernameElem.appendChild(doc.createTextNode(mailbox.getUsername()));

            // create the following:
            // <folders>
            //   <name>A Folder Name</name>
            //   <name>Another Folder Name</name>
            // </folder>
            Element foldersElem = doc.createElement("folders");
            mailboxElem.appendChild(foldersElem);
            Iterator folderNames = mailbox.getFolderNames();
            while (folderNames.hasNext()) {
                String curName = (String) folderNames.next();
                Element curFolderElem = doc.createElement("name");
                curFolderElem.appendChild(doc.createTextNode(curName));
                foldersElem.appendChild(curFolderElem);
            }

            // pick a default folder if the current folder name is invalid
            if (!mailbox.containsFolder(curFolderName)) {
                curFolderName = Mailbox.INBOX;
            }

            // create the following:
            //  <folder>
            //     <name>Folder Name</name>
            //     ...zero or more <messageHeader> elements
            //  </folder>
            Element folderElem = doc.createElement("folder");
            mailboxElem.appendChild(folderElem);

            Element nameElem = doc.createElement("name");
            nameElem.appendChild(doc.createTextNode(curFolderName));
            folderElem.appendChild(nameElem);

            // add all of the <messageHeader> elements to the <folder>
            MailFolder curFolder = mailbox.getFolder(curFolderName);
            Iterator iter = curFolder.getMessages();
            while (iter.hasNext()) {
                MessageHeader curHeader = (MessageHeader) iter.next();
                folderElem.appendChild(createMessageHeaderElement(
                        doc, curHeader));
            }
        }

        return doc;
    }

    /**
     * Produce a <messageHeader> element.
     */
    public static Element createMessageHeaderElement(Document doc,
            MessageHeader msgHeader) {
        Element msgHdrElem = doc.createElement("messageHeader");
        msgHdrElem.setAttribute("id", Long.toString(msgHeader.getID()));

        Element fromElem = doc.createElement("from");
        fromElem.appendChild(doc.createTextNode(msgHeader.getFrom()));
        msgHdrElem.appendChild(fromElem);

        Element toElem = doc.createElement("to");
        toElem.appendChild(doc.createTextNode(msgHeader.getTo()));
        msgHdrElem.appendChild(toElem);

        Element subjectElem = doc.createElement("subject");
        subjectElem.appendChild(doc.createTextNode(msgHeader.getSubject()));
        msgHdrElem.appendChild(subjectElem);

        // produce the following:
        //  <whenReceived sortKey="12345">DateAndTime</whenReceived>
        Element whenReceivedElem = doc.createElement("whenReceived");
        whenReceivedElem.appendChild(doc.createTextNode(
                sdFmt.format(msgHeader.getWhenReceived())));
        whenReceivedElem.setAttribute("sortKey",
                String.valueOf(msgHeader.getWhenReceived().getTime()));
        msgHdrElem.appendChild(whenReceivedElem);

        return msgHdrElem;
    }

    // prevent instantiation of this class
    private MailboxDOMProducer() {
    }
}
