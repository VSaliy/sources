package chap8;

import java.util.*;

/**
 * Contains a mail folder name, along with a list of MessageHeader
 * objects.
 */
public class MailFolder {
    private String folderName;
    private List messages;

    /**
     * @param folderName the name of this mail folder.
     * @param messages a list of MessageHeader objects.
     */
    public MailFolder(String folderName, List messages) {
        this.folderName = folderName;
        this.messages = messages;
    }

    /**
     * @return the name of this mail folder.
     */
    public String getFolderName() {
        return this.folderName;
    }

    /**
     * @return an iterator of MessageHeader objects.
     */
    public Iterator getMessages() {
        return this.messages.iterator();
    }
}

