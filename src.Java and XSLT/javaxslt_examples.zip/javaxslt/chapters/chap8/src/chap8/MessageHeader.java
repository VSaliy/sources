package chap8;

import java.util.*;

/**
 * A summary of a message in a mailbox folder.
 */
public class MessageHeader {
    private long id;
    private String from;
    private String to;
    private String subject;
    private Date whenReceived;

    public String toString() {
        return id + " " + from + " " + to + " " + subject + " " + whenReceived;
    }

    public MessageHeader(long id, String from, String to, String subject,
            Date whenReceived) {
        this.id = id;
        this.from = from;
        this.to = to;
        this.subject = subject;
        this.whenReceived = whenReceived;
    }

    public long getID() {
        return this.id;
    }

    public String getFrom() {
        return this.from;
    }

    public String getTo() {
        return this.to;
    }

    public String getSubject() {
        return this.subject;
    }

    public Date getWhenReceived() {
        return this.whenReceived;
    }
}
