package chap8;

import java.util.*;

/**
 * A mailbox consists of a collection of mail folders for a
 * particular user.
 */
public class Mailbox {
    private String username;
    private Map folders;

    // a standard folder name
    public static final String INBOX = "Inbox";

    /**
     * @param username the owner of this mailbox.
     * @param folders a Map that contains folder names as keys,
     * and MailFolder objects as values.
     */
    public Mailbox(String username, Map folders) {
        this.username = username;
        this.folders = folders;

        if (!this.folders.containsKey(INBOX)) {
            this.folders.put(INBOX, new ArrayList());
        }
    }

    /**
     * @return the owner of this mailbox.
     */
    public String getUsername() {
        return this.username;
    }

    /**
     * @return true if the specified folder is in this mailbox.
     */
    public boolean containsFolder(String folderName) {
        return this.folders.containsKey(folderName);
    }

    /**
     * @return an Iterator of String folder names.
     */
    public Iterator getFolderNames() {
        return this.folders.keySet().iterator();
    }

    /**
     * @return a specific folder, or null if folderName is invalid.
     */
    public MailFolder getFolder(String folderName) {
        return (MailFolder) this.folders.get(folderName);
    }
}

