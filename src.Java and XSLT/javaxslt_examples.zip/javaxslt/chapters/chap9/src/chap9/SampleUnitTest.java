package chap9;

import java.io.*;
import java.net.*;
import java.util.*;

// JAXP used for XSLT transformations
import javax.xml.transform.*;
import javax.xml.transform.stream.*;

// JDOM used for XML parsing and validation
import org.jdom.*;
import org.jdom.input.*;

// JUnit classes
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

/**
 * An example JUnit test. This class performs an XSLT transformation
 * and validates the result.
 */
public class SampleUnitTest extends TestCase {
    private String workingDir;

    // input XML files
    private File aidanXMLFile;
    private File johnXMLFile;

    // a stylesheet that condenses the XML data
    private File condenseXSLTFile;

    // the transformation results
    private File aidanCondensedXMLFile;
    private File johnCondensedXMLFile;

    private TransformerFactory transFact;

    /**
     * All JUnit tests have a constructor that takes the test name.
     */
    public SampleUnitTest(String name) {
        super(name);
    }

    /**
     * Initialization before each test[...] method is called.
     */
    public void setUp() {
        // locate a file named test.properties in the chap9 package
        ResourceBundle rb = ResourceBundle.getBundle("chap9.test");
        this.workingDir = rb.getString("chap9.workingDir");

        assertNotNull(workingDir);
        assertTrue("Unable to locate " + this.workingDir,
                new File(this.workingDir).exists());

        this.aidanXMLFile = new File(workingDir + File.separator
                + "aidan.xml");
        this.johnXMLFile = new File(workingDir + File.separator
                + "john.xml");
        this.condenseXSLTFile = new File(workingDir + File.separator
                + "condensePerson.xslt");

        this.aidanCondensedXMLFile = new File(this.workingDir + File.separator
                + "aidanCondensed.xml");
        this.johnCondensedXMLFile = new File(this.workingDir + File.separator
                + "johnCondensed.xml");

        this.transFact = TransformerFactory.newInstance();
    }

    /**
     * Clean up after each test[...] method
     */
    public void tearDown() {
        // the transformation results could be deleted here, but the
        // cleanup code is intentionally commented out so the
        // developer can see the generated files:

        // this.aidanCondensedXMLFile.delete();
        // this.johnCondensedXMLFile.delete();
    }

    /**
     * An individual unit test.
     */
    public void testTransformWithTemplates() throws Exception {
        Templates templates = this.transFact.newTemplates(
                new StreamSource(this.condenseXSLTFile));

        Transformer trans = templates.newTransformer();

        // do two transformations using the same Transformer
        trans.transform(new StreamSource(this.aidanXMLFile),
                new StreamResult(this.aidanCondensedXMLFile));
        trans.transform(new StreamSource(this.johnXMLFile),
                new StreamResult(this.johnCondensedXMLFile));

        // validate both files
        validateCondensedFile(this.aidanCondensedXMLFile,
                "Aidan Garrett Burke", "6/25/1999");
        validateCondensedFile(this.johnCondensedXMLFile,
                "John Fitzgerald Kennedy", "5/29/1917");
    }

    /**
     * Another unit test.
     */
    public void testTransformer() throws Exception {
        Transformer trans = this.transFact.newTransformer(
                new StreamSource(this.condenseXSLTFile));

        trans.transform(new StreamSource(this.aidanXMLFile),
                new StreamResult(this.aidanCondensedXMLFile));

        validateCondensedFile(this.aidanCondensedXMLFile,
                "Aidan Garrett Burke", "6/25/1999");
    }

    // a helper method used by each of the unit tests
    private void validateCondensedFile(File file, String expectedName,
            String expectedBirthDate) {
        try {
            // first do a simple validation against the DTD
            SAXBuilder builder = new SAXBuilder(true); // validate
            Document doc = builder.build(file);

            // now perform some additional checks
            Element nameElem = doc.getRootElement().getChild("name");
            assertEquals("Name was not correct",
                    expectedName, nameElem.getText());

            Element birthDateElem = doc.getRootElement().getChild("birthDate");
            assertEquals("Birth date was not correct",
                    expectedBirthDate, birthDateElem.getText());

        } catch (JDOMException jde) {
            fail("XML was not valid: " + jde.getMessage());
        }
    }

    /**
     * @return a TestSuite, which is a composite of Test objects.
     */
    public static Test suite() {
        // uses reflection to locate each method named test[...]
        return new TestSuite(SampleUnitTest.class);
    }

    /**
     * Allow the unit tests to be invoked from the command line
     * in text-only mode.
     */
    public static void main(String[] args) {
        TestRunner.run(suite());
    }
}
