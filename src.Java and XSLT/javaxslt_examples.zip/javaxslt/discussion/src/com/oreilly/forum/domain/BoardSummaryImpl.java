package com.oreilly.forum.domain;

import com.oreilly.forum.domain.*;
import java.util.*;

/**
 * An implementation of the BoardSummary interface.
 */
public class BoardSummaryImpl implements BoardSummary {
    private long id;
    private String name;
    private String description;
    private List monthsWithMessages;

    /**
     * @param monthsWithMessages a list of MonthYear objects.
     */
    public BoardSummaryImpl(long id, String name, String description,
            List monthsWithMessages) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.monthsWithMessages = monthsWithMessages;

    }

    public long getID() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    /**
     * @return an iterator of <code>MonthYear</code> objects.
     */
    public Iterator getMonthsWithMessages() {
        // ensure that the iterator is immutable
        return Collections.unmodifiableList(
                this.monthsWithMessages).iterator();
    }
}
