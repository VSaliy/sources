package com.oreilly.forum.domain;

/**
 * Represent a message, including the text.
 */
public interface Message extends MessageSummary {
    /**
     * @return the text of this message.
     */
    String getText();
}
