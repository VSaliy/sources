package com.oreilly.forum.servlet;

import com.oreilly.forum.ForumConfig;
import com.oreilly.forum.jdbcimpl.DBUtil;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * The single servlet in the discussion forum.
 */
public class ForumServlet extends HttpServlet {
    private ReqHandlerRegistry registry;

    /**
     * Registers all request handlers and sets up the
     * ForumConfig object.
     */
    public void init(ServletConfig sc) throws ServletException {
        super.init(sc);

        // get initialization parameters from the deployment
        // descriptor (web.xml)
        String jdbcDriverClassName = sc.getInitParameter(
                "jdbcDriverClassName");
        String databaseURL = sc.getInitParameter(
                "databaseURL");
        String adapterClassName = sc.getInitParameter(
                "adapterClassName");
        ForumConfig.setValues(jdbcDriverClassName,
                databaseURL, adapterClassName);

        try {
            // load all request handlers
            this.registry = new ReqHandlerRegistry(new HomeReqHandler());
            this.registry.register(new PostMsgReqHandler());
            this.registry.register(new ViewMonthReqHandler());
            this.registry.register(new ViewMsgReqHandler());
        } catch (Exception ex) {
            log(ex.getMessage(), ex);
            throw new UnavailableException(ex.getMessage(), 10);
        }
    }

    /**
     * Closes all database connections. This method is invoked
     * when the Servlet is unloaded.
     */
    public void destroy() {
        super.destroy();
        DBUtil.closeAllConnections();
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws IOException,
            ServletException {
        ReqHandler rh = this.registry.getHandler(request);
        Renderer rend = rh.doPost(this, request, response);
        rend.render(this, request, response);
    }

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws IOException,
            ServletException {
        ReqHandler rh = this.registry.getHandler(request);
        Renderer rend = rh.doGet(this, request, response);
        rend.render(this, request, response);
    }
}
