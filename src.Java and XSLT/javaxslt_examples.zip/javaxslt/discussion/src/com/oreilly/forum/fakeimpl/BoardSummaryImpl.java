package com.oreilly.forum.fakeimpl;

import com.oreilly.forum.domain.*;

import java.util.*;

public class BoardSummaryImpl implements BoardSummary {
    private long id;
    private String name;
    private String description;
    // a list of MonthYear objects
    private List monthsWithMessages;


    public BoardSummaryImpl(long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.monthsWithMessages = new ArrayList();
    }

    public void messageAdded(Message msg) {
        DayMonthYear createDate = msg.getCreateDate();

        // update the monthsWithMessages list
        Iterator iter = this.monthsWithMessages.iterator();
        while (iter.hasNext()) {
            MonthYear curMonth = (MonthYear) iter.next();
            if (createDate.getMonth() == curMonth.getMonth()
                    && createDate.getYear() == curMonth.getYear()) {
                return;
            }
        }

        this.monthsWithMessages.add(createDate);
    }


    public long getID() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Iterator getMonthsWithMessages() {
        return this.monthsWithMessages.iterator();
    }
}
