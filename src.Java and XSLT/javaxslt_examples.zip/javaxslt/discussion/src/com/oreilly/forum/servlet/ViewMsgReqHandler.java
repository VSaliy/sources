package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Handle a request to view a message.
 */
public class ViewMsgReqHandler extends ReqHandler {

    protected String getPathInfo() {
        return "viewMsg";
    }

    protected Renderer doGet(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        try {
            DataAdapter adapter = DataAdapter.getInstance();

            // msgID is a required parameter and must be valid
            String msgIDStr = request.getParameter("msgID");

            if (msgIDStr == null) {
                servlet.log("Required parameter 'msgID' was missing");
                return new ErrorRenderer("Invalid request");
            }

            Message msg = adapter.getMessage(Long.parseLong(msgIDStr));
            MessageSummary inResponseTo = null;
            if (msg.getInReplyTo() > -1) {
                inResponseTo = adapter.getMessage(msg.getInReplyTo());
            }
            return new ViewMsgRenderer(msg, inResponseTo);
        } catch (NumberFormatException nfe) {
            servlet.log("'msgID' parameter was not a number");
            return new ErrorRenderer("Invalid request");
        } catch (DataException de) {
            return new ErrorRenderer(de);
        }
    }
}
