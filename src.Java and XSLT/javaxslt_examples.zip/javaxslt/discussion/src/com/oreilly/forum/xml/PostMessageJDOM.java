package com.oreilly.forum.xml;

import com.oreilly.forum.domain.*;
import org.jdom.*;

/**
 * Produce JDOM for the "Post Message" page.
 */
public class PostMessageJDOM {

    public static Element produceElement(
            BoardSummary board,
            MessageSummary inResponseToMsg,
            boolean showError,
            String subject,
            String authorEmail,
            String msgText) {
        Element messageElem = new Element("postMsg");

        // reuse the BoardSummaryJDOM class to produce a
        // fragment of the XML
        messageElem.addContent(BoardSummaryJDOM.produceNameIDElement(board));

        if (inResponseToMsg != null) {
            Element inRespTo = new Element("inResponseTo")
                    .addAttribute("id", Long.toString(inResponseToMsg.getID()));
            inRespTo.addContent(new Element("subject")
                    .setText(inResponseToMsg.getSubject()));
            messageElem.addContent(inRespTo);
        }

        if (showError) {
            messageElem.addContent(new Element("error")
                    .addAttribute("code", "ALL_FIELDS_REQUIRED"));
        }

        Element prefill = new Element("prefill");
        prefill.addContent(new Element("subject")
                .setText(subject));
        prefill.addContent(new Element("authorEmail")
                .setText(authorEmail));
        prefill.addContent(new Element("message")
                .setText(msgText));
        messageElem.addContent(prefill);

        return messageElem;
    }


    private PostMessageJDOM() {
    }
}
