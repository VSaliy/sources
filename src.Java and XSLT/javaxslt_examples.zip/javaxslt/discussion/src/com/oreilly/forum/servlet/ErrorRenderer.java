package com.oreilly.forum.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Shows an error page. Since errors are frequently caused by improperly
 * configured JAR files, XML And XSLT are not used by this class.
 * If XML and XSLT were used, then the same CLASSPATH issue that caused
 * the original exception to occur would probably cause this page
 * to fail as well.
 */
public class ErrorRenderer extends Renderer {
    private String message;
    private Throwable throwable;

    public ErrorRenderer(Throwable throwable) {
        this(throwable, throwable.getMessage());
    }

    public ErrorRenderer(String message) {
        this(null, message);
    }

    public ErrorRenderer(Throwable throwable, String message) {
        this.throwable = throwable;
        this.message = message;
    }

    public void render(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        // just show a simple error page for now.
        pw.println("<html>");
        pw.println("<body>");
        pw.println("<p>");
        pw.println(this.message);
        pw.println("</p>");
        if (this.throwable != null) {
            pw.println("<pre>");
            this.throwable.printStackTrace(pw);
            pw.println("</pre>");
        }
        pw.println("</body></html>");
    }
}
