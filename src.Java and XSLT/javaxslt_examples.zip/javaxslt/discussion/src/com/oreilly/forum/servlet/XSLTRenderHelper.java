package com.oreilly.forum.servlet;

import com.oreilly.javaxslt.util.StylesheetCache;
import java.io.*;
import java.net.URL;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import org.jdom.*;
import org.jdom.output.*;

/**
 * A helper class that makes rendering of XSLT easier. This
 * eliminates the need to duplicate a lot of code for each
 * of the web pages in this app.
 */
public class XSLTRenderHelper {
    private static Map filenameCache = new HashMap();

    /**
     * Perform an XSLT transformation.
     *
     * @param servlet provides access to the ServletContext so
     *                the XSLT directory can be determined.
     * @param xmlJDOMData JDOM data for the XML Document.
     * @param xsltBaseName the name of the stylesheet without a directory.
     * @param response the Servlet response to write output to.
     */
    public static void render(HttpServlet servlet, Document xmlJDOMData,
            String xsltBaseName, HttpServletResponse response)
            throws ServletException, IOException {

        String xsltFileName = null;
        try {
            // figure out the complete XSLT stylesheet file name
            synchronized (filenameCache) {
                xsltFileName = (String) filenameCache.get(xsltBaseName);
                if (xsltFileName == null) {
                    ServletContext ctx = servlet.getServletContext();
                    xsltFileName = ctx.getRealPath(
                            "/WEB-INF/xslt/" + xsltBaseName);
                    filenameCache.put(xsltBaseName, xsltFileName);
                }
            }

            // write the JDOM data to a StringWriter
            StringWriter sw = new StringWriter();
            XMLOutputter xmlOut = new XMLOutputter("", false, "UTF-8");
            xmlOut.output(xmlJDOMData, sw);

            response.setContentType("text/html");
            Transformer trans = StylesheetCache.newTransformer(xsltFileName);

            // pass a parameter to the XSLT stylesheet
            trans.setParameter("rootDir", "/forum/");

            trans.transform(new StreamSource(new StringReader(sw.toString())),
                            new StreamResult(response.getWriter()));
        } catch (IOException ioe) {
            throw ioe;
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    private XSLTRenderHelper() {
    }
}
