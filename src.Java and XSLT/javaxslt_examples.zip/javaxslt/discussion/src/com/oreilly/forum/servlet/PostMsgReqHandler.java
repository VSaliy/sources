package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Handles GET and POST requests for the page that allows users
 * to post or reply to a message.
 */
public class PostMsgReqHandler extends ReqHandler {

    protected String getPathInfo() {
        return "postMsg";
    }

    /**
     * When an HTTP GET is issues, show the web page for the
     * first time.
     */
    protected Renderer doGet(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        try {
            // mode must be "postNewMsg" or "replyToMsg"
            String mode = request.getParameter("mode");

            DataAdapter adapter = DataAdapter.getInstance();
            if ("replyToMsg".equals(mode)) {
                long origMsgID = Long.parseLong(
                        request.getParameter("origMsgID"));
                Message inResponseToMsg = adapter.getMessage(origMsgID);
                if (inResponseToMsg != null) {
                    return new PostMsgRenderer(inResponseToMsg);
                }
            } else if ("postNewMsg".equals(mode)) {
                long boardID = Long.parseLong(
                        request.getParameter("boardID"));
                BoardSummary board = adapter.getBoardSummary(boardID);
                if (board != null) {
                    return new PostMsgRenderer(board);
                }
            }

            return new ErrorRenderer("Invalid request");
        } catch (NumberFormatException nfe) {
            return new ErrorRenderer(nfe);
        } catch (DataException de) {
            return new ErrorRenderer(de);
        }
    }


    /**
     * Handles HTTP POST requests, indicating that the user has
     * filled in the form and pressed the Submit button.
     */
    protected Renderer doPost(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {

        // if the user hit the Cancel button, return to the home page
        if (request.getParameter("cancelBtn") != null) {
            return new HomeRenderer();
        }

        // lots of error checking follows...
        if (request.getParameter("submitBtn") == null) {
            servlet.log("Expected 'submitBtn' parameter to be present");
            return new ErrorRenderer("Invalid request");
        }

        // a null parameter indicates either a hack attempt, or a
        // syntax error in the HTML
        String mode = request.getParameter("mode");
        String msgSubject = request.getParameter("msgSubject");
        String authorEmail = request.getParameter("authorEmail");
        String msgText = request.getParameter("msgText");
        if (mode == null || msgSubject == null || authorEmail == null
                || msgText == null) {
            return new ErrorRenderer("Invalid request");
        }
        // one of these may be null
        String origMsgIDStr = request.getParameter("origMsgID");
        String boardIDStr = request.getParameter("boardID");
        if (origMsgIDStr == null && boardIDStr == null) {
            return new ErrorRenderer("Invalid request");
        }

        long origMsgID = 0;
        long boardID = 0;
        try {
            origMsgID = (origMsgIDStr != null) ? Long.parseLong(origMsgIDStr) : 0;
            boardID = (boardIDStr != null) ? Long.parseLong(boardIDStr) : 0;
        } catch (NumberFormatException nfe) {
            return new ErrorRenderer("Invalid request");
        }


        // remove extra whitespace then verify that the user filled
        // in all required fields
        msgSubject = msgSubject.trim();
        authorEmail = authorEmail.trim();
        msgText = msgText.trim();

        try {
            DataAdapter adapter = DataAdapter.getInstance();
            if (msgSubject.length() == 0
                    || authorEmail.length() == 0
                    || msgText.length() == 0) {
                BoardSummary board = (boardIDStr == null) ? null
                        : adapter.getBoardSummary(boardID);
                MessageSummary inResponseToMsg = (origMsgIDStr == null) ? null
                        : adapter.getMessage(origMsgID);

                return new PostMsgRenderer(board, inResponseToMsg,
                        true, msgSubject, authorEmail, msgText);
            }


            //
            // If this point is reached, no errors were detected so the
            // new message can be posted, or a response can be created
            //
            Message msg = null;
            if ("replyToMsg".equals(mode)) {
                msg = adapter.replyToMessage(origMsgID, msgSubject,
                        authorEmail, msgText);
            } else if ("postNewMsg".equals(mode)) {
                msg = adapter.postNewMessage(boardID, msgSubject,
                        authorEmail, msgText);
            }


            if (msg != null) {
                MessageSummary inResponseTo = null;
                if (msg.getInReplyTo() > -1) {
                    inResponseTo = adapter.getMessage(msg.getInReplyTo());
                }
                return new ViewMsgRenderer(msg, inResponseTo);
            }
            return new ErrorRenderer("Invalid request");
        } catch (DataException dex) {
            return new ErrorRenderer(dex);
        }
    }
}
