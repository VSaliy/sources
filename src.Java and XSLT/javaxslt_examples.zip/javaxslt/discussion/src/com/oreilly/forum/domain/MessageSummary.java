package com.oreilly.forum.domain;

import java.util.*;

/**
 * Basic information about a message, not including the message text.
 */
public interface MessageSummary extends Comparable {

    /**
     * @return the ID of the message that this one is a reply to, or
     *         -1 if none.
     */
    long getInReplyTo();

    /**
     * @return the unique ID of this message.
     */
    long getID();

    /**
     * @return when this message was created.
     */
    DayMonthYear getCreateDate();

    /**
     * @return the board that this message belongs to.
     */
    BoardSummary getBoard();

    /**
     * @return the subject of this message.
     */
    String getSubject();

    /**
     * The author Email can be 80 characters.
     */
    String getAuthorEmail();
}
