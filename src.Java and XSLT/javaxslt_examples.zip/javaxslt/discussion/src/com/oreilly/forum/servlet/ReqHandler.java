package com.oreilly.forum.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * All request handlers must extend from this class.
 */
public abstract class ReqHandler {
    protected abstract String getPathInfo();

    protected Renderer doGet(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        return new ErrorRenderer("GET not allowed");
    }

    protected Renderer doPost(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        return new ErrorRenderer("POST not allowed");
    }
}
