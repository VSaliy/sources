package com.oreilly.forum.xml;

import com.oreilly.forum.domain.*;
import java.util.*;
import org.jdom.*;

/**
 * Produce JDOM data for the home page.
 */
public class HomeJDOM {

    /**
     * @param boards an iterator of <code>BoardSummary</code> objects.
     */
    public static Element produceElement(Iterator boards) {
        Element homeElem = new Element("home");
        while (boards.hasNext()) {
            BoardSummary curBoard = (BoardSummary) boards.next();
            homeElem.addContent(BoardSummaryJDOM.produceElement(curBoard));
        }

        return homeElem;
    }

    private HomeJDOM() {
    }
}
