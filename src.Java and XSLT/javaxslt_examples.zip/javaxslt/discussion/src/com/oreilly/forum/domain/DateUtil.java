package com.oreilly.forum.domain;

import java.util.*;

/**
 * Misc utility functions for dates. Methods are synchronized because
 * the same Calendar instance is shared.
 */
public final class DateUtil {

    private static Calendar cal = Calendar.getInstance();

    /**
     * @return the day of the month for a given date.
     */
    public synchronized static int getDayOfMonth(Date date) {
        cal.setTime(date);
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * @return the month number for a given date.
     */
    public synchronized static int getMonth(Date date) {
        cal.setTime(date);
        return cal.get(Calendar.MONTH);
    }

    /**
     * @return the year number for the given date.
     */
    public synchronized static int getYear(Date date) {
        cal.setTime(date);
        return cal.get(Calendar.YEAR);
    }

    private DateUtil() {
    }
}