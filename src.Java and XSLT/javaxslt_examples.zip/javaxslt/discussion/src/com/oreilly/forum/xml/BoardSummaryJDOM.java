package com.oreilly.forum.xml;

import com.oreilly.forum.domain.*;
import java.util.*;
import org.jdom.*;

/**
 * Produces JDOM for a BoardSummary object.
 */
public class BoardSummaryJDOM {
    public static Element produceNameIDElement(BoardSummary board) {
        // produce the following:
        // <board id="123">
        //   <name>the board name</name>
        //   <description>board description</description>
        // </board>
        Element boardElem = new Element("board");
        boardElem.addAttribute("id", Long.toString(board.getID()));
        boardElem.addContent(new Element("name")
                .setText(board.getName()));
        boardElem.addContent(new Element("description")
                .setText(board.getDescription()));
        return boardElem;
    }

    public static Element produceElement(BoardSummary board) {
        Element boardElem = produceNameIDElement(board);

        // add the list of messages
        Iterator iter = board.getMonthsWithMessages();
        while (iter.hasNext()) {
            MonthYear curMonth = (MonthYear) iter.next();
            Element elem = new Element("messages");
            elem.addAttribute("month", Integer.toString(curMonth.getMonth()));
            elem.addAttribute("year", Integer.toString(curMonth.getYear()));
            boardElem.addContent(elem);
        }

        return boardElem;
    }

    private BoardSummaryJDOM() {
    }
}
