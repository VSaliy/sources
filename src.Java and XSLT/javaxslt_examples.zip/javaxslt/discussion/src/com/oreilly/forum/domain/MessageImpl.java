package com.oreilly.forum.domain;

import java.util.*;

/**
 * An implementation of the Message interface.
 */
public class MessageImpl extends MessageSummaryImpl implements Message {
    private String text;

    /**
     * Construct a new instance of this class.
     */
    public MessageImpl(long id, DayMonthYear createDate,
            BoardSummary board, String subject, String authorEmail,
            String text, long inReplyTo) {
        super(id, createDate, board, subject, authorEmail, inReplyTo);
        this.text = text;
    }

    /**
     * @return the text of this message.
     */
    public String getText() {
        return this.text;
    }
}
