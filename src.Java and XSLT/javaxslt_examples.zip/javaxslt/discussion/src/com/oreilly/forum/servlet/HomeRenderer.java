package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import com.oreilly.forum.xml.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.jdom.*;

/**
 * Shows the home page.
 */
public class HomeRenderer extends Renderer {

    public void render(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        try {
            // get the data for the home page
            DataAdapter adapter = DataAdapter.getInstance();

            // an iterator of BoardSummary objects
            Iterator boards = adapter.getAllBoards();

            // convert the data into XML (a JDOM Document)
            Document doc = new Document(HomeJDOM.produceElement(boards));

            // apply the appropriate stylesheet
            XSLTRenderHelper.render(servlet, doc, "home.xslt", response);
        } catch (DataException de) {
            new ErrorRenderer(de).render(servlet, request, response);
        }
    }
}
