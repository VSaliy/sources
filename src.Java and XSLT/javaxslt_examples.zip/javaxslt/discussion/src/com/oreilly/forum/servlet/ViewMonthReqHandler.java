package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Handle a request to view a month for a message board.
 */
public class ViewMonthReqHandler extends ReqHandler {

    protected String getPathInfo() {
        return "viewMonth";
    }

    protected Renderer doGet(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        try {
            DataAdapter adapter = DataAdapter.getInstance();

            // these are all required parameters
            long boardID = 0L;
            int month = 0;
            int year = 0;
            try {
                boardID = Long.parseLong(request.getParameter("boardID"));
                month = Integer.parseInt(request.getParameter("month"));
                year = Integer.parseInt(request.getParameter("year"));
            } catch (Exception ex) {
                return new ErrorRenderer("Invalid request");
            }
            BoardSummary board = adapter.getBoardSummary(boardID);
            if (board == null) {
                return new ErrorRenderer("Invalid request");
            }

            return new ViewMonthRenderer(board, new MonthYear(month, year));
        } catch (DataException de) {
            return new ErrorRenderer(de);
        }
    }
}
