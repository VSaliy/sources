package com.oreilly.forum.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * This is the 'default' request handler in the app. The
 * first inbound request generally goes to an instance
 * of this class, which returns the home page renderer.
 */
public class HomeReqHandler extends ReqHandler {

    protected String getPathInfo() {
        return "home";
    }

    protected Renderer doGet(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        return new HomeRenderer();
    }

}
