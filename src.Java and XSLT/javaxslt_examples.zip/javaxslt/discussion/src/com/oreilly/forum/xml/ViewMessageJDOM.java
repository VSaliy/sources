package com.oreilly.forum.xml;

import com.oreilly.forum.domain.*;
import java.util.Date;
import org.jdom.*;
import org.jdom.output.*;

/**
 * Generate JDOM for the View Message page.
 */
public class ViewMessageJDOM {

    /**
     * @param message the message to view.
     * @param inResponseTo the message this one is in response to, or
     * perhaps null.
     */
    public static Element produceElement(Message message,
            MessageSummary inResponseTo) {
        Element messageElem = new Element("message");
        messageElem.addAttribute("id", Long.toString(message.getID()));
        DayMonthYear d = message.getCreateDate();
        messageElem.addAttribute("month",
                Integer.toString(d.getMonth()));
        messageElem.addAttribute("day",
                Integer.toString(d.getDay()));
        messageElem.addAttribute("year",
                Integer.toString(d.getYear()));

        Element boardElem = BoardSummaryJDOM.produceNameIDElement(
                message.getBoard());
        messageElem.addContent(boardElem);


        if (inResponseTo != null) {
            Element inRespToElem = new Element("inResponseTo")
                    .addAttribute("id", Long.toString(inResponseTo.getID()));
            inRespToElem.addContent(new Element("subject")
                    .setText(inResponseTo.getSubject()));
            messageElem.addContent(inRespToElem);
        }

        messageElem.addContent(new Element("subject")
                .setText(message.getSubject()));
        messageElem.addContent(new Element("authorEmail")
                .setText(message.getAuthorEmail()));
        messageElem.addContent(new Element("text")
                .setText(message.getText()));
        return messageElem;
    }

    private ViewMessageJDOM() {
    }
}
