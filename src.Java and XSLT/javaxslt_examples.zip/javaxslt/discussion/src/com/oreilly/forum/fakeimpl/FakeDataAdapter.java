package com.oreilly.forum.fakeimpl;

import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import java.util.*;


public class FakeDataAdapter extends DataAdapter {
    // a list of BoardSummary objects
    private List allBoards;
    private static long nextMessageID = 0;
    private Map messageMap = new HashMap();

    public FakeDataAdapter() throws DataException {
        this.allBoards = new ArrayList();

        BoardSummary bs0 = new BoardSummaryImpl(0L,
                "Java Programming",
                "General programming questions about Java.");
        BoardSummary bs1 = new BoardSummaryImpl(1L,
                "XSLT Stylesheet Techniques",
                "Writing effective XSLT stylesheets.");
        this.allBoards.add(bs0);
        this.allBoards.add(bs1);

        this.postNewMessage(0L, "First subject in Java Prog",
                "burke_e@yahoo.com", "Sample message text");

    }

    /**
     * @param msgID must be a valid message identifier.
     * @return the message with the specified id.
     * @throws DataException if msgID does not exist or a database
     * error occurs.
     */
    public Message getMessage(long msgID) throws DataException {
        Message msg = (Message) this.messageMap.get(new Long(msgID));
        if (msg != null) {
            return msg;
        }
        throw new DataException("Invalid msgID");
    }

    /**
     * If no messages exist for the specified board and month, return
     * an empty iterator.
     * @return an iterator of <code>MessageSummary</code> objects.
     * @throws DataException if the boardID is illegal or a database
     * error occurs.
     */
    public Iterator getAllMessages(long boardID, MonthYear month)
            throws DataException {
        // this is slow, but works fine for a fake implementation
        List msgs = new ArrayList();
        Iterator iter = this.messageMap.values().iterator();
        while (iter.hasNext()) {
            MessageSummary curMsg = (MessageSummary) iter.next();
            if (curMsg.getBoard().getID() == boardID
                    && month.containsInMonth(curMsg.getCreateDate())) {
                msgs.add(curMsg);
            }
        }
        return msgs.iterator();
    }

    /**
     * Add a reply to an existing message.
     *
     * @throws DataException if a database error occurs, or if any
     * parameter is illegal.
     */
    public Message replyToMessage(long origMsgID, String msgSubject,
            String authorEmail, String msgText) throws DataException {
        MessageSummary origMsg = getMessage(origMsgID);
        long msgID = getNextMessageID();

        Message msg = new MessageImpl(msgID, new DayMonthYear(), origMsg.getBoard(),
                msgSubject, authorEmail, msgText, origMsgID);

        this.messageMap.put(new Long(msg.getID()), msg);
        return msg;
    }

    /**
     * Post a new message.
     *
     * @return the newly created message.
     * @throws DataException if a database error occurs, or if any
     * parameter is illegal.
     */
    public Message postNewMessage(long boardID, String msgSubject,
            String authorEmail, String msgText) throws DataException {
        BoardSummary boardSum = getBoardSummary(boardID);
        long msgID = getNextMessageID();

        Message msg = new MessageImpl(msgID, new DayMonthYear(), boardSum,
                msgSubject, authorEmail, msgText, -1);
        this.messageMap.put(new Long(msg.getID()), msg);

        ((BoardSummaryImpl) boardSum).messageAdded(msg);

        return msg;
    }

    /**
     * @return an iterator of <code>BoardSummary</code> objects.
     */
    public Iterator getAllBoards() throws DataException {
        return this.allBoards.iterator();
    }

    public BoardSummary getBoardSummary(long boardID)
            throws DataException {
        Iterator iter = getAllBoards();
        while (iter.hasNext()) {
            BoardSummary curBoard = (BoardSummary) iter.next();
            if (curBoard.getID() == boardID) {
                return curBoard;
            }
        }
        throw new DataException("Illegal boardID: " + boardID);
    }

    private synchronized static long getNextMessageID() {
        nextMessageID++;
        return nextMessageID;
    }
}
