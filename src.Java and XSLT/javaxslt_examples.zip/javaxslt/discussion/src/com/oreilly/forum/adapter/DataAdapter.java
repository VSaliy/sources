package com.oreilly.forum.adapter;

import com.oreilly.forum.*;
import com.oreilly.forum.domain.*;
import java.util.*;

/**
 * Defines an interface to a data source.
 */
public abstract class DataAdapter {
    private static DataAdapter instance;

    /**
     * @return the singleton instance of this class.
     */
    public static synchronized DataAdapter getInstance()
            throws DataException {
        if (instance == null) {
            String adapterClassName = ForumConfig.getAdapterClassName();
            try {
                Class adapterClass = Class.forName(adapterClassName);
                instance = (DataAdapter) adapterClass.newInstance();
            } catch (Exception ex) {
                throw new DataException("Unable to instantiate "
                        + adapterClassName);
            }
        }
        return instance;
    }

    /**
     * @param msgID must be a valid message identifier.
     * @return the message with the specified id.
     * @throws DataException if msgID does not exist or a database
     * error occurs.
     */
    public abstract Message getMessage(long msgID) throws DataException;

    /**
     * Add a reply to an existing message.
     *
     * @throws DataException if a database error occurs, or if any
     * parameter is illegal.
     */
    public abstract Message replyToMessage(long origMsgID, String msgSubject,
            String authorEmail, String msgText) throws DataException;

    /**
     * Post a new message.
     *
     * @return the newly created message.
     * @throws DataException if a database error occurs, or if any
     * parameter is illegal.
     */
    public abstract Message postNewMessage(long boardID, String msgSubject,
            String authorEmail, String msgText) throws DataException;

    /**
     * If no messages exist for the specified board and month, return
     * an empty iterator.
     * @return an iterator of <code>MessageSummary</code> objects.
     * @throws DataException if the boardID is illegal or a database
     * error occurs.
     */
    public abstract Iterator getAllMessages(long boardID, MonthYear month)
            throws DataException;

    /**
     * @return an iterator of all <code>BoardSummary</code> objects.
     */
    public abstract Iterator getAllBoards() throws DataException;


    /**
     * @return a board summary for the given id.
     * @throws DataException if boardID is illegal or a database
     *                       error occurs.
     */
    public abstract BoardSummary getBoardSummary(long boardID)
            throws DataException;
}
