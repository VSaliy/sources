package com.oreilly.forum.domain;

import java.util.Date;

/**
 * Represents a day, month, and year.
 */
public class DayMonthYear extends MonthYear {
    private int day;

    public DayMonthYear() {
        this(new Date());
    }

    public DayMonthYear(Date date) {
        super(date);
        this.day = DateUtil.getDayOfMonth(date);
    }

    public DayMonthYear(int day, int month, int year) {
        super(month, year);
        this.day = day;
    }

    public int getDay() {
        return this.day;
    }

    public boolean equals(Object obj) {
        if (obj instanceof DayMonthYear) {
            DayMonthYear rhs = (DayMonthYear) obj;
            return super.equals(obj) && this.day == rhs.day;
        }
        return false;
    }

    public int hashCode() {
        return super.hashCode() ^ this.day;
    }

    public int compareTo(Object obj) {
        DayMonthYear rhs = (DayMonthYear) obj;
        int comparison = super.compareTo(obj);
        if (comparison == 0) {
            if (this.day < rhs.day) {
                return -1;
            } else if (this.day > rhs.day) {
                return 1;
            }
        }
        return comparison;
    }

    public String toString() {
        return getMonth() + "/" + getDay() + "/" + getYear();
    }
}
