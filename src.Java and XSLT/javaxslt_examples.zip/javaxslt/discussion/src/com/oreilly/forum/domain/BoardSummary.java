package com.oreilly.forum.domain;

import java.util.Iterator;

/**
 * Information about a message board.
 */
public interface BoardSummary {
    /**
     * @return a unique ID for this board.
     */
    long getID();

    /**
     * @return a name for this board.
     */
    String getName();

    /**
     * @return a description for this board.
     */
    String getDescription();

    /**
     * @return an iterator of <code>MonthYear</code> objects.
     */
    Iterator getMonthsWithMessages();
}
