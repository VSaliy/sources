package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.domain.*;
import com.oreilly.forum.xml.*;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.jdom.*;

/**
 * Show the web page that allows a user to post or reply to
 * a message.
 */
public class PostMsgRenderer extends Renderer {
    private MessageSummary inResponseToMsg;
    private BoardSummary board;
    private String msgSubject;
    private String authorEmail;
    private String msgText;
    private boolean showError;

    /**
     * This constructor indicates that the user is replying to an
     * existing message.
     */
    public PostMsgRenderer(Message inResponseToMsg) {
        this.board = inResponseToMsg.getBoard();
        this.inResponseToMsg = inResponseToMsg;
        this.showError = false;
        this.msgSubject = "Re: " + inResponseToMsg.getSubject();
        this.authorEmail = "";

        StringTokenizer st = new StringTokenizer(
                inResponseToMsg.getText(), "\n");
        StringBuffer buf = new StringBuffer();
        buf.append("\n");
        buf.append("\n> -----Original Message-----");
        buf.append("\n>   Posted by ");
        buf.append(inResponseToMsg.getAuthorEmail());
        buf.append(" on ");
        buf.append(inResponseToMsg.getCreateDate().toString());
        buf.append("\n");
        while (st.hasMoreTokens()) {
            String curLine = st.nextToken();
            buf.append("> ");
            buf.append(curLine);
            buf.append("\n");
        }
        buf.append("> ");
        this.msgText = buf.toString();
    }

    /**
     * This constructor indicates that the user is posting
     * a new message.
     */
    public PostMsgRenderer(BoardSummary board) {
        this(board, null, false, "", "", "");
    }

    /**
     * This constructor is used when the user submitted a form
     * but did not fill out all required fields.
     */
    public PostMsgRenderer(BoardSummary board,
            MessageSummary inResponseToMsg,
            boolean showError,
            String msgSubject,
            String authorEmail,
            String msgText) {
        this.board = board;
        this.inResponseToMsg = inResponseToMsg;
        this.showError = showError;
        this.msgSubject = msgSubject;
        this.authorEmail = authorEmail;
        this.msgText = msgText;
    }

    public void render(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {

        // convert the data into XML (a JDOM Document)
        Document doc = new Document(PostMessageJDOM.produceElement(
                this.board,
                this.inResponseToMsg,
                this.showError,
                this.msgSubject,
                this.authorEmail,
                this.msgText));

        // apply the appropriate stylesheet
        XSLTRenderHelper.render(servlet, doc, "postMsg.xslt", response);
    }
}
