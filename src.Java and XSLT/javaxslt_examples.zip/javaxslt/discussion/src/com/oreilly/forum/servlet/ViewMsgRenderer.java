package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.domain.*;
import com.oreilly.forum.xml.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.jdom.*;

/**
 * Show the "view message" page.
 */
public class ViewMsgRenderer extends Renderer {

    private Message message;
    private MessageSummary inResponseTo;

    public ViewMsgRenderer(Message message, MessageSummary inResponseTo) {
        this.message = message;
        this.inResponseTo = inResponseTo;
    }

    public void render(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {

        // convert the data into XML (a JDOM Document)
        Document doc = new Document(ViewMessageJDOM.produceElement(
                this.message, this.inResponseTo));

        // apply the appropriate stylesheet
        XSLTRenderHelper.render(servlet, doc, "viewMsg.xslt", response);
    }
}
