package com.oreilly.forum;


/**
 * Define application-wide configuration information. The Servlet
 * must call the setValues() method before any of the getter
 * methods in this class can be used.
 */
public class ForumConfig {
    // maximum sizes of various fields in the database
    public static final int MAX_BOARD_NAME_LEN = 80;
    public static final int MAX_BOARD_DESC_LEN = 255;
    public static final int MAX_MSG_SUBJECT_LEN = 80;
    public static final int MAX_EMAIL_LEN = 80;

    private static String jdbcDriverClassName;
    private static String databaseURL;
    private static String adapterClassName;

    public static void setValues(
            String jdbcDriverClassName,
            String databaseURL,
            String adapterClassName) {
        ForumConfig.jdbcDriverClassName = jdbcDriverClassName;
        ForumConfig.databaseURL = databaseURL;
        ForumConfig.adapterClassName = adapterClassName;
    }

    /**
     * @return the JDBC driver class name.
     */
    public static String getJDBCDriverClassName() {
        return ForumConfig.jdbcDriverClassName;
    }

    /**
     * @return the JDBC database URL.
     */
    public static String getDatabaseURL() {
        return ForumConfig.databaseURL;
    }

    /**
     * @return the data adapter implementation class name.
     */
    public static String getAdapterClassName() {
        return ForumConfig.adapterClassName;
    }

    private ForumConfig() {
    }
}
