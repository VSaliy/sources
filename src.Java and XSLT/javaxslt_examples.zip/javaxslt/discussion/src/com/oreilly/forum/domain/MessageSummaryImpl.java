package com.oreilly.forum.domain;

import java.util.*;

/**
 * Implementation of the MessageSummary interface.
 */
public class MessageSummaryImpl implements MessageSummary {
    private long id;
    private BoardSummary board;
    private String subject;
    private String authorEmail;
    private DayMonthYear createDate;
    private long inReplyTo;

    public MessageSummaryImpl(long id, DayMonthYear createDate,
            BoardSummary board, String subject, String authorEmail,
            long inReplyTo) {
        this.id = id;
        this.createDate = createDate;
        this.board = board;
        this.subject = subject;
        this.authorEmail = authorEmail;
        this.inReplyTo = inReplyTo;
    }

    public long getInReplyTo() {
        return this.inReplyTo;
    }

    public long getID() {
        return this.id;
    }

    public DayMonthYear getCreateDate() {
        return this.createDate;
    }

    public BoardSummary getBoard() {
        return this.board;
    }

    public String getSubject() {
        return this.subject;
    }

    public String getAuthorEmail() {
        return this.authorEmail;
    }

    public boolean equals(Object obj) {
        if (obj instanceof MessageSummaryImpl) {
            MessageSummaryImpl rhs = (MessageSummaryImpl) obj;
            return this.id == rhs.id;
        }
        return false;
    }

    public int hashCode() {
        return (int) this.id;
    }

    /**
     * Sorts by create date followed by message subject.
     */
    public int compareTo(Object obj) {
        if (this == obj) {
            return 0;
        }
        MessageSummaryImpl rhs = (MessageSummaryImpl) obj;

        int comparison = this.createDate.compareTo(rhs.createDate);
        if (comparison != 0) {
            return comparison;
        }

        comparison = this.subject.compareTo(rhs.subject);
        if (comparison != 0) {
            return comparison;
        }

        return 0;
    }
}
