package com.oreilly.forum.servlet;

import java.util.*;
import javax.servlet.http.*;

/**
 * A utility class that locates request handler instances based
 * on extra path information.
 */
public class ReqHandlerRegistry {
    private ReqHandler defaultHandler;
    private Map handlerMap = new HashMap();

    public ReqHandlerRegistry(ReqHandler defaultHandler) {
        this.defaultHandler = defaultHandler;
    }

    public void register(ReqHandler handler) {
        this.handlerMap.put(handler.getPathInfo(), handler);
    }

    public ReqHandler getHandler(HttpServletRequest request) {
        ReqHandler rh = null;
        String pathInfo = request.getPathInfo();
        if (pathInfo != null) {
            int firstSlashPos = pathInfo.indexOf('/');
            int secondSlashPos = (firstSlashPos > -1) ?
                    pathInfo.indexOf('/', firstSlashPos+1) : -1;


            String key = null;
            if (firstSlashPos > -1) {
                if (secondSlashPos > -1) {
                    key = pathInfo.substring(firstSlashPos+1, secondSlashPos);
                } else {
                    key = pathInfo.substring(firstSlashPos+1);
                }
            } else {
                key = pathInfo;
            }
            if (key != null && key.length() > 0) {
                rh = (ReqHandler) this.handlerMap.get(key);
            }
        }
        return (rh != null) ? rh : this.defaultHandler;
    }
}
