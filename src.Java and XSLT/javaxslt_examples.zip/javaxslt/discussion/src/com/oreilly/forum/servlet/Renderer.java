package com.oreilly.forum.servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * All page renderers must extend from this class.
 */
public abstract class Renderer {
    public abstract void render(HttpServlet servlet,
            HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException;
}
