package com.oreilly.forum.servlet;

import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import com.oreilly.forum.xml.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.jdom.*;

/**
 * Renders a page that shows all messages in a given month.
 */
public class ViewMonthRenderer extends Renderer {

    private BoardSummary board;
    private MonthYear month;

    public ViewMonthRenderer(BoardSummary board, MonthYear month) {
        this.board = board;
        this.month = month;
    }

    public void render(HttpServlet servlet, HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {
        try {
            // convert the data into XML (a JDOM Document)
            Document doc = new Document(ViewMonthJDOM.produceElement(
                    this.board, this.month));

            // apply the appropriate stylesheet
            XSLTRenderHelper.render(servlet, doc,
                    "viewMonth.xslt", response);
        } catch (DataException de) {
            throw new ServletException(de);
        }
    }
}
