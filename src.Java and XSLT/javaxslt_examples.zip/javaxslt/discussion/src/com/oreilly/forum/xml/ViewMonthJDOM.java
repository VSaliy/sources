package com.oreilly.forum.xml;

import java.util.*;
import com.oreilly.forum.*;
import com.oreilly.forum.adapter.*;
import com.oreilly.forum.domain.*;
import org.jdom.*;

/**
 * Creates the JDOM for the month view of a board.
 */
public class ViewMonthJDOM {

    /**
     * @param board the message board to generate JDOM for.
     * @param month the month and year to view.
     */
    public static Element produceElement(BoardSummary board,
            MonthYear month) throws DataException {
        Element viewMonthElem = new Element("viewMonth");
        viewMonthElem.addAttribute("month",
                Integer.toString(month.getMonth()));
        viewMonthElem.addAttribute("year",
                Integer.toString(month.getYear()));

        // create the <board> element...
        Element boardElem = BoardSummaryJDOM.produceNameIDElement(board);
        viewMonthElem.addContent(boardElem);

        DataAdapter adapter = DataAdapter.getInstance();

        MessageTree msgTree = new MessageTree(adapter.getAllMessages(
                board.getID(), month));

        // get an iterator of MessageSummary objects
        Iterator msgs = msgTree.getTopLevelMessages();

        while (msgs.hasNext()) {
            MessageSummary curMsg = (MessageSummary) msgs.next();
            Element elem = produceMessageElement(curMsg, msgTree);
            viewMonthElem.addContent(elem);
        }

        return viewMonthElem;
    }

    /**
     * Produce a fragment of XML for an individual message. This
     * is a recursive function.
     */
    private static Element produceMessageElement(MessageSummary msg,
            MessageTree msgTree) {
        Element msgElem = new Element("message");
        msgElem.addAttribute("id", Long.toString(msg.getID()));
        msgElem.addAttribute("day",
                Integer.toString(msg.getCreateDate().getDay()));

        msgElem.addContent(new Element("subject")
                .setText(msg.getSubject()));
        msgElem.addContent(new Element("authorEmail")
                .setText(msg.getAuthorEmail()));

        Iterator iter = msgTree.getReplies(msg);
        while (iter.hasNext()) {
            MessageSummary curReply = (MessageSummary) iter.next();

            // recursively build the XML for all replies
            msgElem.addContent(produceMessageElement(curReply, msgTree));
        }
        return msgElem;
    }

    private ViewMonthJDOM() {
    }
}
