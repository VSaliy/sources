Examples for "Java and XSLT"
Last updated 02 September 2001
Get the latest updates from http://www.javaxslt.com

This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).

See "exampleList.xml or exampleList.html" for a complete list of examples,
cross referenced with example numbers in the book.

Software Requirements
---------------------
You must install and properly configure the following 
three products:
- Ant 1.3
- Tomcat 4.0
- Java 2 Standard Edition v1.3 or later

Ant is Apache's open source build tool, and can be obtained 
from http://jakarta.apache.org.  You must also download and
install jakarta-ant-1.3-optional.jar as described in the Ant 
documentation. Be sure to set the ANT_HOME environment variable.

Tomcat can be obtained from http://jakarta.apache.org.
Be sure to set the TOMCAT_HOME environment variable.

Compiling the Examples
----------------------
All compilation is done via Apache's Ant build tool. You will
see a file named "build.xml" in the top-level directory. This 
is Ant's equivalent to a Makefile. All Ant commands should
be issued from the command line in the same directory as
build.xml.

To see a list of available build targets, type the following:
  ant -projecthelp

To compile everything, placing results in the 'build' directory:
  ant compile

To compile an individual target, use one of the following:
  ant chap1   (note: no Java code for chaps 2 and 3)
  ant chap4
  ant chap5
  ant chap6
  etc...
  ant forum  (just build the discussion forum, from chapter 7)
  ant common  (just build common code - see the 'common' directory)

To remove the 'build' directory:
  ant clean

Directory Structure
-------------------
javaxslt
  +---examples
        +---chapters
        |     +---chap1
        |     +---chap2
        |     +---chap3
        |     +---chap4
        |     +---chap5
        |     +---chap6
        |     +---...
        +---common
        |     +---src
        |           +---com/oreilly/javaxslt
        |                 +---util
        |
        +---discussion (from chapter 7)
              +---design
              +---docroot
              +---prototype
              +---src
              +---xslt

