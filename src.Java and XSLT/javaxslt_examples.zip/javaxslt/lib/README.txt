This product includes software developed by the
Apache Software Foundation (http://www.apache.org/).

JAR files from the following products are included
in this directory:

File                    Product
----------------------  -------
crimson_1.1.jar         Apache's Crimson XML parser
jaxp_1.1.jar            Sun's Java API for XML Processing
jdom_beta6.jar          JDOM XML API
junit_3.7.jar           JUnit unit testing framework
mm.mysql-2.0.4-bin.jar  MySQL JDBC driver
servlet_2.3.jar         Sun's Servlet API
xalan_2.1.jar           Apache's Xalan XSLT processor


Version numbers are included in the name of each JAR file.

