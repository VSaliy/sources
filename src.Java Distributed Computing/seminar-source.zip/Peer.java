package jdc.patterns.peer;

import jdc.util.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Properties;

public abstract class Peer {
  /**
   * Table of currently connected Peers.
   */
  protected Hashtable mPeers = new Hashtable();

  /**
   * The networked identity of this peer.  Subclasses implementing this
   * abstract class will need to provide a means for initializing this
   * identity, such that the identity is unique in the distributed context.
   */
  protected Identity mIdentity = null;

  /**
   * Default constructor.  Leave identity uninitialized, to indicate
   * no identity.
   */
  public Peer() {}
  
  public Identity getIdentity() {
    return mIdentity;
  }

  public void setIdentity(Identity i) {
    mIdentity = i;
  }
  
  /**
   * Connect to a peer given the connection properties.  The requirements
   * on these properties will depend on the implementation.  A socket-based
   * peer will need to have the host name and port on which the peer is
   * listening.  An RMI-based peer will need the host and registry name of the
   * remote peer object.  The peer will need to initialize the Identity of the
   * remote based on data gleaned from the connection process.
   */
  public abstract boolean connect(Properties connProps);

  /**
   * Connect to a peer given the connection properties and identity of the
   * peer.  Subclasses can choose to implement this using both arguments, or
   * ignoring one in favor of the other (connection properties vs. properties
   * pulled from the remote peer identifier).
   */
  public abstract boolean connect(Properties connProps, Identity peerID);

  /**
   * Send the message to the identified peer.
   */
  public abstract boolean send(Message msg, Identity peer);

  /**
   * Broadcast the message to all currently connected peers.
   */
  public boolean broadcast(Message msg) {
    boolean success = true;
    Enumeration pEnum = getPeers();
    while (pEnum.hasMoreElements()) {
      Peer p = (Peer)pEnum.nextElement();
      if (!send(msg, p.getIdentity())) {
	success = false;
      }
    }
    return success;
  }

  /**
   * Handle an incoming message.
   */
  public abstract void handle(Message m);
  
  /**
   * Add a peer to our list.
   */
  public void addPeer(Peer p) {
    mPeers.put(p.getIdentity(), p);
  }
  
  /**
   * Get the peer identified by the given identity.
   */
  public Peer getPeer(Identity i) {
    return (Peer)mPeers.get(i);
  }

  /**
   * Get list of Peers
   */
  public Enumeration getPeers() {
    return mPeers.elements();
  }
}
