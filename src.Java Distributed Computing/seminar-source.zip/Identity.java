package jdc.util;

import java.util.Hashtable;
import java.util.Enumeration;
import java.io.Serializable;

/**
 * A representation of an agent identity, for general use in distributed
 * computing contexts.  This base class is a simple wrapper around a property
 * list, with an equality method implemented to compare the name and id of two
 * Identities, for purposes of correlating messages from the same agent.
 *
 * Subclasses can extend the interface to provide additional properties or
 * certification tokens.
 *
 * Source code from "Java Distributed Computing", 2nd ed., Jim Farley.
 *
 * Class: Identity
 * Example: ??
 * Description: Representation of an agent identity.
 */

public class Identity implements Serializable {
  protected Hashtable props = new Hashtable();

  public Identity() {};
  public Identity(int id) { props.put("idnum", new Integer(id)); }

  /**
   *  Check the equality of two identities.  In the default case, equality is
   *  based on a comparison of the name and id of the two Identities.
   */
  public boolean equals(Object o) {
    boolean same = true;
    if (o != null && o.getClass() == this.getClass()) {
      Identity oi = (Identity)o;
      Hashtable oProps = oi.props;
      Enumeration keys = this.props.keys();
      while (keys.hasMoreElements()) {
	Object key = keys.nextElement();
	Object prop = this.props.get(key);
	Object oProp = oProps.get(key);
	if ((prop == null && oProp == null) ||
	    (prop != null && oProp != null &&
	     prop.equals(oProp))) {
	  // Do nothing, still equal as far as we know
	}
	else {
	  // Found a non-equal property pair.  Quit here.
	  same = false;
	  break;
	}
      }
    }
    return same;
  }


  public int getId() {
    Integer idNum = (Integer)props.get("idnum");
    if (idNum != null) {
      return idNum.intValue();
    }
    else {
      return -1;
    }
  }

  public String getName() { return (String)props.get("name"); }
  public void setName(String n) { props.put("name", n); }

  public Object getProperty(Object key) {
    return props.get(key);
  }
  public void setProperty(Object key, Object val) {
    props.put(key, val);
  }
}
