package jdc.util;

import java.io.*;

public class Message implements Serializable {
  protected String mId = "";
  protected Object mBody = null;
  
  public Message() {}

  public Message(String id, Object body) {
    mId = id;
    mBody = body;
  }


  public void setBody(Object obj) {
    mBody = obj;
  }
  
  public String getId() {
    return mId;
  }

  public void setId(String id) {
    mId = id;
  }
  public Object getBody() {
    return mBody;
  }
}

