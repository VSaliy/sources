package jdc.patterns.examples;

import jdc.patterns.peer.*;
import jdc.util.*;
import java.util.*;
import java.rmi.*;

public class RMIPeerWrapper {
  public static void main(String argv[]) {
    String name = argv[0];
    RMIPeerImpl me = null;
    try {
      me = new RMIPeerImpl(name);
      System.out.println("Made local peer \"" + name + "\"");
    }
    catch (RemoteException re) {
      System.out.println("Failed to init local peer.");
      re.printStackTrace();
      return;
    }
    String nextHost;
    String nextName;
    Properties cProps;
    for (int i = 1; i < argv.length; i++) {
      nextHost = argv[i];
      if (argv.length > i + 1) {
	i++;
	nextName = argv[i];
	System.out.println("Connecting to remote peer \"" + nextHost +
			   ":" + nextName + "\"");
	cProps = new Properties();
	cProps.put(RMIPeerImpl.HOST_PROP, nextHost);
	cProps.put(RMIPeerImpl.REGNAME_PROP, nextName);
	me.connect(cProps);
      }
    }

    // Now loop, broadcasting a simple message to all peers
    Message msg = new Message("Hello there", "");
    while (true) {
      try {
	System.out.println("Broadcasting \"hello\" message...");
	me.broadcast(msg);
	Thread.sleep(3000);
      }
      catch (Exception e) {
	e.printStackTrace();
      }
    }
  }
}
