package jdc.patterns.peer;

import jdc.util.*;
import java.rmi.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Properties;

public interface RMIPeer extends Remote {

  public Identity getIdentity() throws RemoteException;
  
  /**
   * Handle an incoming message.
   */
  public void handle(Message m, RMIPeer src) throws RemoteException;
  
  /**
   * Add a peer to our list.
   */
  public void addPeer(RMIPeer p) throws RemoteException;
  
  /**
   * Get the peer identified by the given identity.
   */
  public RMIPeer getPeer(Identity i) throws RemoteException;

  /**
   * Get list of Peers
   */
  public Enumeration getPeers() throws RemoteException;

  /**
   * Remove a peer from our list.
   */
  public void removePeer(RMIPeer p) throws RemoteException;
}
