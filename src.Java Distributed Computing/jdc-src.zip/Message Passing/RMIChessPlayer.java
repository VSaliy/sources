package dcj.examples.message;

import java.rmi.RemoteException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMIChessPlayer
 * Example: 6-20
 * Description: Interface for an RMI-based chess player agent.
 */

public interface RMIChessPlayer {
  public boolean acceptMove(RMIChessMove m) throws RemoteException;
  public RMIChessMove nextMove() throws RemoteException;
  public void moveAccepted(RMIChessMove m) throws RemoteException;
  public void conceded() throws RemoteException;
  public boolean gameOver() throws RemoteException;
}