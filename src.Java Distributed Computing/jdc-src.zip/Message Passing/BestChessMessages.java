package dcj.util.message;

import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessMessage, MoveMessage, etc.
 * Example: 6-12
 * Description: Final versions of the chess messages.
 */

abstract class ChessMessage extends Message {
  protected ChessPlayer player;

  public ChessMessage(ChessPlayer p) { player = p; }
  public ChessMessage()              { player = null; }
}

class MoveMessage extends ChessMessage {
  public MoveMessage(ChessPlayer p) {
    super(p);
    setId("move");
  }

  public MoveMessage(String from, String to, int checkFlag) {
    setId("move");
    ChessMove move = new ChessMove(from, to, checkFlag);
    addArg(move);
  }

  public boolean Do() {
    boolean success = true;
    ChessMove move = (ChessMove)argList.elementAt(1);
    String to = move.to();
    String from = move.from();
    int checkFlag = move.checkFlag();

    try {
      if (!player.acceptMove(from, to, checkFlag)) {
        MessageHandler.current.sendMsg(new RejectMoveMessage());
      }
      else {
        ConfirmMoveMessage ccmsg =
          new ConfirmMoveMessage(move);
        MessageHandler.current.sendMsg(ccmsg);

        // We accepted the opponent's move, now send them
        // our counter-move, unless they just mated us...
        if (checkFlag == ChessPlayer.CHECKMATE) {
          ConcedeMessage cmsg = new ConcedeMessage();
          MessageHandler.current.sendMsg(cmsg);
        }
        else {
          player.nextMove(from, to, checkFlag);
          MoveMessage mmsg = new MoveMessage(from, to, checkFlag);
          MessageHandler.current.sendMsg(mmsg);
        }
      }
    }
    catch (IOException e) {
      success = false;
    }

    return success;
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;

    DataInputStream din = new DataInputStream(ins);

    try {
      String temp = din.readUTF();
      if (temp.compareTo("MOBJ") == 0) {
        ObjectInputStream oin = new ObjectInputStream(ins);
        ChessMove move = (ChessMove)oin.readObject();
        addArg(move);
      }
      else {
        String to = din.readUTF();
        int checkFlag = din.readInt();
        ChessMove move = new ChessMove(temp, to, checkFlag);
        addArg(move);
      }

      // Got all of our arguments, now watch for the
      // end-of-message token
      temp = din.readUTF();
      while (temp.compareTo(endToken) != 0) {
        temp = din.readUTF();
      }
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  public boolean writeArgs(OutputStream outs) {
    boolean success = true;
    DataOutputStream dout = new DataOutputStream(outs);
    ObjectOutputStream oout = new ObjectOutputStream(outs);
    ChessMove move = (ChessMove)argList.elementAt(0);

    try {
      dout.writeUTF("MOBJ");
      oout.writeObject(move);
    }
    catch (IOException e) {
      success = false;
    }

    return success;
  }

  public boolean handles(String mid) {
    if (mid.compareTo("move") == 0)
      return true;
    else
      return false;
  }

  public Message newCopy() {
    return(new MoveMessage(player));
  }
}

class ConfirmMoveMessage extends ChessMessage {
  public ConfirmMoveMessage() {
    setId("confirm");
  }

  public ConfirmMoveMessage(String from, String to, int checkFlag) {
    setId("confirm");
    addArg(from);
    addArg(to);
    addArg(new Integer(checkFlag));
  }

  public ConfirmMoveMessage(ChessPlayer p) {
    super(p);
    setId("confirm");
  }

  public boolean Do() {
    // Opponent accepted our last move, so record it on our
    // copy of the game board.
    String from = (String)argList.elementAt(0);
    String to = (String)argList.elementAt(1);
    Integer cmateInt = (Integer)argList.elementAt(2);
    int checkOrMate = cmateInt.intValue();
    player.moveAccepted(from, to, checkOrMate);
    return true;
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;

    DataInputStream din = new DataInputStream(ins);

    try {
      String from = din.readUTF();
      addArg(from);
      String to = din.readUTF();
      addArg(to);
      int checkFlag = din.readInt();
      addArg(new Integer(checkFlag));

      // Got all of our arguments, now watch for the
      // end-of-message token
      String temp = din.readUTF();
      while (temp.compareTo(endToken) != 0) {
        temp = din.readUTF();
      }
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  public boolean writeArgs(OutputStream outs) {
    boolean success = true;
    DataOutputStream dout = new DataOutputStream(outs);
    String from = (String) argList.elementAt(0);
    String to = (String)argList.elementAt(1);
    Integer tmpInt = (Integer)argList.elementAt(2);
    int checkFlag = tmpInt.intValue();

    try {
      dout.writeUTF(from);
      dout.writeUTF(to);
      dout.writeInt(checkFlag);
      dout.writeUTF(endToken);
    }
    catch (IOException e) {
      success = false;
    }

    return success;
  }

  public boolean handles(String mid) {
    if (mid.compareTo("confirm") == 0)
      return true;
    else
      return false;
  }

  public Message newCopy() {
    return(new ConfirmMoveMessage());
  }
}

class RejectMoveMessage extends ChessMessage {
  public RejectMoveMessage() {
    setId("reject");
  }
  public RejectMoveMessage(ChessPlayer p) {
    super(p);
    setId("reject");
  }

  public boolean Do() {
    String newFrom = "";
    String newTo = "";
    int newCheckFlag = ChessPlayer.NO_CHECK;
    boolean success = true;
    MessageHandler handler = MessageHandler.current;

    if (player.nextMove(newFrom, newTo, newCheckFlag)) {
      MoveMessage mmsg = new MoveMessage(player);
      mmsg.addArg(newFrom);
      mmsg.addArg(newTo);
      mmsg.addArg(new Integer(newCheckFlag));
      try {
        handler.sendMsg(mmsg);
      }
      catch (IOException e) {
        success = false;
      }
    }
    else {
      // Our player didn't come up with another move, so
      // concede the game
      try {
        handler.sendMsg(new ConcedeMessage());
      }
      catch (IOException e) {
        success = false;
      }
    }

    return success;
  }

  public boolean handles(String mid) {
    if (mid.compareTo("reject") == 0)
      return true;
    else
      return false;
  }

  public Message newCopy() {
    return(new RejectMoveMessage());
  }
}

class ConcedeMessage extends ChessMessage {
  public ConcedeMessage() {
    setId("concede");
  }

  public ConcedeMessage(ChessPlayer p) {
    super(p);
    setId("concede");
  }

  public boolean Do() {
    player.conceded();
    return true;
  }

  public boolean handles(String mid) {
    if (mid.compareTo("concede") == 0)
      return true;
    else
      return false;
  }

  public Message newCopy() {
    return(new ConcedeMessage());
  }
}
