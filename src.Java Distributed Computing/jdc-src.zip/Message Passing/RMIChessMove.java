package dcj.examples.message;

import java.rmi.RemoteException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMIChessMove
 * Example: 6-18
 * Description: Interface for an RMI-based chess move object.
 */

public interface RMIChessMove {
  public String from() throws RemoteException;
  public void setFrom(String f) throws RemoteException;

  public String to() throws RemoteException;
  public void setTo(String t) throws RemoteException;

  public boolean checkFlag() throws RemoteException;
  public void setCheckFlag(boolean f) throws RemoteException;
}