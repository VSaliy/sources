package dcj.examples.message;

import java.io.Serializable;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessMove
 * Example: 6-8
 * Description: Encapsulation of a chess move.
 */

class ChessMove implements Serializable {
  String fromPos;
  String toPos;
  int checkFlag;

  public ChessMove(String from, String to, int ckFlag) {
    fromPos = from;
    toPos = to;
    checkFlag = ckFlag;
  }

  public String from() {
    return fromPos;
  }

  public String to() {
    return toPos;
  }

  public int checkFlag() {
    return checkFlag;
  }
}