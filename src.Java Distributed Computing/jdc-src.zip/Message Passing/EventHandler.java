package dcj.util.message;

import java.util.EventListener;
import java.util.EventObject;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: EventHandler
 * Example: 6-14
 * Description: An abstraction of an event handler, with a polymorphic
 *      handleEvent() method.
 */
public interface EventHandler extends EventListener {
  public void handleEvent(EventObject e);
}