package dcj.examples.security;

import java.io.*;

public class SecureCreditAgent extends AuthAgent {

  protected ACL creditACL;

  public SecureCreditAgent(String host, int port) {
    super(host, port);
    // Initialize our access control lists
    initACL();
  }

  protected void initACL() {
    creditACL = new ACL();
    // Read resources and access permissions
    // from a database, initialize the ACL object
         .
         .
         .
  }

  protected void processMsg(String msg) {
    String name = null;
    String cmd = null;
    String retMsg = new String();

    // Parse the command and account name from the input stream.
    StreamTokenizer stok = new StreamTokenizer(new StringReader(msg));
    try {
      stok.nextToken();
      cmd = stok.sval;
      name = stok.sval;
    }
    catch (IOException e) {}

    if (cmd.compareTo("GET") == 0) {
      if (isAuthorized(getAgentID(), name, "READ")) {
        String cData = getCreditData(name);
        retMsg = name + " " + cData;
      }
      else {
        retMsg = "UNAUTHORIZED";
      }
    }
    else {
      retMsg = "UNKNOWN_CMD";
    }

    // Add return message with results to the message queue.
    addMsg(retMsg);
  }

  protected String getCreditData(String acctName) {
    // Real method would use account name to
    // initiate a database query...
    return "No info available.";
  }

  protected boolean isAuthorized(Identity agent,
                                 String acctName, String access) {
    boolean auth;
    Permission p = new PermissionImpl(access);
    auth = creditACL.checkPermission(agent, p);
    return auth;
  }
}
