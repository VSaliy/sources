package dcj.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: HeadCmd
 * Example: 1-1
 * Description: A command sent between two agents, used to indicate
 *    the prelude to a communication session.
 */

import java.lang.*;

public class HeadCmd extends SimpleCmd
{
  public HeadCmd(String s) { super(s); }
  public String Do() {
    String result = "Head \"" + arg + "\" processed.\n";
    return result;
  }
}
