package dcj.util.Bandwidth;

import java.util.Vector;
import java.util.Date;
import java.util.Enumeration;

class DataSample {
  long byteCount;
  Date timestamp;

  DataSample(long bc, Date ts) {
    byteCount = bc;
    timestamp = ts;
  }
}

public class DataCounter {
  protected Date epoch;
  protected Vector samples;

  DataCounter() {
    samples = new Vector();
    // By default, assume data flow starts now.
    epoch = new Date();
  }

  // Set start time to specific time.
  public void start(Date e) {
    epoch = e;
  }

  // Set start time to now.
  public void start() {
    epoch = new Date();
  }

  public void addSample(long bcount, Date ts) {
    samples.addElement(new DataSample(bcount, ts));
  }

  public void addSample(long bcount) {
    samples.addElement(new DataSample(bcount, new Date()));
  }

  public float getAverageRate() {
    Enumeration se = samples.elements();
    Date earliest = epoch;
    Date latest = epoch;
    long byteCount = 0;

    while (se.hasMoreElements()) {
      DataSample ds = (DataSample)se.nextElement();
      byteCount += ds.byteCount;
      if (earliest == null || earliest.after(ds.timestamp)) {
        earliest = ds.timestamp;
      }
      if (latest == null || latest.before(ds.timestamp)) {
        latest = ds.timestamp;
      }
    }

    float rate = -1;
    long deltaT = latest.getTime() - earliest.getTime();
    if (deltaT > 0) {
      rate = (float)byteCount / (float)deltaT;
    }

    return rate;
  }
}