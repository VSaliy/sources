package dcj.examples.dbase;

import java.rmi.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMIScheduler
 * Example: 7-12
 * Description: An agent that uses the RMI-based database objects.
 */

public class RMIScheduler {
  public static void main(String argv[]) {
    System.setSecurityManager(new RMISecurityManager());
    try {
      RMISchedDbase dbase =
        (RMISchedDbase)Naming.lookup("//my.server/ScheduleDataServer");
      Vector resources = dbase.getAllResources();
      System.out.println("Got " + resources.size() + " resources.");
    }
    catch (Exception e) {
      System.out.println("Exception: " + e);
      e.printStackTrace();
    }
  }
}