package dcj.examples;

import java.io.*;
import java.net.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: XDRInputStream
 * Example: 2-2
 * Description: An extension of FilterInputStream, intended to
 *      demonstrate a stream intended for reading XDR-formatted
 *      data.
 * NOTE: This file contains incomplete example code only, which will
 *       not compile without additions and modifications.
 */

public abstract class XDRInputStream extends FilterInputStream {
  public XDRInputStream(InputStream in) {
    super(in);
  }

  // Overridden methods from FilterInputStream, implemented
  // to read XDR-formatted data

  abstract public boolean readBoolean() throws IOException;
  abstract public byte    readByte() throws IOException;
  abstract public int     readUnsignedByte() throws IOException;
  abstract public float   readFloat() throws IOException;
  // Other readXXX() methods omitted in this example...

  // We'll assume this stream doesn't support mark/reset operations

  public boolean markSupported() { return false; }
}