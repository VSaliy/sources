package dcj.examples;

import dcj.util.URLClassLoader;

class URLLoaderTest
{
  public static void main(String argv[])
  {
    URLClassLoader loader = new URLClassLoader();
    Class c = null;
    try { c = loader.loadClass(argv[0], true); }
    catch(ClassNotFoundException e)
      {
	System.out.println("URLLoaderTest: Class not found at \"" +
			   argv[0] + "\": " + e);
      }

    // Let's see what we got...
    if (c != null)
      System.out.println("We loaded a class named \"" + c.getName() + "\"");
  }
}