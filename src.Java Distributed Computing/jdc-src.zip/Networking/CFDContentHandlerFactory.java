package dcj.examples.Networking;

import java.net.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: CFDContentHandlerFactory
 * Example: 2-8
 * Description: A content handler factory that supports CFD data files
 *      by offering a CFDContentHandler to deal with them.  This class
 *      should be updated to deal with standard mime types as well.
 */

public class CFDContentHandlerFactory
    implements ContentHandlerFactory {
  public ContentHandler createContentHandler(String mimetype) {
    if (mimetype.compareTo("application/cfd") == 0) {
      return new CFDContentHandler();
    }
    else
      return null;
  }
}