package dcj.examples;

import java.lang.Runnable;
import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RunnableSolver
 * Example: 4-1
 * Description: A Solver that can be run within the body of a separate
 *      thread.
 */

public class RunnableSolver implements Runnable, Solver {
  // Protected implementation variables
  protected ProblemSet currProblem = null;
  protected OutputStream clientOut = null; // Destination for solutions
  protected InputStream clientIn = null;   // Source of problems

  // Constructors
  public RunnableSolver(InputStream cin, OutputStream cout) {
    super();
    clientIn = cin;
    clientOut = cout;
  }

  public boolean solve() {
    boolean success = true;
    SimpleCmdInputStream sin = new SimpleCmdInputStream(clientIn);
    String inStr = null;
    try {
      System.out.println("Reading from client...");
      inStr = sin.readString();
    }
    catch (IOException e) {
      System.out.println("Error reading data from client.");
      return false;
    }

    if (inStr.compareTo("problem") == 0) {
      try {
        inStr = sin.readString();
      }
      catch (IOException e) {
        System.out.println("Error reading data from client.");
        return false;
      }

      System.out.println("Got \"" + inStr + "\" from client.");
      double problem = Double.valueOf(inStr).doubleValue();
      ProblemSet p = new ProblemSet();
      p.setValue(problem);
      success = solve(p, 0);
    }
    else {
      System.out.println("Error reading problem from client.");
      return false;
    }

    return success;
  }

  public boolean solve(ProblemSet s, int iters) {
    boolean success = true;

    if (s == null) {
      System.out.println("No problem to solve.");
      return false;
    }

    System.out.println("Problem value = " + s.getValue());

    // Solve problem here...
    try {
      s.setSolution(Math.sqrt(s.getValue()));
    }
    catch (ArithmeticException e) {
      System.out.println("Badly-formed problem.");
      success = false;
    }

    System.out.println("Problem solution = " + s.getSolution());
    System.out.println("Sending solution to output...");

    // Write the solution to the designated output destination
    try {
      DataOutputStream dout = new DataOutputStream(clientOut);
      dout.writeChars("solution=" + s.getSolution() + "\n");
    }
    catch (IOException e) {
      System.out.println("Error writing results to output.");
      success = false;
    }

    return success;
  }

  public ProblemSet getProblem() {
    return currProblem;
  }

  public void setProblem(ProblemSet s) {
    currProblem = s;
  }

  public void setIterations(int dummy) {
    // Not used on this solver
  }

  public int getIterations() {
    // Not used on this solver
    return 0;
  }

  public void PrintResults(OutputStream os) {
    PrintStream pos = new PrintStream(os);
    pos.println("Problem solution: " + currProblem.getSolution());
  }

  public void run() {
    solve();
  }
}