package dcj.examples;

import java.lang.*;
import java.net.*;
import java.io.*;

public class ThreadedSolverClient extends SimpleClient
{
  ProblemSet problem;
  
  public ThreadedSolverClient(String host, int port, double pval)
  {
    super(host, port);
    problem = new ProblemSet();
    problem.Value(pval);
  }

  public static void main(String argv[])
  {
    if (argv.length < 3)
      {
        System.out.println("Usage: java ThreadedSolverClient [host] [port] [problem]");
        System.exit(1);
      }
    
    String host = argv[0];
    int port = 3000;
    double pval = 0;
    try
      {
        port = Integer.parseInt(argv[1]);
        pval = Double.valueOf(argv[2]).doubleValue();
      }
    catch (NumberFormatException e)
      {}
    
    ThreadedSolverClient client = new ThreadedSolverClient(host, port, pval);
    System.out.println("Attaching client to " + host + ":" + port + "...");
    client.run();
  }
  
  public void run()
  {
    try
      {
        DataOutputStream dout =
          new DataOutputStream(serverConn.getOutputStream());
        DataInputStream din =
          new DataInputStream(serverConn.getInputStream());

        // Send a problem...
        System.out.println("Sending problem to server...");
        dout.writeChars("problem " + problem.Value() + " ");
        // ...and read the solution
        System.out.println("Waiting for solution...");
        String result = din.readLine();
        System.out.println("Server says: \"" + result + "\"");
      }
    catch (IOException e)
      {
        System.out.println("ThreadedSolverClient: " + e);
        System.exit(1);
      }
  }
}
