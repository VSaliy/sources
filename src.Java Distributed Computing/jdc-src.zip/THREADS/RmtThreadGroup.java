package dcj.utils.Thread;

import java.lang.String;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RmtThreadGroup
 * Example: 4-5
 * Description: A utility class used internally by DistThreadGroup to track
 *      remote thread groups.
 */

public class RmtThreadGroup {
  protected String host = "";
  protected int port = 0;

  public RmtThreadGroup() {}

  public RmtThreadGroup(String h, int p) {
    host = h;
    port = p;
  }

  public String getHost() { return host; }
  public int getPort() { return port; }
  public void setHost(String h) { host = h; }
  public void setPort(int p) { port = p; }
}