/*
 * File: ./DCJ/examples/_CORBASolverStub.java
 * From: Solver.idl
 * Date: Sun Jun 15 14:50:46 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public class _CORBASolverStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements DCJ.examples.CORBASolver {

    public _CORBASolverStub(org.omg.CORBA.portable.Delegate d) {
          super(d);
    }

    public static final org.omg.CORBA.portable.OperationDescriptor __ops[] = new org.omg.CORBA.portable.OperationDescriptor[6];

    public static org.omg.CORBA.portable.OperationDescriptor[] _get_operations() {
        return __ops;
    }

    static {
           //       Descriptor for ::DCJ::examples::CORBASolver::_get_curr
           int[] _p0 = {
           0xe
                      };
           Class[] _c0 = {
new DCJ.examples.ProblemSetHolder().getClass()
           };
           {
               __ops[0] = new org.omg.CORBA.portable.OperationDescriptor("_get_curr", _p0, _c0, null, null, false);
           }


           //       Descriptor for ::DCJ::examples::CORBASolver::_set_curr
           int[] _p1 = {
           0xe | 0x40000000                      };
           Class[] _c1 = {
new DCJ.examples.ProblemSetHolder().getClass()
           };
           __ops[1] = new org.omg.CORBA.portable.OperationDescriptor("_set_curr", _p1, _c1, null, null, false);


           //       Descriptor for ::DCJ::examples::CORBASolver::_get_numIterations
           int[] _p2 = {
           0x5
                      };
           Class[] _c2 = {
null
           };
           {
               __ops[2] = new org.omg.CORBA.portable.OperationDescriptor("_get_numIterations", _p2, _c2, null, null, false);
           }


           //       Descriptor for ::DCJ::examples::CORBASolver::_set_numIterations
           int[] _p3 = {
           0x5 | 0x40000000                      };
           Class[] _c3 = {
null
           };
           __ops[3] = new org.omg.CORBA.portable.OperationDescriptor("_set_numIterations", _p3, _c3, null, null, false);


           {
           //      Descriptor for ::DCJ::examples::CORBASolver::create
           int[] _p4 = {
0xe
           };
           Class[] _c4 = {
null
           };
           Class[] _e4 = {

           };
           String[] _exId4 = {

           };
               __ops[4] = new org.omg.CORBA.portable.OperationDescriptor("create", _p4, _c4, _exId4, _e4, false);
           }


           {
           //      Descriptor for ::DCJ::examples::CORBASolver::solve
           int[] _p5 = {
0x8, 0xe | 0xc0000000
           };
           Class[] _c5 = {
null, new DCJ.examples.ProblemSetHolder().getClass()
           };
           Class[] _e5 = {

           };
           String[] _exId5 = {

           };
               __ops[5] = new org.omg.CORBA.portable.OperationDescriptor("solve", _p5, _c5, _exId5, _e5, false);
           }


    }

    private static String _type_ids[] = {
        "IDL:DCJ/examples/CORBASolver:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    //	IDL operations
    //	Implementation of attribute ::curr
    public DCJ.examples.ProblemSet curr() throws org.omg.CORBA.SystemException {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           _invoke(__ops[0], _n, _o);
           return DCJ.examples.ProblemSetHelper.narrow((org.omg.CORBA.Object) _o[0]);
    }
    public void curr(DCJ.examples.ProblemSet arg) throws org.omg.CORBA.SystemException {
           long   _n[] = new long[2];
           java.lang.Object _o[] = new java.lang.Object[2];
           _o[1] = arg;
           _invoke(__ops[1], _n, _o);
    }
    //	Implementation of attribute ::numIterations
    public int numIterations() throws org.omg.CORBA.SystemException {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           _invoke(__ops[2], _n, _o);
           return (int) (_n[0] & 0xFFFFFFFFL);
    }
    public void numIterations(int arg) throws org.omg.CORBA.SystemException {
           long   _n[] = new long[2];
           java.lang.Object _o[] = new java.lang.Object[2];
           _n[1] = (arg & 0xFFFFFFFFL);
           _invoke(__ops[3], _n, _o);
    }
    //	    Implementation of ::DCJ::examples::CORBASolver::create
    public org.omg.CORBA.Object create()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _o[0] = null;
           _e = _invoke(__ops[4], _n, _o);
           return ((org.omg.CORBA.Object) _o[0]);
    }
    //	    Implementation of ::DCJ::examples::CORBASolver::solve
    public boolean solve(DCJ.examples.ProblemSetHolder s)
 {
           long   _n[] = new long[2];
           java.lang.Object _o[] = new java.lang.Object[2];
           java.lang.Object _e;
           _o[0] = s;
           _e = _invoke(__ops[5], _n, _o);
           return (_n[0] == 0) ? false : true;
    }

};
