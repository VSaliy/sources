/*
 * File: ./DCJ/examples/ProblemSet.java
 * From: Solver.idl
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public interface ProblemSet
    extends org.omg.CORBA.Object {
    double getValue()
;
    void setValue(double v)
;
    double getSolution()
;
    void setSolution(double s)
;
}
