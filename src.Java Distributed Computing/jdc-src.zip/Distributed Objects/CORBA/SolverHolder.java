/*
 * File: ./DCJ/examples/SolverHolder.java
 * From: Solver.idl
 * Date: Tue Jun 17 21:50:24 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public final class SolverHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public DCJ.examples.Solver value;
    //	constructors 
    public SolverHolder() {
	this(null);
    }
    public SolverHolder(DCJ.examples.Solver __arg) {
	value = __arg;
    }

    public void __write(org.omg.CORBA.portable.OutputStream out) {
        DCJ.examples.SolverHelper.__write(out, value);
    }

    public void __read(org.omg.CORBA.portable.InputStream in) {
        value = DCJ.examples.SolverHelper.__read(in);
    }

    public org.omg.CORBA.TypeCode __type() {
        return DCJ.examples.SolverHelper.type();
    }
}
