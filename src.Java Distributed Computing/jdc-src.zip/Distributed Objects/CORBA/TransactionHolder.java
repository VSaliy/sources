/*
 * File: ./Examples/TransactionHolder.java
 * From: BankServer.idl
 * Date: Sun Jun 15 14:12:50 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public final class TransactionHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public Examples.Transaction value;
    //	constructors 
    public TransactionHolder() {
	this(null);
    }
    public TransactionHolder(Examples.Transaction __arg) {
	value = __arg;
    }

    public void __write(org.omg.CORBA.portable.OutputStream out) {
        Examples.TransactionHelper.__write(out, value);
    }

    public void __read(org.omg.CORBA.portable.InputStream in) {
        value = Examples.TransactionHelper.__read(in);
    }

    public org.omg.CORBA.TypeCode __type() {
        return Examples.TransactionHelper.type();
    }
}
