/*
 * File: ./Examples/Transaction.java
 * From: BankServer.idl
 * Date: Sun Jun 15 14:12:50 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public interface Transaction
    extends org.omg.CORBA.Object {
    double amount()
;
    boolean isDebit()
;
}
