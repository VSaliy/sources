/*
 * File: ./Examples/BankServer.java
 * From: BankServer.idl
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public interface BankServer
    extends org.omg.CORBA.Object {
    boolean verifyPIN(int acctNo, int pin)
;
    void getAcctSpecifics(int acctNo, String customerName, org.omg.CORBA.DoubleHolder balance, org.omg.CORBA.BooleanHolder isChecking)
;
    boolean processTransaction(Examples.Transaction t, int acctNo)
;
}
