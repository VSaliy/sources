package dcj.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ProblemSet
 * Example: 3-2
 * Description: An over-simplified representation of numerical problem sets.
 */

public class ProblemSet {
  protected double value = 47.0;
  protected double solution = -1.0;

  public double getValue() { return value; }
  public double getSolution() { return solution; }
  public void setValue(double v) { value = v; }
  public void setSolution(double s) { solution = s; }
}
