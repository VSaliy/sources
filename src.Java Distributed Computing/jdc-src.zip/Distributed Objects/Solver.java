package dcj.examples;

import java.io.OutputStream;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: Solver
 * Example: 3-1
 * Description: Base interface for the distributed object examples in the
 *      chapter.
 */

public interface Solver {
  // Solve the current problem set
  public boolean solve();

  // Solve the given problem set
  public boolean solve(ProblemSet s, int numIters);

  // Get/set the current problem set
  public ProblemSet getProblem();
  public void setProblem(ProblemSet s);

  // Get/set the current iteration setting
  public int getIterations();
  public void setIterations(int numIter);
}