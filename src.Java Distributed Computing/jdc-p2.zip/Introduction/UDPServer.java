package dcj.examples;

import java.net.*;

class UDPServer {
    public static void main(String argv[]) {
      try {
        DatagramSocket ds = new DatagramSocket(5000);
        byte[] data = new byte[1024];
        DatagramPacket p = new DatagramPacket(data, 1024);
        ds.receive(p);
        System.out.println("Server got data: " + p.getData());
      }
      catch (Exception e) {
        System.out.println("Server got exception: ");
        e.printStackTrace();
      }
    }
}