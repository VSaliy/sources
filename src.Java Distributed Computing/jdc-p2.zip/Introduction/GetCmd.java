package dcj.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: GetCmd
 * Example: 1-1
 * Description: A command sent between two agents, used to request
 *      something of the receiver.
 */

import java.lang.*;

public class GetCmd extends SimpleCmd
{
  public GetCmd(String s) { super(s); }

  public String Do() {
    String result = arg + " Gotten\n";
    return result;
  }
}
