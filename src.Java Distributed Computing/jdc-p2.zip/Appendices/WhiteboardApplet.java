package dcj.examples.appB;

import java.applet.*;
import java.awt.Color;
import dcj.examples.Collaborative.*;

public class WhiteboardApplet extends Applet {
  private MsgWhiteboardUser wbUser;

  public WhiteboardApplet() {}

  public void init() {
    wbUser = new MsgWhiteboardUser("Fred", new Color(255, 0, 0),
                                   "localhost", 5009);
  }
}