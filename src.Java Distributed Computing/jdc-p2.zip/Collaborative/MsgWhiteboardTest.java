package dcj.examples.Collaborative;

import dcj.util.Collaborative.*;
import java.awt.Color;

public class MsgWhiteboardTest {
  public static void main(String argv[]) {
    String name = argv[0];
    String host = argv[1];
    String port = argv[2];
    int r = Integer.parseInt(argv[3]);
    int g = Integer.parseInt(argv[4]);
    int b = Integer.parseInt(argv[5]);
    Color color = new Color(r, g, b);
    try {
      MsgWhiteboardUser wu = new MsgWhiteboardUser(name, color,
                                             host, Integer.parseInt(port));
      while (true) {}
    }
    catch (Exception e) {}
  }
}