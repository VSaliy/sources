package dcj.examples.Collaborative;

import dcj.util.Collaborative.*;
import java.awt.Color;

public class ThreadWhiteboardTest2 {
  public static void main(String argv[]) {
    String name = argv[0];
    String host = argv[1];
    String mname = argv[2];
    int r = Integer.parseInt(argv[3]);
    int g = Integer.parseInt(argv[4]);
    int b = Integer.parseInt(argv[5]);
    Color color = new Color(r, g, b);
    try {
      ThreadWhiteboardUser2 wu = new ThreadWhiteboardUser2(name, color,
                                             host, mname);
      while (true) {}
    }
    catch (Exception e) {}
  }
}