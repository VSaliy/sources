package dcj.util.Collaborative;

import java.util.Vector;
import java.io.IOException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: Mediator
 * Example: 9-4
 * Description: An interface for a mediator of a remote collaboration.
 */

public interface Mediator {
  public Identity newMember();
  public boolean  remove(Identity i);
  public Vector   getMembers();

  public boolean send(Identity to, Identity from,
                      String mtag, String msg)
      throws IOException;
  public boolean broadcast(Identity from,
                           String mtag, String msg)
      throws IOException;
  public boolean send(Identity to, Identity from,
                      String mtag, Object data)
      throws IOException;
  public boolean broadcast(Identity from,
                         String mtag, Object data)
      throws IOException;
}