package dcj.util.Collaborative;

import java.io.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: MediatorMessage
 * Example: 9-6
 * Description: Subclass of Message that handles messages for our collaboration
 *      framework.
 */

public class MediatorMessage extends Message
{
  protected Mediator mediator = null;

  public MediatorMessage(Mediator m) {
    mediator = m;
  }

  public MediatorMessage(String mid) {
    super(mid);
  }

  public boolean Do()
  {
    boolean success = false;

    try {
      String mtype = messageID();
      if (mtype.compareTo("send") == 0) {
        Identity from = (Identity)getArg(0);
        Identity to = (Identity)getArg(1);
        String tag = (String)getArg(2);
        try {
          String s = (String)getArg(3);
          mediator.send(to, from, tag, s);
          success = true;
        }
        catch (ClassCastException cce) {
          // Argument wasn't a String, so send it as an Object
          Object oarg = getArg(3);
          mediator.send(to, from, tag, oarg);
          success = true;
        }
      }
      else if (mtype.compareTo("broadcast") == 0) {
        System.out.println("mm: Got broadcast message.");
        Identity from = (Identity)getArg(0);
        String tag = (String)getArg(1);
        System.out.println("mm: tag = \"" + tag + "\"");
        try {
          String s = (String)getArg(2);
          mediator.broadcast(from, tag, s);
          success = true;
        }
        catch (ClassCastException cce) {
          Object oarg = getArg(2);
          mediator.broadcast(from, tag, oarg);
        }
      }
    }
    catch (Exception e) {
      success = false;
      System.out.println("mm: Error parsing message.");
      e.printStackTrace();
    }
    return success;
  }

  // We want to handle all messages.
  public boolean handles(String msgId) { return true; }

  public Message newCopy() {
    MediatorMessage copy;
    if (mediator != null) {
      // Make a new MediatorMessage with the same Mediator
      copy = new MediatorMessage(mediator);
      copy.setId(messageID());
    }
    else {
      copy = new MediatorMessage(messageID());
    }
    return copy;
  }
}