package dcj.examples.message;

import java.util.EventObject;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessMoveEvent
 * Example: 6-16
 * Description: A chess move "message" implemented as a Java event.
 */

public class ChessMoveEvent extends EventObject {
  ChessMove move;
  int type;

  public final static int SUBMIT = 0;
  public final static int CONFIRM = 1;
  public final static int REJECT = 2;

  public ChessMoveEvent(ChessMove subject, ChessPlayer src) {
    super(src);
    move = subject;
    type = SUBMIT;
  }

  public int getType() { return type; }

  // Set the type of the move event
  public void setConfirm() { type = CONFIRM; }
  public void setReject() { type = REJECT; }
  public void setSubmit() { type = SUBMIT; }

  // Get and set the move
  public ChessMove getMove() { return move; }
  public void setMove(ChessMove m) { move = m; }
}