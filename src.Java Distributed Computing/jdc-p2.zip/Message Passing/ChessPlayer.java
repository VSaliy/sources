package dcj.examples.message;

import java.io.Serializable;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessPlayer
 * Example: 6-3
 * Description: An class representing a player in a chess game.  The player
 *      maintains its own copy of the board state.
 */

public class ChessPlayer implements Serializable {
  // Data structures for maintaining chess board state
  //             .
  //             .
  //             .

  public static final int CHECK = 0;
  public static final int CHECKMATE = 1;
  public static final int NO_CHECK = 2;

  public ChessPlayer() {
    // Initialize chess board
  }

  public boolean acceptMove(ChessMove m) {
    // Check validity of requested move.
    // If valid, apply to chess board and return true.
    // If invalid, return false.
    //             .
    //             .
    //             .
    return true;
  }

  public ChessMove nextMove() {
    String from = "";
    String to = "";
    int checkFlag = NO_CHECK;

    // Generate our next move based on the current
    // state of the game board...
    //             .
    //             .
    //             .
    return new ChessMove(from, to, checkFlag);
  }

  public void moveAccepted(ChessMove m) {
    // Our move was accepted as valid, apply it to the
    // game board...
    //             .
    //             .
    //             .
  }

  public void conceded() {
    // We've won!
  }
}