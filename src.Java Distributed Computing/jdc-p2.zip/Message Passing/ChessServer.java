package dcj.examples.messageV1;

import java.io.*;
import dcj.examples.message.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessServer
 * Example: 6-5
 * Description: An agent that wraps around a local ChessPlayer and handles the
 *      network communication with the remote opponent.
 */

public class ChessServer extends BasicMsgHandler
{
  ChessPlayer player;

  public ChessServer(InputStream in, OutputStream out) {
    super(in, out);
    player = new ChessPlayer();
  }

  public ChessPlayer getPlayer() {
    return player;
  }

  protected BasicMessage buildMessage(String msgId) {
    BasicMessage msg = null;

    System.out.println("Got message type \"" + msgId + "\"");

    if (msgId.compareTo("move") == 0) {
      msg = new MoveMessage(player);
    }
    else if (msgId.compareTo("confirm") == 0) {
      msg = new ConfirmMoveMessage(player);
    }
    else if (msgId.compareTo("reject") == 0) {
      msg = new RejectMoveMessage(player);
    }
    else if (msgId.compareTo("concede") == 0) {
      msg = new ConcedeMessage(player);
    }

    return msg;
  }
}