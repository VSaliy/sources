package dcj.util.message;

import java.io.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: Message
 * Example: 6-11
 * Description: The final version of the basic message class.
 */

public class Message
{
  protected String id;
  protected Vector argList;
  protected String endToken = "END";

  public Message() {
    id = "message";
    argList = new Vector();
  }

  public Message(String mid) {
    id = mid;
    argList = new Vector();
  }

  public void addArg(Object arg) {
    argList.addElement(arg);
  }

  public String messageID() {
    return id;
  }

  public void setId(String mid) {
    id = mid;
  }

  public Object getArg(int idx) {
    Object arg = null;
    if (idx < argList.size()) {
      arg = argList.elementAt(idx);
    }

    return arg;
  }

  public Vector argList() {
    Vector listCopy = (Vector)argList.clone();
    return listCopy;
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;
    DataInputStream din = new DataInputStream(ins);

    // Read tokens until the "end-of-message" token is seen.
    try {
      String token = din.readUTF();
      while (token.compareTo(endToken) != 0) {
        addArg(token);
        token = din.readUTF();
      }
    }
    catch (IOException e) {
      // Failed to read complete argument list.
      success = false;
    }
    return success;
  }

  public boolean writeArgs(OutputStream outs) {
    int len = argList.size();
    boolean success = true;
    DataOutputStream dout = new DataOutputStream(outs);

    // Write each argument in order
    try {
      for (int i = 0; i < len; i++) {
        String arg = (String)argList.elementAt(i);
        dout.writeUTF(arg);
      }

      // Finish with the end-of-message token
      dout.writeUTF(endToken);
    }
    catch (IOException e) {
      success = false;
    }
    return success;
  }

  public boolean Do() { return false; }
  public boolean handles(String msgId) { return false; }
  public Message newCopy() { return new Message(id); }
}
