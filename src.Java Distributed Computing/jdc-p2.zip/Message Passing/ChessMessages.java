package dcj.examples.messageV1;

import java.io.*;
import dcj.examples.message.ChessPlayer;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Classes: ChessMessage, MoveMessage, ConfirmMoveMessage, RejectMoveMessage,
 *          ConcedeMessage
 * Example: 6-4
 * Description: Subclasses of BasicMessage used to implement the remote
 *      chess game.
 */

abstract class ChessMessage extends BasicMessage {
  protected ChessPlayer player;

  public ChessMessage(ChessPlayer p) { player = p; }
  public ChessMessage()              { player = null; }
}

class MoveMessage extends ChessMessage {
  public MoveMessage(ChessPlayer p) {
    super(p);
    setId("move");
  }

  public MoveMessage(String from, String to, int checkFlag) {
    setId("move");
    addArg(from);
    addArg(to);
    addArg(Integer.toString(checkFlag));
  }

  public boolean Do() {
    boolean success = true;
    BasicMsgHandler handler = BasicMsgHandler.current;

    String from = (String)argList.elementAt(0);
    String to = (String)argList.elementAt(1);
    String checkStr = (String)argList.elementAt(2);
    int checkFlag = Integer.valueOf(checkStr).intValue();

    try {
      if (!player.acceptMove(from, to, checkFlag)) {
        handler.sendMsg(new RejectMoveMessage());
      }
      else {
        ConfirmMoveMessage cmmsg =
          new ConfirmMoveMessage(from, to, checkFlag);
        handler.sendMsg(cmmsg);

        // We accepted the opponent's move, now send them
        // our counter-move, unless they just mated us...
        if (checkFlag == ChessPlayer.CHECKMATE) {
          ConcedeMessage cmsg = new ConcedeMessage();
          handler.sendMsg(cmsg);
        }
        else {
          player.nextMove(from, to, checkFlag);
          MoveMessage mmsg = new MoveMessage(from, to, checkFlag);
          handler.sendMsg(mmsg);
        }
      }
    }
    catch (IOException e) {
      success = false;
    }
    return success;
  }
}

class ConfirmMoveMessage extends ChessMessage {
  public ConfirmMoveMessage(String from, String to, int checkFlag) {
    setId("confirm");
    addArg(from);
    addArg(to);
    addArg(Integer.toString(checkFlag));
  }

  public ConfirmMoveMessage(ChessPlayer p) {
    super(p);
    setId("confirm");
  }

  public boolean Do() {
    boolean success = true;

    // Opponent accepted our last move, so record it on our
    // copy of the game board.
    String from = (String)argList.elementAt(0);
    String to = (String)argList.elementAt(1);
    String cmateStr = (String)argList.elementAt(2);
    int checkOrMate = Integer.valueOf(cmateStr).intValue();
    player.moveAccepted(from, to, checkOrMate);
    return success;
  }
}

class RejectMoveMessage extends ChessMessage {
  public RejectMoveMessage() {
    setId("reject");
  }

  public RejectMoveMessage(ChessPlayer p) {
    super(p);
    setId("reject");
  }

  public boolean Do() {
    boolean success = true;
    String newFrom = "";
    String newTo = "";
    int newCheckFlag = ChessPlayer.NO_CHECK;
    BasicMsgHandler handler = BasicMsgHandler.current;

    try {
      if (player.nextMove(newFrom, newTo, newCheckFlag)) {
        MoveMessage mmsg =
          new MoveMessage(newFrom, newTo, newCheckFlag);
        handler.sendMsg(mmsg);
      }
      else {
        // Our player didn't come up with another move, so
        // concede the game
        handler.sendMsg(new ConcedeMessage());
      }
    }
    catch (IOException e) {
      success = false;
    }

    return success;
  }
}

class ConcedeMessage extends ChessMessage {
  public ConcedeMessage() {
    setId("concede");
  }

  public ConcedeMessage(ChessPlayer p) {
    super(p);
    setId("concede");
  }

  public boolean Do() {
    player.conceded();
    return true;
  }
}