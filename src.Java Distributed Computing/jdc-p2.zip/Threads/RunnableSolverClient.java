package dcj.examples;

import java.lang.*;
import java.net.*;
import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RunnableSolverClient
 * Example: 4-3
 * Description: A client that connects with a RunnableSolverServer and
 *      submits a problem for it to solve.
 */

public class RunnableSolverClient extends SimpleClient {
  ProblemSet problem;

  public RunnableSolverClient(String host, int port, double pval) {
    super(host, port);
    problem = new ProblemSet();
    problem.setValue(pval);
  }

  public static void main(String argv[]) {
    if (argv.length < 3) {
      System.out.println("Usage: java RunnableSolverClient [host] [port] [problem]");
      System.exit(1);
    }

    String host = argv[0];
    int port = 3000;
    double pval = 0;
    try {
      port = Integer.parseInt(argv[1]);
      pval = Double.valueOf(argv[2]).doubleValue();
    }
    catch (NumberFormatException e) {
      System.err.println("Bad port number or problem value given.");
    }

    RunnableSolverClient client = new RunnableSolverClient(host, port, pval);
    System.out.println("Attaching client to " + host + ":" + port + "...");
    client.run();
  }

  public void run() {
    try {
      DataOutputStream dout =
        new DataOutputStream(serverConn.getOutputStream());
      DataInputStream din =
        new DataInputStream(serverConn.getInputStream());

      // Send a problem...
      dout.writeChars("problem " + problem.getValue() + " ");
      // ...and read the solution
      String result = din.readLine();
    }
    catch (IOException e) {
      System.out.println("RunnableSolverClient: " + e);
      System.exit(1);
    }
  }
}