package jen.CORBA;

import org.omg.CORBA.*;
import org.omg.CosNaming.*;

public class DistNaming {
  public static void main(String argv[]) {
    ORB orb = ORB.init(argv, null);
    org.omg.CORBA.Object ref = orb.resolve_initial_references("NamingContext");
    NamingContext localNC = NamingContextHelper.narrow(ref);
    Properties props = new Properties();
    props.put("org.omg.CORBA.ORBInitialHost", "tarazed.hbs.edu");
    props.put("org.omg.CORBA.ORBInitialPort", "31000");
    ORB orb2 = ORB.init((String[])null, props);
    ref = orb2.resolve_initial_references("NamingContext");
    NamingContext remoteNC = NamingContextHelper.narrow(ref);
    NamingComponent root = new NamingComponent("RemoteContexts", "");
    NamingComponent sub = new NamingComponent("Naming1", "");
    NameComponent path[] = {root, sub};
    localNC.rebind(path, remoteNC);
    while ( true ) {
      wait();
    }
  }
}