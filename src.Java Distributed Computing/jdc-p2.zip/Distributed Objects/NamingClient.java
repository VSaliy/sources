package jen.corba;

import org.omg.CORBA.*;
import org.omg.CosNaming.*;

public class NamingClient {
  public static void main(String argv[]) {
    ORB orb = ORB.init(argv, null);
    org.omg.CORBA.Object ref = orb.resolve_initial_references("NamingService");
    NamingContext nameContext = NamingContextHelper.narrow(ref);
    NameComponent topNC = new NameComponent("RemoteContexts", "");
    NameComponent subNC = new NameComponent("Naming1", "");
    NameComponent path[] = {topNC, subNC };
    org.omg.CORBA.Object ref2 = nameContext.resolve(path);
    NamingContext nameContext2 = NamingContextHelper.narrow(ref2);
    System.out.println("Got second naming context...");
  }
}