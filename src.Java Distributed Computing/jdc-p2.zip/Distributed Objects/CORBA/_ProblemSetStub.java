/*
 * File: ./DCJ/examples/_ProblemSetStub.java
 * From: Solver.idl
 * Date: Tue Jun 17 21:50:24 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public class _ProblemSetStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements DCJ.examples.ProblemSet {

    public _ProblemSetStub(org.omg.CORBA.portable.Delegate d) {
          super(d);
    }

    public static final org.omg.CORBA.portable.OperationDescriptor __ops[] = new org.omg.CORBA.portable.OperationDescriptor[4];

    public static org.omg.CORBA.portable.OperationDescriptor[] _get_operations() {
        return __ops;
    }

    static {
           {
           //      Descriptor for ::DCJ::examples::ProblemSet::getValue
           int[] _p0 = {
0x7
           };
           Class[] _c0 = {
null
           };
           Class[] _e0 = {

           };
           String[] _exId0 = {

           };
               __ops[0] = new org.omg.CORBA.portable.OperationDescriptor("getValue", _p0, _c0, _exId0, _e0, false);
           }


           {
           //      Descriptor for ::DCJ::examples::ProblemSet::setValue
           int[] _p1 = {
             0x7 | 0x40000000
           };
           Class[] _c1 = {
             null
           };
           Class[] _e1 = {

           };
           String[] _exId1 = {

           };
               __ops[1] = new org.omg.CORBA.portable.OperationDescriptor("setValue", _p1, _c1, _exId1, _e1, false);
           }


           {
           //      Descriptor for ::DCJ::examples::ProblemSet::getSolution
           int[] _p2 = {
0x7
           };
           Class[] _c2 = {
null
           };
           Class[] _e2 = {

           };
           String[] _exId2 = {

           };
               __ops[2] = new org.omg.CORBA.portable.OperationDescriptor("getSolution", _p2, _c2, _exId2, _e2, false);
           }


           {
           //      Descriptor for ::DCJ::examples::ProblemSet::setSolution
           int[] _p3 = {
             0x7 | 0x40000000
           };
           Class[] _c3 = {
             null
           };
           Class[] _e3 = {

           };
           String[] _exId3 = {

           };
               __ops[3] = new org.omg.CORBA.portable.OperationDescriptor("setSolution", _p3, _c3, _exId3, _e3, false);
           }


    }

    private static String _type_ids[] = {
        "IDL:DCJ/examples/ProblemSet:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    //	IDL operations
    //	    Implementation of ::DCJ::examples::ProblemSet::getValue
    public double getValue()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _e = _invoke(__ops[0], _n, _o);
           return Double.longBitsToDouble(_n[0]);
    }
    //	    Implementation of ::DCJ::examples::ProblemSet::setValue
    public void setValue(double v)
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _n[0] = Double.doubleToLongBits(v);
           _e = _invoke(__ops[1], _n, _o);
    }
    //	    Implementation of ::DCJ::examples::ProblemSet::getSolution
    public double getSolution()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _e = _invoke(__ops[2], _n, _o);
           return Double.longBitsToDouble(_n[0]);
    }
    //	    Implementation of ::DCJ::examples::ProblemSet::setSolution
    public void setSolution(double s)
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _n[0] = Double.doubleToLongBits(s);
           _e = _invoke(__ops[3], _n, _o);
    }

};
