/*
 * File: ./DCJ/examples/CORBASolverHelper.java
 * From: Solver.idl
 * Date: Sun Jun 15 14:50:46 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public final class CORBASolverHelper {
     // It is useless to have instances of this class
     private CORBASolverHelper() { }

    public static void __write(org.omg.CORBA.portable.OutputStream out, DCJ.examples.CORBASolver that) {
        out.write_Object(that);
    }
    public static DCJ.examples.CORBASolver __read(org.omg.CORBA.portable.InputStream in) {
        return DCJ.examples.CORBASolverHelper.narrow(in.read_Object());
    }
   public static DCJ.examples.CORBASolver extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.get_input_stream();
     return __read(in);
   }
   public static void insert(org.omg.CORBA.Any a, DCJ.examples.CORBASolver that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     a.type(type());
     __write(out, that);
     a.read_value(out.get_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "CORBASolver");
      return _tc;
   }
   public static String id() {
       return "IDL:DCJ/examples/CORBASolver:1.0";
   }
   public static boolean _is_a(org.omg.CORBA.Object that)
 {
        if (that == null)
           return true;
	else 
           return that._is_a(id());
   }
   public static DCJ.examples.CORBASolver narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof DCJ.examples.CORBASolver)
            return (DCJ.examples.CORBASolver) that;
	if (!_is_a(that)) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        DCJ.examples.CORBASolver result = new DCJ.examples._CORBASolverStub(dup);
        return result;
   }
}
