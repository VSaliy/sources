/*
 * File: ./Examples/BankServerHolder.java
 * From: BankServer.idl
 * Date: Sun Jun 15 14:12:50 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public final class BankServerHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public Examples.BankServer value;
    //	constructors 
    public BankServerHolder() {
	this(null);
    }
    public BankServerHolder(Examples.BankServer __arg) {
	value = __arg;
    }

    public void __write(org.omg.CORBA.portable.OutputStream out) {
        Examples.BankServerHelper.__write(out, value);
    }

    public void __read(org.omg.CORBA.portable.InputStream in) {
        value = Examples.BankServerHelper.__read(in);
    }

    public org.omg.CORBA.TypeCode __type() {
        return Examples.BankServerHelper.type();
    }
}
