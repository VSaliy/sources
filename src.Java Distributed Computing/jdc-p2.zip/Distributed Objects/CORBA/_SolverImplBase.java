/*
 * File: ./DCJ/examples/_SolverImplBase.java
 * From: Solver.idl
 * Date: Tue Jun 17 21:50:24 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public abstract class _SolverImplBase extends org.omg.CORBA.portable.ObjectImpl implements DCJ.examples.Solver, org.omg.CORBA.portable.Skeleton {
    static private org.omg.CORBA.portable.OperationDescriptor[][] _dispatch_table;
    static {
       _dispatch_table = new org.omg.CORBA.portable.OperationDescriptor[1][0];
       _dispatch_table[0] = DCJ.examples._SolverStub._get_operations();
    }
    public org.omg.CORBA.portable.OperationDescriptor[][] _get_dispatch_table() {
          return _dispatch_table;
    }
    // Constructor
    public _SolverImplBase() {
         super(null);
    }
    // Type strings for this class and its superclases
    private static String _type_ids[] = {
        "IDL:DCJ/examples/Solver:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    // Dispatch call
    public java.lang.Object _execute(int intf, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)
          throws java.lang.Exception {

            return DCJ.examples._SolverImplBase._execute(this, op, n, o, ctx);
    }
    public static java.lang.Object _execute(DCJ.examples.Solver self, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)             throws java.lang.Exception {

        switch (op) {
           case 0: // DCJ.examples.Solver.solveCurrent
                  {
                      boolean __result = self.solveCurrent(
);
                        n[0] = (__result) ? 1 : 0;
                  }
                   break;
           case 1: // DCJ.examples.Solver.solve
                  {
                      boolean __result = self.solve(
                        (DCJ.examples.ProblemSetHolder)o[0],
                        (int) (n[1] & 0xFFFFFFFFL));
                        n[0] = (__result) ? 1 : 0;
                  }
                   break;
           case 2: // DCJ.examples.Solver.getProblem
                  {
                      DCJ.examples.ProblemSet __result = self.getProblem(
);
                        o[0] = __result;
                  }
                   break;
           case 3: // DCJ.examples.Solver.setProblem
                  {
                      self.setProblem(
                        (DCJ.examples.ProblemSetHolder)o[0]);
                  }
                   break;
           case 4: // DCJ.examples.Solver.getNumIterations
                  {
                      int __result = self.getNumIterations(
);
                        n[0] = (__result & 0xFFFFFFFFL);
                  }
                   break;
           case 5: // DCJ.examples.Solver.setNumIterations
                  {
                      self.setNumIterations(
                        (int) (n[0] & 0xFFFFFFFFL));
                  }
                   break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
  }
       return null;
    }
}
