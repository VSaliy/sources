/*
 * File: ./DCJ/examples/ProblemSetHolder.java
 * From: Solver.idl
 * Date: Tue Jun 17 21:50:24 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public final class ProblemSetHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public DCJ.examples.ProblemSet value;
    //	constructors 
    public ProblemSetHolder() {
	this(null);
    }
    public ProblemSetHolder(DCJ.examples.ProblemSet __arg) {
	value = __arg;
    }

    public void __write(org.omg.CORBA.portable.OutputStream out) {
        DCJ.examples.ProblemSetHelper.__write(out, value);
    }

    public void __read(org.omg.CORBA.portable.InputStream in) {
        value = DCJ.examples.ProblemSetHelper.__read(in);
    }

    public org.omg.CORBA.TypeCode __type() {
        return DCJ.examples.ProblemSetHelper.type();
    }
}
