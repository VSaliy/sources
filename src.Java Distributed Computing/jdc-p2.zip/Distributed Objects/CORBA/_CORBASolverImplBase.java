/*
 * File: ./DCJ/examples/_CORBASolverImplBase.java
 * From: Solver.idl
 * Date: Sun Jun 15 14:50:46 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public abstract class _CORBASolverImplBase extends org.omg.CORBA.portable.ObjectImpl implements DCJ.examples.CORBASolver, org.omg.CORBA.portable.Skeleton {
    static private org.omg.CORBA.portable.OperationDescriptor[][] _dispatch_table;
    static {
       _dispatch_table = new org.omg.CORBA.portable.OperationDescriptor[1][0];
       _dispatch_table[0] = DCJ.examples._CORBASolverStub._get_operations();
    }
    public org.omg.CORBA.portable.OperationDescriptor[][] _get_dispatch_table() {
          return _dispatch_table;
    }
    // Constructor
    public _CORBASolverImplBase() {
         super(null);
    }
    // Type strings for this class and its superclases
    private static String _type_ids[] = {
        "IDL:DCJ/examples/CORBASolver:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    // Dispatch call
    public java.lang.Object _execute(int intf, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)
          throws java.lang.Exception {

            return DCJ.examples._CORBASolverImplBase._execute(this, op, n, o, ctx);
    }
    public static java.lang.Object _execute(DCJ.examples.CORBASolver self, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)             throws java.lang.Exception {

        switch (op) {
           case 0: // DCJ.examples.CORBASolver.curr
              {
              DCJ.examples.ProblemSet __result = self.curr();
              o[0] = __result;
              }
                   break;
           case 1: // DCJ.examples.CORBASolver.curr
              self.curr(              (DCJ.examples.ProblemSet)o[1]);
                   break;
           case 2: // DCJ.examples.CORBASolver.numIterations
              {
              int __result = self.numIterations();
              n[0] = (__result & 0xFFFFFFFFL);
              }
                   break;
           case 3: // DCJ.examples.CORBASolver.numIterations
              self.numIterations(              (int) (n[1] & 0xFFFFFFFFL));
                   break;
           case 4: // DCJ.examples.CORBASolver.create
                  {
                      org.omg.CORBA.Object __result = self.create(
);
                        o[0] = __result;
                  }
                   break;
           case 5: // DCJ.examples.CORBASolver.solve
                  {
                      boolean __result = self.solve(
                        (DCJ.examples.ProblemSetHolder)o[0]);
                        n[0] = (__result) ? 1 : 0;
                  }
                   break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
  }
       return null;
    }
}
