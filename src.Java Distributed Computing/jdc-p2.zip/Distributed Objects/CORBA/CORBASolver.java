/*
 * File: ./DCJ/examples/CORBASolver.java
 * From: Solver.idl
 * Date: Sun Jun 15 14:50:46 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public interface CORBASolver
    extends org.omg.CORBA.Object {
    DCJ.examples.ProblemSet curr() throws org.omg.CORBA.SystemException;
    void curr(DCJ.examples.ProblemSet arg) throws org.omg.CORBA.SystemException;
    int numIterations() throws org.omg.CORBA.SystemException;
    void numIterations(int arg) throws org.omg.CORBA.SystemException;
    org.omg.CORBA.Object create()
;
    boolean solve(DCJ.examples.ProblemSetHolder s)
;
}
