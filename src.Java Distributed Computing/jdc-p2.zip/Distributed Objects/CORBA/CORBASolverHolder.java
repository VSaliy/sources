/*
 * File: ./DCJ/examples/CORBASolverHolder.java
 * From: Solver.idl
 * Date: Sun Jun 15 14:50:46 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public final class CORBASolverHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public DCJ.examples.CORBASolver value;
    //	constructors 
    public CORBASolverHolder() {
	this(null);
    }
    public CORBASolverHolder(DCJ.examples.CORBASolver __arg) {
	value = __arg;
    }

    public void __write(org.omg.CORBA.portable.OutputStream out) {
        DCJ.examples.CORBASolverHelper.__write(out, value);
    }

    public void __read(org.omg.CORBA.portable.InputStream in) {
        value = DCJ.examples.CORBASolverHelper.__read(in);
    }

    public org.omg.CORBA.TypeCode __type() {
        return DCJ.examples.CORBASolverHelper.type();
    }
}
