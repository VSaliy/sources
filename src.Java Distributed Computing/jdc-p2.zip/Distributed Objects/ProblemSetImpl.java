package DCJ.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ProblemSetImpl
 * Example: 3-8
 * Description: Implementation of the ProblemSet Java interface generated
 *      by idltojava from the IDL interface from Ex. 3-4.
 */
public class ProblemSetImpl extends _ProblemSetImplBase {
  protected double value;
  protected double solution;

  public double getValue() { return value; }
  public void setValue(double v) { value = v; }
  public double getSolution() { return solution; }
  public void setSolution(double s) { solution = s; }
}