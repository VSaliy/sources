package dcj.examples.security;

import java.io.*;
import java.security.acl.*;
import java.security.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: AuthCreditAgent
 * Example: 5-4
 * Description: The CreditAgent reimplemented to inherit the signature
 *      authentication from AuthAgent, and uses an ACL to control access
 *      to account information.
 * NOTE: This file contains incomplete example code only, which will
 *       not compile without additions and modifications.  At the time of this
 *       writing, a concrete implementations of the Acl and Permission
 *       interfaces are not available in the standard JDK.
 */

public class AuthCreditAgent extends AuthAgent {

  protected Acl creditACL;

  public AuthCreditAgent(String host, int port) {
    super(host, port);
    // Initialize our access control lists
    initACL();
  }

  protected void initACL() {
    creditACL = new Acl();
    // Read resources and access permissions
    // from a database, initialize the ACL object
    //     .
    //     .
    //     .
  }

  protected void processMsg(String msg) {
    String name = null;
    String cmd = null;
    String retMsg = new String();

    // Parse the command and account name from the input stream.
    StreamTokenizer stok = new StreamTokenizer(new StringReader(msg));
    try {
      stok.nextToken();
      cmd = stok.sval;
      name = stok.sval;
    }
    catch (IOException e) {}

    if (cmd.compareTo("GET") == 0) {
      if (isAuthorized(remoteAgent, name, "READ")) {
        String cData = getCreditData(name);
        retMsg = name + " " + cData;
      }
      else {
        retMsg = "UNAUTHORIZED";
      }
    }
    else {
      retMsg = "UNKNOWN_CMD";
    }

    // Add return message with results to the message queue.
    addMsg(retMsg);
  }

  protected String getCreditData(String acctName) {
    // Real method would use account name to
    // initiate a database query...
    return "No info available.";
  }

  protected boolean isAuthorized(Identity agent,
                                 String acctName, String access) {
    boolean auth;
    java.security.acl.Permission p = new PermissionImpl(access);
    auth = creditACL.checkPermission(agent, p);
    return auth;
  }
}