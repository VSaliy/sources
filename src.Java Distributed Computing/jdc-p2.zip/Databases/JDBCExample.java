package dcj.examples.dbase;

import java.lang.*;
import java.sql.*;

class JDBCExample {
  public static void main(String argv[]) {
    // Construct the database address
    String dbaseURL = "jdbc:mysubprotocol://dbasehost/dbasename";
    // Make the database connection
    Connection dbConnection = null;
    Statement query = null;
    try {
      dbConnection =
        DriverManager.getConnection(dbaseURL, "dbaseuser", "dbasepasswd");
      // Create a statement and execute the SQL query
      query = dbConnection.createStatement();
    }
    catch (SQLException e) {
      System.out.println("Error connecting to dbase.");
      System.exit(1);
    }

    ResultSet results = null;
    try {
      results =
        query.executeQuery("SELECT user_fname, user_lname from user_table");

      // Iterate through the results and print them to standard output
      while (results.next()) {
        String fname = results.getString("user_fname");
        String lname = results.getString("user_lname");
        System.out.println("Found user \"" + fname + " " + lname + "\"");
      }
    }
    catch (SQLException e) {
      System.out.println("Error retrieving data from database.");
      System.exit(1);
    }
  }
}
