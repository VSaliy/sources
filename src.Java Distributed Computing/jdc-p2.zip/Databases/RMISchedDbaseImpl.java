package dcj.examples.dbase;

import java.util.Vector;
import java.util.Date;
import java.sql.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: SchedDbaseImpl
 * Example: 7-11
 * Description: Server implementation of the "factory" object.
 */

class SchedDbaseImpl extends UnicastRemoteObject
                     implements RMISchedDbase {

  public SchedDbaseImpl() throws RemoteException { super(); }

  // Main method registers a SchedDbaseImpl object with the
  // local RMI naming service, using the first command-line
  // argument as the name of the service, and the second as
  // the URL for the JDBC connection.
  public static void main(String argv[]) {
    System.setSecurityManager(new RMISecurityManager());

    try {
      String name = argv[0];
      System.out.println("Registering SchedDbaseImpl with "
                         + "naming service as " + name);
      SchedDbaseImpl server = new SchedDbaseImpl();
      Class.forName("oracle.jdbc.driver.OracleDriver");
      DatabaseItemImpl.dbConn =
        DriverManager.getConnection("jdbc:oracle:thin:@dbaseserver:1521:mydb",
                                    "user", "passwd");
      Registry r = LocateRegistry.getRegistry(1234);
      r.rebind(name, server);
      System.out.println(name + " ready.");
    }
    catch (Exception e) {
      System.out.println("Exception while registering "
                         + "SchedDbaseImpl: \n");
      e.printStackTrace();
      System.exit(2);
    }
  }

    // Methods for creating/retrieving resources
  public RMISchedResource getResource(int rid)
                            throws RemoteException {
    SchedResourceImpl res = new SchedResourceImpl(rid);
    return res;
  }

  public RMISchedResource newResource(String n, int t, float s)
                            throws RemoteException {
    SchedResourceImpl res = new SchedResourceImpl(n, t, s);
    return res;
  }

  public Vector getAllResources() throws RemoteException {
    Vector resList = new Vector();
    try {
      Statement s = DatabaseItemImpl.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT distinct(rid) FROM resource");
      while (r.next()) {
        int id = r.getInt("rid");
        SchedResourceImpl res = new SchedResourceImpl(id);
        if (res.isValid()) {
          resList.addElement(res);
        }
      }
    }
    catch (Exception e) {}

    return resList;
  }

  // Methods for creating/retrieving tasks
  public RMISchedTask getTask(int id) throws RemoteException {
    SchedTaskImpl task = new SchedTaskImpl(id);
    return task;
  }

  public RMISchedTask newTask(int t, float sz)
                        throws RemoteException {
    SchedTaskImpl task = new SchedTaskImpl(t, sz);
    return task;
  }

  public Vector getAllTasks() throws RemoteException {
    Vector taskList = new Vector();
    try {
      Statement s = DatabaseItemImpl.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT distinct(tid) FROM task");
      while (r.next()) {
        int id = r.getInt("tid");
        SchedTaskImpl task = new SchedTaskImpl(id);
        if (task.isValid()) {
          taskList.addElement(task);
        }
      }
    }
    catch (Exception e) {}

    return taskList;
  }

  // Methods for creating/retrieving constraints
  public RMITimeConstraint newConstraint(int type, int t1, int t2)
                             throws RemoteException {
    TimeConstraintImpl c = new TimeConstraintImpl(type, t1, t2);

    // Create a new record in the database.
    try {
      Statement s = DatabaseItemImpl.dbConn.createStatement();
      int numr = s.executeUpdate("INSERT time_constraint SET type = "
                                 + type + " task1 = " + t1
                                 + " task2 = " + t2);
      if (numr != 1)
        c.valid = false;
      else
        c.valid = true;
    }
    catch (SQLException e) {
      c.valid = false;
    }

    return c;
  }

  public Vector constraintsFor(int tid) throws RemoteException {
    Vector constraints = new Vector();

    try {
      Statement s = DatabaseItemImpl.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT task1, task2, type FROM "
                                   + "time_constraint where task1 = "
                                   + tid + " or task2 = " + tid);
      while (r.next()) {
        int tid1 = r.getInt("task1");
        int tid2 = r.getInt("task2");
        int type = r.getInt("type");
        TimeConstraintImpl c = new TimeConstraintImpl(type, tid1, tid2);
        constraints.addElement(c);
      }
    }
    catch (Exception e) {}

    return constraints;
  }

  // Methods for creating/retrieving resource assignments
  public RMIResAssignment newResAssignment(int rid, int tid,
                                           Date time)
                            throws RemoteException {
    ResAssignmentImpl r = new ResAssignmentImpl(rid, tid, time);

    // Create a new record in the database.
    try {
      Statement s = DatabaseItemImpl.dbConn.createStatement();
      int numr = s.executeUpdate("INSERT res_assignment SET resource = "
                                 + rid + " task = " + tid
                                 + " time = " + time);
      if (numr != 1)
        r.valid = false;
      else
        r.valid = true;
    }
    catch (SQLException e) {
      r.valid = false;
    }

    return r;
  }

  public Vector assignmentsFor(int rid) throws RemoteException {
    Vector ras = new Vector();

    try {
      Statement s = DatabaseItemImpl.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT task, time FROM "
                                   + "res_assignment where resource = "
                                   + rid);
      while (r.next()) {
        int tid = r.getInt("task");
        Date time = r.getDate("time");
        ResAssignmentImpl ra = new ResAssignmentImpl(rid, tid, time);
        ras.addElement(ra);
      }
    }
    catch (Exception e) {}

    return ras;
  }
}
