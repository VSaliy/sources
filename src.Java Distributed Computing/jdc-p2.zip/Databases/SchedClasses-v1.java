package dcj.examples.dbase;

import java.sql.*;
import java.util.Vector;

abstract class SchedDbaseItem {
  static Connection dbConn;
  boolean valid;

  public boolean isValid() { return valid; }

  protected abstract boolean updateToDbase();
  protected abstract boolean updateFromDbase();
}

class SchedResource extends SchedDbaseItem {
  int rid;
  String name;
  int type;
  float size;

  public SchedResource(int id) {
    rid = id;
    valid = updateFromDbase();
  }

  public SchedResource(String n, int t, float s) {
    // How is ID generated?
    try {
      Statement st = SchedDbaseItem.dbConn.createStatement();
      int rcnt = st.executeUpdate("INSERT INTO resource "
                   + "(rid, name, type, size) VALUES "
                   + "(ridSeq.nextVal, " + n + ", "
                   + t + ", " + s + ")");
      if (rcnt == 1)
        valid = true;
      else
        valid = false;
    }
    catch (SQLException e) {
      valid = false;
    }
  }

  public int    getId()           { return rid; }

  public String getName()         { return name; }
  public void   setName(String n) { name = n; updateToDbase(); }

  public int    getType()         { return type; }
  public void   setType(int t)    { type = t; updateToDbase(); }

  public float  getSize()         { return size; }
  public void   setSize(float s)  { size = s; updateToDbase(); }

  public boolean updateFromDbase() {
    boolean success = true;

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT name, type, size FROM resource WHERE rid = "
                       + rid);
      if (r.next()) {
        name = r.getString("name");
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() {
    boolean success = true;

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE resource SET name = " + name
                                 + " type = " + type + " size = " + size
                                 + " WHERE rid = " + rid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }

  static public Vector getAllResources() {
    Vector resList = new Vector();
    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT distinct(rid) FROM resource");
      while (r.next()) {
        int id = r.getInt("rid");
        SchedResource res = new SchedResource(id);
        if (res.isValid()) {
          resList.addElement(res);
        }
      }
    }
    catch (Exception e) {};

    return resList;
  }
}

class SchedTask extends SchedDbaseItem {
  int tid;
  int type;
  float size;

  SchedTask(int id) {
    tid = id;
    valid = updateFromDbase();
  }

  SchedTask(int t, float sz) {
    type = t;
    size = sz;
    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      int cnt = s.executeUpdate("INSERT INTO task (tid, type, size) "
                  + "VALUES (tidSeq.nextVal, " + type + ", "
                  + size + ")");
      if (cnt < 1) {
        valid = false;
      }
      else {
        valid = true;
      }
    }
    catch (SQLException e) {
      valid = false;
    }
  }

  public int    getId()           { return tid; }

  public int    getType()         { return type; }
  public void   setType(int t)    { type = t; }

  public float  getSize()         { return size; }
  public void   setSize(float s)  { size = s; }

  public boolean updateFromDbase() {
    boolean success = true;

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT type, size FROM task WHERE tid = "
                       + tid);
      if (r.next()) {
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() {
    boolean success = true;

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE task SET type = "
                                 + type + ", size = " + size
                                 + " WHERE tid = " + tid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }

  static public Vector getAllTasks() {
    Vector taskList = new Vector();

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT distinct(tid) FROM task");
      while (r.next()) {
        int id = r.getInt("tid");
        SchedTask task = new SchedTask(id);
        if (task.isValid()) {
          taskList.addElement(task);
        }
      }
    }
    catch (Exception e) {}

    return taskList;
  }
}

class TimeConstraint extends SchedDbaseItem {
  int ctype;
  int task1;
  int task2;

  // This constructor is used to create a representation
  // of a constraint in the database.
  public TimeConstraint(int type, int tid1, int tid2,
                        boolean insert) {
    ctype = type;
    task1 = tid1;
    task2 = tid2;

    if (insert) {
      // Create a new record in the database.
      try {
        Statement s = SchedDbaseItem.dbConn.createStatement();
        int numr = s.executeUpdate("INSERT INTO time_constraint "
                     + "(type, task1, task2) VALUES ("
                     + type + ", " + task1 + ", " + task2 + ")");
        if (numr != 1)
          valid = false;
        else
          valid = true;
      }
      catch (SQLException e) {
        valid = false;
      }
    }
  }

  public int getTask1Id() { return task1; }
  public int getTask2Id() { return task2; }
  public int getType() { return ctype; }

  static public Vector constraintsFor(int tid) {
    Vector constraints = new Vector();

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT task1, task2, type FROM "
                                   + "time_constraint where task1 = "
                                   + tid + " or task2 = " + tid);
      while (r.next()) {
        int tid1 = r.getInt("task1");
        int tid2 = r.getInt("task2");
        int type = r.getInt("type");
        TimeConstraint c = new TimeConstraint(type, tid1, tid2,
                                              false);
        constraints.addElement(c);
      }
    }
    catch (Exception e) {}

    return constraints;
  }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() { return false; }
  public boolean updateToDbase() { return false; }
}

class ResAssignment extends SchedDbaseItem {
  int rid;
  int tid;
  Date timestamp;

  ResAssignment(int res, int task, Date time, boolean insert) {
    rid = res;
    tid = task;
    timestamp = time;

    if (insert) {
      // Create a new record in the database.
      try {
        Statement s = SchedDbaseItem.dbConn.createStatement();
        int numr = s.executeUpdate("INSERT INTO res_assignment "
                     + " (resource, task, time) VALUES ("
                     + rid + ", " + tid + ", " + time + ")");
        if (numr != 1)
          valid = false;
        else
          valid = true;
      }
      catch (SQLException e) {
        valid = false;
      }
    }
  }

  public int  getResourceId() { return rid; }
  public int  getTaskId() { return tid; }
  public Date getTimeStamp() { return timestamp; }

  static public Vector assignmentsFor(int rid) {
    Vector ras = new Vector();

    try {
      Statement s = SchedDbaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT task, time FROM "
                                   + "res_assignment where resource = "
                                   + rid);
      while (r.next()) {
        int tid = r.getInt("task");
        Date time = r.getDate("time");
        ResAssignment ra = new ResAssignment(rid, tid, time,
                                             false);
        ras.addElement(ra);
      }
    }
    catch (Exception e) {}

    return ras;
  }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() { return false; }
  public boolean updateToDbase() { return false; }
}
