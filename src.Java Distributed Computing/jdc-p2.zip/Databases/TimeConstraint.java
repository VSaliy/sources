package dcj.examples.dbase;

import java.sql.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: TimeConstraint
 * Example: 7-5
 * Description: Data pertaining to a temporal constraint between two tasks.
 */

class TimeConstraint extends DatabaseItem {
  int ctype;
  int task1;
  int task2;

  // This constructor is used to create a representation
  // of a constraint in the database.
  public TimeConstraint(int type, int tid1, int tid2,
                        boolean insert) {
    ctype = type;
    task1 = tid1;
    task2 = tid2;

    if (insert) {
      // Create a new record in the database.
      try {
        Statement s = DatabaseItem.dbConn.createStatement();
        int numr = s.executeUpdate("INSERT INTO time_constraint "
                     + "(type, task1, task2) VALUES ("
                     + type + ", " + task1 + ", " + task2 + ")");
        if (numr != 1)
          valid = false;
        else
          valid = true;
      }
      catch (SQLException e) {
        valid = false;
      }
    }
  }

  public int getTask1Id() { return task1; }
  public int getTask2Id() { return task2; }
  public int getType() { return ctype; }

  static public Vector constraintsFor(int tid) {
    Vector constraints = new Vector();

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT task1, task2, type FROM "
                                   + "time_constraint where task1 = "
                                   + tid + " or task2 = " + tid);
      while (r.next()) {
        int tid1 = r.getInt("task1");
        int tid2 = r.getInt("task2");
        int type = r.getInt("type");
        TimeConstraint c = new TimeConstraint(type, tid1, tid2,
                                              false);
        constraints.addElement(c);
      }
    }
    catch (Exception e) {}

    return constraints;
  }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() { return false; }
  public boolean updateToDbase() { return false; }
}