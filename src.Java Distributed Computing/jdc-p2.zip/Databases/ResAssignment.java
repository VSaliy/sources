package dcj.examples.dbase;

import java.sql.*;
import java.util.Vector;
import java.util.Date;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ResAssignment
 * Example: 7-6
 * Description: Data pertaining to an assignment of a task to a resource.
 */

class ResAssignment extends DatabaseItem {
  int rid;
  int tid;
  Date timestamp;

  ResAssignment(int res, int task, Date time, boolean insert) {
    rid = res;
    tid = task;
    timestamp = time;

    if (insert) {
      // Create a new record in the database.
      try {
        Statement s = DatabaseItem.dbConn.createStatement();
        int numr = s.executeUpdate("INSERT INTO res_assignment "
                     + " (resource, task, time) VALUES ("
                     + rid + ", " + tid + ", " + time + ")");
        if (numr != 1)
          valid = false;
        else
          valid = true;
      }
      catch (SQLException e) {
        valid = false;
      }
    }
  }

  public int  getResourceId() { return rid; }
  public int  getTaskId() { return tid; }
  public Date getTimeStamp() { return timestamp; }

  static public Vector assignmentsFor(int rid) {
    Vector ras = new Vector();

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT task, time FROM "
                                   + "res_assignment where resource = "
                                   + rid);
      while (r.next()) {
        int tid = r.getInt("task");
        Date time = r.getDate("time");
        ResAssignment ra = new ResAssignment(rid, tid, time,
                                             false);
        ras.addElement(ra);
      }
    }
    catch (Exception e) {}

    return ras;
  }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() { return false; }
  public boolean updateToDbase() { return false; }
}