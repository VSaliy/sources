package dcj.examples;

import dcj.examples.XDRInputStream;
import java.net.*;
import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: XDRInputExample
 * Example: 2-3
 * Description: A client program that uses an XDRInputStream.
 * NOTE: This file contains incomplete example code only, which will
 *       not compile without additions and modifications.
 */

class XDRInputExample {
  public static void main(String argv[]) {
    String host = argv[0];

    // Default port is 5001
    int port = 5001;

    try {
      port = Integer.parseInt(argv[1]);
    }
    catch (NumberFormatException e) {
      System.out.println("Bad port number given, using default "
                         + port);
    }

    // Try connecting to specified host and port
    Socket serverConn = null;
    try { serverConn = new Socket(host, port); }
    catch (UnknownHostException uhe) {
      System.out.println("Bad host name given.");
      System.exit(1);
    }
    catch (Exception e) {
      System.out.println("Error opening socket:");
      e.printStackTrace();
    }

    try {
      // Wrap an XDR stream around the input stream
      XDRInputStream xin = new XDRInputStream(serverConn.getInputStream());

      // Start reading expected data from XDR-formatted stream
      int numVals = xin.readInt();
      float val1 = xin.readFloat();
      //  . . .
    }
    catch (IOException ioe) {
      System.out.println("Error getting stream from socket.");
    }

  }
}