package dcj.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: PostCmd
 * Example: 1-1
 * Description: A command sent between two agents, used to post
 *      data from the sender to the receiver.
 */

import java.lang.*;

public class PostCmd extends SimpleCmd
{
  public PostCmd(String s) { super(s); }

  public String Do() {
    String result = arg + " Posted\n";
    return result;
  }
}
