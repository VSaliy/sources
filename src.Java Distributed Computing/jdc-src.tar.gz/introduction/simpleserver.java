package dcj.examples;

import java.net.*;
import java.io.*;
import java.lang.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: SimpleServer
 * Example: 1-4
 * Description: A server that listens on a port and accepts
 *      connections from any clients it finds. Once a connection is
 *      made, communication takes place using the simple command
 *      protocol defined in earlier examples. This can be made to
 *      extend thread, so that an application can have multiple
 *      server threads servicing several ports, if necessary.
 */

public class SimpleServer {
  protected int portNo = 3000; // Port to listen to for clients (default=3000)
  protected ServerSocket clientConnect;

  public SimpleServer(int port) throws IllegalArgumentException {
    if (port <= 0)
      throw new IllegalArgumentException(
                  "Bad port number given to SimpleServer constructor.");

    // Try making a ServerSocket to the given port
    System.out.println("Connecting server socket to port...");
    try { clientConnect = new ServerSocket(port); }
    catch (IOException e) {
      System.out.println("Failed to connect to port " + port);
      System.exit(1);
    }

    // Made the connection, so set the local port number
    this.portNo = port;
  }

  public static void main(String argv[]) {
    int port = 3000;
    if (argv.length > 0) {
      int tmp = port;
      try {
        tmp = Integer.parseInt(argv[0]);
      }
      catch (NumberFormatException e) {}

      port = tmp;
    }

    SimpleServer server = new SimpleServer(port);
    System.out.println("SimpleServer running on port " + port + "...");
    server.listen();
  }

  public void listen() {
    // Listen to port for client connection requests.
    try {
      System.out.println("Waiting for clients...");
      while (true) {
        Socket clientReq = clientConnect.accept();
        System.out.println("Got a client...");
        serviceClient(clientReq);
      }
    }
    catch (IOException e) {
      System.out.println("IO exception while listening for clients.");
      System.exit(1);
    }
  }

  public void serviceClient(Socket clientConn) {
    SimpleCmdInputStream inStream = null;
    DataOutputStream outStream = null;
    try {
      inStream = new SimpleCmdInputStream(clientConn.getInputStream());
      outStream = new DataOutputStream(clientConn.getOutputStream());
    }
    catch (IOException e) {
      System.out.println("SimpleServer: Error getting I/O streams.");
    }

    SimpleCmd cmd = null;
    System.out.println("Attempting to read commands...");
    while (cmd == null ||
           cmd.getClass().getName().compareTo("dcj.examples.DoneCmd") != 0) {
      try { cmd = inStream.readCommand(); }
      catch (IOException e) {
        System.out.println("SimpleServer: " + e);
        System.exit(1);
      }

      if (cmd != null) {
        String result = cmd.Do();
        try { outStream.writeBytes(result); }
        catch (IOException e) {
          System.out.println("SimpleServer: " + e);
          System.exit(1);
        }
      }
    }
  }

  public synchronized void finalize() {
    System.out.println("Shutting down SimpleServer running on port "
                       + portNo);
  }
}