package dcj.examples;
/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: DoneCmd
 * Example: 1-1
 * Description: A command sent between two agents, used to indicate
 *    that an interactive session is finished.
 */

class DoneCmd extends SimpleCmd
{
  public DoneCmd() { super(""); };

  public String Do() {
    String result = "All done.\n";
    return result;
  }
}