package dcj.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: SimpleCmdInputStream
 * Example: 1-2
 * Description: An extension of DataInputStream, used to read
 *      commands from another agent through a stream interface.
 *      The underlying stream could be a piped stream connected to
 *      another thread, or the input stream from a socket
 *      connection, etc.
 */

import java.lang.*;
import java.io.*;
import java.net.*;


public class SimpleCmdInputStream extends DataInputStream
{
  public SimpleCmdInputStream(InputStream in) {
    super(in);
  }

  public String readString() throws IOException {
    StringBuffer strBuf = new StringBuffer();
    boolean hitSpace = false;
    while (!hitSpace) {
      char c = readChar();
      hitSpace = Character.isSpace(c);
      if (!hitSpace)
        strBuf.append(c);
    }

    String str = new String(strBuf);
    return str;
  }

  public SimpleCmd readCommand() throws IOException {
    SimpleCmd cmd;
    String commStr = readString();
    if (commStr.compareTo("HEAD") == 0)
      cmd = new HeadCmd(readString());
    else if (commStr.compareTo("GET") == 0)
      cmd = new GetCmd(readString());
    else if (commStr.compareTo("POST") == 0)
      cmd = new PostCmd(readString());
    else if (commStr.compareTo("DONE") == 0)
      cmd = new DoneCmd();
    else
      throw new IOException("Unknown command.");

    return cmd;
  }
}
