package dcj.examples;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: SimpleCmd
 * Example: 1-1
 * Description: Base class for commands in a message-based
 *      communication protocol.  Subclasses are defined to
 *      represent specifics command types defining a particular
 *      protocol.
 */

public abstract class SimpleCmd
{
  protected String arg;

  public SimpleCmd(String inArg) {
    arg = inArg;
  }

  public abstract String Do();
}
