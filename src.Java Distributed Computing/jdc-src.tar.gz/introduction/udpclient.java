package dcj.examples;

import java.net.*;
import java.io.OutputStream;

class UDPClient {
    public static void main(String argv[]) {
      try {
        DatagramSocket s = new DatagramSocket();
        byte[] data = "Hello".getBytes();
        InetAddress addr = InetAddress.getByName("localhost");
        DatagramPacket p = new DatagramPacket(data, data.length, addr, 5000);
        s.send(p);
      }
      catch (Exception e) {
        System.out.println("Client got exception:");
        e.printStackTrace();
      }
    }
}