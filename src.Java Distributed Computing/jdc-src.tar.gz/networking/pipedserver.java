package dcj.examples;

import java.lang.*;
import java.net.*;
import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: PipedServer
 * Example: 2-5
 * Description: The other end of a piped connection between two
 *      threads.
 */

public class PipedServer extends Thread {
  PipedInputStream pin;
  PipedOutputStream pout;

  public PipedServer(PipedInputStream in, PipedOutputStream out) {
    pin = in;
    pout = out;
  }

  public void run() {
    // Wrap a data stream around the input and output streams
    DataInputStream din = new DataInputStream(pin);
    DataOutputStream dout = new DataOutputStream(pout);

    // Wait for the client to say hello...
    try {
        System.out.println("PipedServer: Reading from client...");
        String clientHello = din.readLine();
        System.out.println("PipedServer: Client said: \""
                           + clientHello + "\"");
      }
    catch (IOException e)
      {
        System.out.println("PipedServer: Couldn't get hello from client.");
        stop();
      }

    // ...and say hello back.
    try
      {
        System.out.println("PipedServer: Writing response to client...");
        dout.writeChars("hello I am the server.\n");
      }
    catch (IOException e)
      {
        System.out.println("PipedServer: Failed to connect to client.");
      }
    stop();
  }
}