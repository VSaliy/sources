package dcj.examples;

import java.lang.*;
import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: PipedClient
 * Example: 2-4
 * Description: One end of a piped connection between two threads.
 */

public class PipedClient extends Thread
{
  PipedInputStream pin;
  PipedOutputStream pout;

  public PipedClient(PipedInputStream in, PipedOutputStream out)
  {
    pin = in;
    pout = out;
  }

  public void run()
  {
    // Wrap a data stream around the input and output streams
    DataInputStream din = new DataInputStream(pin);
    DataOutputStream dout = new DataOutputStream(pout);

    // Say hello to the server...
    try
      {
        System.out.println("PipedClient: Writing greeting to server...");
        dout.writeChars("hello from PipedClient\n");
      }
    catch (IOException e)
      {
        System.out.println("PipedClient: Couldn't get response.");
        System.exit(1);
      }

    // See if it says hello back...
    try
      {
        System.out.println("PipedClient: Reading response from server...");
        String response = din.readLine();
        System.out.println("PipedClient: Server said: \""
                           + response + "\"");
      }
    catch (IOException e)
      {
        System.out.println("PipedClient: Failed to connect to peer.");
      }

    stop();
  }
}