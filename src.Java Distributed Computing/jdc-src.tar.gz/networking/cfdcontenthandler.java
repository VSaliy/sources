import java.net.*;
import dcj.examples.Networking.CFDDataSet;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: CFDContentHandler
 * Example: 2-7
 * Description: A content handler that can deal with hypothetical CFD
 *       data files.
 * NOTE: This file contains incomplete example code only, which will
 *       not compile without additions and modifications.
 */

public class CFDContentHandler extends ContentHandler {
  public Object getContent(URLConnection u) {
    CFDDataSet d = new CFDDataSet();
    try {
      InputStream in = u.getInputStream();
      byte[] buffer = new byte[1024];
      while (in.read(buffer) > 0) {
        d.addData(buffer);
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    return d;
  }
}