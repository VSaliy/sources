package dcj.examples.security;

import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: CreditAgent
 * Example: 5-2
 * Description: An extension of SimpleAgent that provides credit information
 *      for named accounts.
 */

public class CreditAgent extends SimpleAgent {
  public CreditAgent(String host, int port) {
    super(host, port);
  }

  protected void processMsg(String msg) {
    String name = null;
    String cmd = null;
    String retMsg = new String();

    // Parse the command and account name from the input stream.
    StreamTokenizer stok = new StreamTokenizer(new StringReader(msg));
    try {
      stok.nextToken();
      cmd = stok.sval;
      name = stok.sval;
    }
    catch (IOException e) {}

    if (cmd.compareTo("GET") == 0) {
      String cData = getCreditData(name);
      retMsg = name + " " + cData;
    }
    else {
      retMsg = "UNKNOWN_CMD";
    }

    // Add return message with results to the message queue.
    addMsg(retMsg);
  }

  protected String getCreditData(String acctName) {
    // Real method would use account name to
    // initiate a database query...
    return "No info available.";
  }
}