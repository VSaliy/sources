package dcj.util.Bandwidth;

import java.io.OutputStream;
import java.io.FilterOutputStream;
import java.util.Date;
import java.io.IOException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RTOutputStream
 * Example: 8-3
 * Description: An output stream that monitors its own "real time"
 *      data throughput.
 */

public class RTOutputStream extends FilterOutputStream {
  DataMonitor monitor;

  RTOutputStream(OutputStream out) {
    super(out);
    monitor = new DataMonitor();
  }

  public void write(int b) throws IOException {
    Date start = new Date();
    super.write(b);
    monitor.addSample(1, start, new Date());
  }

  public void write(byte data[]) throws IOException {
    Date start = new Date();
    super.write(data);
    monitor.addSample(data.length, start, new Date());
  }

  public void write(byte data[], int off, int len)
    throws IOException {
    Date start = new Date();
    super.write(data, off, len);
    monitor.addSample(data.length, start, new Date());
  }

  public float averageRate() {
    return monitor.getAverageRate();
  }

  public float lastRate() {
    return monitor.getLastRate();
  }
}