package dcj.util.Bandwidth;

import java.io.InputStream;
import java.io.OutputStream;

public class ContentProducer
{
  protected ContentProducer source = null;
  protected ContentConsumer dest = null;
  protected DataMonitor     monitor = new DataMonitor();

  public ContentProducer(InputStream src) {
    source = new ContentProducer(src);
  }

  public ContentProducer(ContentProducer src) {
    source = src;
  }

  public ContentProducer(OutputStream dst) {
    dest = new ContentConsumer(dst);
  }

  public ContentProducer(ContentConsumer dst) {
    dest = dst;
  }

  public void setSource(ContentProducer p) {
    source = p;
  }

  public void setSource(InputStream s) {
    source = new ContentProducer(s);
  }

  public void setDest(ContentConsumer c) {
    dest = c;
  }

  public void setDest(OutputStream s) {
    dest = new ContentConsumer(s);
  }

  // Produce a chunk of data
  public byte[] produce() {
    boolean success;
    byte[] data = null;
    success = preProduction();
    if (success)
      data = doProduction();
    if (success && data != null)
      success = postProduction(data);

    return data;
  }

  // Default pre-consumption procedure: log the start of
  // data consumption if not done already.
  protected boolean preProduction() {
    if (monitor.getStart() == null)
      monitor.start();

    return true;
  }

  // Default consumption procedure: write data unmodified to our
  // output destination, if present.
  protected byte[] doProduction() {
    byte[] data = null;
    if (source != null) {
      data = source.produce();
    }

    return data;
  }

  // Default post-consumption procedure: log the data consumption
  // size and finish time with our monitor.
  protected boolean postProduction(byte[] data) {
    monitor.addSample(data.length);
    return true;
  }
}