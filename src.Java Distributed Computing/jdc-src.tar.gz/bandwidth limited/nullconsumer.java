package dcj.util.Bandwidth;

import java.io.InputStream;
import java.io.OutputStream;

public class ContentConsumer
{
  protected ContentProducer source = null;
  protected ContentConsumer dest = null;
  protected DataMonitor     monitor = new DataMonitor();

  public ContentConsumer(InputStream src) {
    source = new ContentProducer(src);
  }

  public ContentConsumer(ContentProducer src) {
    source = src;
  }

  public ContentConsumer(OutputStream dst) {
    dest = new ContentConsumer(dst);
  }

  public ContentConsumer(ContentConsumer dst) {
    dest = dst;
  }

  public void setSource(ContentProducer p) {
    source = p;
  }

  public void setSource(InputStream s) {
    source = new ContentProducer(s);
  }

  public void setDest(ContentConsumer c) {
    dest = c;
  }

  public void setDest(OutputStream s) {
    dest = new ContentConsumer(s);
  }

  // Consume data from our producer until it is exhausted.
  public boolean consume() {
    boolean success = false;
    if (source != null) {
      byte[] data = source.produce();
//      byte[] data = null;
      while (data != null) {
        success = consume(data);
        data = source.produce();
      }
    }

    return success;
  }

  // Consume a chunk of data
  public boolean consume(byte[] data) {
    boolean success;
    success = preConsume(data);
    if (success)
      success = doConsume(data);
    if (success)
      success = postConsume(data);

    return success;
  }

  // Default pre-consumption procedure: log the start of
  // data consumption if not done already.
  protected boolean preConsume(byte[] data) {
    if (monitor.getStart() == null)
      monitor.start();

    return true;
  }

  // Default consumption procedure: write data unmodified to our
  // output destination, if present.
  protected boolean doConsume(byte[] data) {
    boolean success = false;
    if (dest != null) {
      success = dest.consume(data);
    }

    return true;
  }

  // Default post-consumption procedure: log the data consumption
  // size and finish time with our monitor.
  protected boolean postConsume(byte[] data) {
    monitor.addSample(data.length);
    return true;
  }
}