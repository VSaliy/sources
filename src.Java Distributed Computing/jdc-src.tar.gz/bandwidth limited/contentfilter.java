package dcj.util.Bandwidth;

import java.io.InputStream;
import java.io.OutputStream;

public class ContentFilter
{
  protected ContentProducer out = null;
  protected ContentConsumer in = null;
  protected DataMonitor     monitor = new DataMonitor();

  public ContentFilter(InputStream src, OutputStream dst) {
    in = new ContentProducer(src);
    out = new ContentConsumer(dst);
    buildFilter();
  }

  public ContentFilter(ContentProducer p, ContentConsumer c) {
    in = c;
    out = p;
    buildFilter();
  }

  protected void buildFilter() {
    if (in != null && out != null) {
      in.setSource(out);
      out.setDest(in);
    }
  }

  public ContentConsumer getInput() { return in; }
  public ContentProducer getOutput() { return out; }

  public void setOutput(ContentProducer p) {
    out = p;
    buildFilter();
  }
  public void setInput(ContentConsumer c) {
    in = c;
    buildFilter();
  }

  // Consume data from our producer until it is exhausted.
  public boolean consume() {
    boolean success = false;
    if (source != null) {
      byte[] data = source.produce();
//      byte[] data = null;
      while (data != null) {
        success = consume(data);
        data = source.produce();
      }
    }

    return success;
  }

  // Consume a chunk of data
  public boolean consume(byte[] data) {
    boolean success;
    success = preConsume(data);
    if (success)
      success = doConsume(data);
    if (success)
      success = postConsume(data);

    return success;
  }

  // Default pre-consumption procedure: log the start of
  // data consumption if not done already.
  protected boolean preConsume(byte[] data) {
    if (monitor.getStart() == null)
      monitor.start();

    return true;
  }

  // Default consumption procedure: write data unmodified to our
  // output destination, if present.
  protected boolean doConsume(byte[] data) {
    boolean success = false;
    if (dest != null) {
      success = dest.consume(data);
    }

    return true;
  }

  // Default post-consumption procedure: log the data consumption
  // size and finish time with our monitor.
  protected boolean postConsume(byte[] data) {
    monitor.addSample(data.length);
    return true;
  }
}