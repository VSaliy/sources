package dcj.util.Bandwidth;

import java.io.InputStream;
import java.io.OutputStream;

import java.util.Date;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ContentProducer
 * Example: 8-5
 * Description: A producer of content.  The source may be a network connection,
 *      a disk file, etc.
 */

public class ContentProducer
{
  protected ContentProducer source = null;
  protected ContentConsumer dest = null;
  protected DataMonitor     monitor = new DataMonitor();

  public ContentProducer(ContentProducer src) {
    source = src;
  }

  public ContentProducer(ContentConsumer dst) {
    dest = dst;
  }

  public void setSource(ContentProducer p) {
    source = p;
  }

  public void setDest(ContentConsumer c) {
    dest = c;
  }

  // Produce data and pass it to our destination, if present.
  public boolean produceAll() {
    boolean success = false;
    if (dest != null) {
      byte[] data = produce(0);
      while (data != null) {
        success = dest.consume(data);
        if (success)
          data = produce(0);
        else
          data = null;
      }
    }

    return success;
  }

  // Produce a chunk of data, within the given limit.
  public byte[] produce(long limit) {
    // Record the start time.
    Date start = new Date();

    boolean success;
    byte[] data = null;
    success = preProduction(limit);
    if (success)
      data = doProduction(limit);
    if (success && data != null)
      success = postProduction(data, limit);

    // Record the data sample in our monitor.
    monitor.addSample(data.length, start, new Date());

    // Pass the data on to our destination, if present
    if (data != null && dest != null)
      dest.consume(data);

    return data;
  }

  // Default pre-consumption procedure.
  protected boolean preProduction(long limit) {
    return true;
  }

  // Default production procedure: ask for data from our source,
  // if present, and pass along unmodified (e.g. a no-op).
  protected byte[] doProduction(long limit) {
    byte[] data = null;
    if (source != null) {
      data = source.produce(limit);
    }

    return data;
  }

  // Default post-consumption procedure.
  protected boolean postProduction(byte[] data, long limit) {
    return true;
  }
}