package DCJ.examples;

import java.lang.*;
import java.io.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: CORBASolverImpl
 * Example: 3-7
 * Description: Server implementation of the Solver Java interface generated
 *      by idltojava from the IDL interface from Ex. 3-4.
 */
public class CORBASolverImpl extends _SolverImplBase {

  protected int numIterations = 1; // not used for this Solver...
  protected ProblemSetHolder currProblem = null;

  // Constructors
  public CORBASolverImpl() { super(); }
  public CORBASolverImpl(int numIter) {
    super();
    numIterations = numIter;
  }


  public ProblemSet getProblem() {
    return currProblem.value;
  }

  public void setProblem(ProblemSetHolder ph) {
    currProblem = ph;
  }

  public int getNumIterations() {
    return numIterations;
  }

  public void setNumIterations(int i) {
    numIterations = i;
  }

  public boolean solveCurrent() {
    System.out.println("Solving current problem...");
    return solve(currProblem, numIterations);
  }

  public boolean solve(ProblemSetHolder sh, int numIters) {
    ProblemSet s = sh.value;
    boolean success = true;

    if (s == null) {
      System.out.println("No problem to solve.");
      return false;
    }

    System.out.println("Problem value = " + s.getValue());

    // Solve problem here...
    try {
      s.setSolution(Math.sqrt(s.getValue()));
    }
    catch (ArithmeticException e) {
      System.out.println("Badly-formed problem.");
      success = false;
    }

    System.out.println("Problem solution = " + s.getSolution());

    return success;
  }

  public static void main(String argv[]) {

    try {
      // create and initialize the ORB
      System.out.println("Initializing ORB...");
      ORB orb = ORB.init(argv, null);

      // Create a Solver and register it with the ORB
      System.out.println("Connecting solver to ORB...");
      CORBASolverImpl solver = new CORBASolverImpl();
      orb.connect(solver);

      // Get the naming service from the ORB
      System.out.println("Getting reference to Naming Service...");
      org.omg.CORBA.Object ncObj =
        orb.resolve_initial_references("NameService");
      NamingContext ncRef = NamingContextHelper.narrow(ncObj);

      // Bind the Solver object to a name
      System.out.println("Registering Solver with Naming Service...");
      NameComponent comp = new NameComponent("Solver", "");
      NameComponent path[] = {comp};
      ncRef.rebind(path, solver);

      // Wait for client requests
      System.out.println("Waiting for clients...");
      java.lang.Object dummySync = new java.lang.Object();
      synchronized (dummySync) {
        dummySync.wait();
      }
    }
    catch (Exception e) {
      System.err.println(e);
      e.printStackTrace(System.out);
    }
  }
}
