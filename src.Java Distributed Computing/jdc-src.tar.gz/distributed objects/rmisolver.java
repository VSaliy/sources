package dcj.examples.rmi;

import java.rmi.*;
import java.io.OutputStream;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMISolver
 * Example: 3-10
 * Description: A modified version of our Solver interface, with the exception
 *      declarations required by RMI.
 */

public interface RMISolver extends java.rmi.Remote {
  public boolean solve() throws RemoteException;
  public boolean solve(RMIProblemSet s,
                       int numIters) throws RemoteException;

  public RMIProblemSet getProblem() throws RemoteException;
  public boolean setProblem(RMIProblemSet s) throws RemoteException;
  public int getIterations() throws RemoteException;
  public boolean setIterations(int numIter) throws RemoteException;
}
