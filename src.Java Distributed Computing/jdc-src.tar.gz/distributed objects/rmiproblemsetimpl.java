package dcj.examples.rmi;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMISolver
 * Example: 3-13
 * Description: Implementation of the RMI-based ProblemSet interface.
 */

public class RMIProblemSetImpl
    extends java.rmi.server.UnicastRemoteObject
    implements RMIProblemSet {

  protected double value;
  protected double solution;

  public RMIProblemSetImpl() throws RemoteException {
    value = 0.0;
    solution = 0.0;
  }

  public double getValue() throws RemoteException {
    return value;
  }

  public double getSolution() throws RemoteException {
    return solution;
  }

  public void setValue(double v) throws RemoteException {
    value = v;
  }

  public void setSolution(double s) throws RemoteException {
    solution = s;
  }
}