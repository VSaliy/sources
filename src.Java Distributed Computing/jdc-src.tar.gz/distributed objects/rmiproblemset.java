package dcj.examples.rmi;

import java.rmi.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMIProblemSet
 * Example: 3-11
 * Description: A modified version of our ProblemSet interface, with the
 *      exception declarations required by RMI.
 */

public interface RMIProblemSet extends Remote {
  public double getValue() throws RemoteException;
  public double getSolution() throws RemoteException;
  public void setValue(double v) throws RemoteException;
  public void setSolution(double s) throws RemoteException;
}
