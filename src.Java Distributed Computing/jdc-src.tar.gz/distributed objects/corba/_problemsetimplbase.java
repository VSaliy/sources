/*
 * File: ./DCJ/examples/_ProblemSetImplBase.java
 * From: Solver.idl
 * Date: Tue Jun 17 21:50:24 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public abstract class _ProblemSetImplBase extends org.omg.CORBA.portable.ObjectImpl implements DCJ.examples.ProblemSet, org.omg.CORBA.portable.Skeleton {
    static private org.omg.CORBA.portable.OperationDescriptor[][] _dispatch_table;
    static {
       _dispatch_table = new org.omg.CORBA.portable.OperationDescriptor[1][0];
       _dispatch_table[0] = DCJ.examples._ProblemSetStub._get_operations();
    }
    public org.omg.CORBA.portable.OperationDescriptor[][] _get_dispatch_table() {
          return _dispatch_table;
    }
    // Constructor
    public _ProblemSetImplBase() {
         super(null);
    }
    // Type strings for this class and its superclases
    private static String _type_ids[] = {
        "IDL:DCJ/examples/ProblemSet:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    // Dispatch call
    public java.lang.Object _execute(int intf, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)
          throws java.lang.Exception {

            return DCJ.examples._ProblemSetImplBase._execute(this, op, n, o, ctx);
    }
    public static java.lang.Object _execute(DCJ.examples.ProblemSet self, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)             throws java.lang.Exception {

        switch (op) {
           case 0: // DCJ.examples.ProblemSet.getValue
                  {
                      double __result = self.getValue(
);
                        n[0] = Double.doubleToLongBits(__result);
                  }
                   break;
           case 1: // DCJ.examples.ProblemSet.setValue
                  {
                      self.setValue(
                        Double.longBitsToDouble(n[0]));
                  }
                   break;
           case 2: // DCJ.examples.ProblemSet.getSolution
                  {
                      double __result = self.getSolution(
);
                        n[0] = Double.doubleToLongBits(__result);
                  }
                   break;
           case 3: // DCJ.examples.ProblemSet.setSolution
                  {
                      self.setSolution(
                        Double.longBitsToDouble(n[0]));
                  }
                   break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
  }
       return null;
    }
}
