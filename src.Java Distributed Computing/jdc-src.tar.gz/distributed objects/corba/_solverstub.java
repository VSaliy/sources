/*
 * File: ./DCJ/examples/_SolverStub.java
 * From: Solver.idl
 * Date: Tue Jun 17 21:50:24 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package DCJ.examples;
public class _SolverStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements DCJ.examples.Solver {

    public _SolverStub(org.omg.CORBA.portable.Delegate d) {
          super(d);
    }

    public static final org.omg.CORBA.portable.OperationDescriptor __ops[] = new org.omg.CORBA.portable.OperationDescriptor[6];

    public static org.omg.CORBA.portable.OperationDescriptor[] _get_operations() {
        return __ops;
    }

    static {
           {
           //      Descriptor for ::DCJ::examples::Solver::solveCurrent
           int[] _p0 = {
0x8
           };
           Class[] _c0 = {
null
           };
           Class[] _e0 = {

           };
           String[] _exId0 = {

           };
               __ops[0] = new org.omg.CORBA.portable.OperationDescriptor("solveCurrent", _p0, _c0, _exId0, _e0, false);
           }


           {
           //      Descriptor for ::DCJ::examples::Solver::solve
           int[] _p1 = {
0x8, 0xe | 0xc0000000, 0x3 | 0x40000000
           };
           Class[] _c1 = {
null, new DCJ.examples.ProblemSetHolder().getClass(), null
           };
           Class[] _e1 = {

           };
           String[] _exId1 = {

           };
               __ops[1] = new org.omg.CORBA.portable.OperationDescriptor("solve", _p1, _c1, _exId1, _e1, false);
           }


           {
           //      Descriptor for ::DCJ::examples::Solver::getProblem
           int[] _p2 = {
0xe
           };
           Class[] _c2 = {
new DCJ.examples.ProblemSetHolder().getClass()
           };
           Class[] _e2 = {

           };
           String[] _exId2 = {

           };
               __ops[2] = new org.omg.CORBA.portable.OperationDescriptor("getProblem", _p2, _c2, _exId2, _e2, false);
           }


           {
           //      Descriptor for ::DCJ::examples::Solver::setProblem
           int[] _p3 = {
             0xe | 0xc0000000
           };
           Class[] _c3 = {
             new DCJ.examples.ProblemSetHolder().getClass()
           };
           Class[] _e3 = {

           };
           String[] _exId3 = {

           };
               __ops[3] = new org.omg.CORBA.portable.OperationDescriptor("setProblem", _p3, _c3, _exId3, _e3, false);
           }


           {
           //      Descriptor for ::DCJ::examples::Solver::getNumIterations
           int[] _p4 = {
0x5
           };
           Class[] _c4 = {
null
           };
           Class[] _e4 = {

           };
           String[] _exId4 = {

           };
               __ops[4] = new org.omg.CORBA.portable.OperationDescriptor("getNumIterations", _p4, _c4, _exId4, _e4, false);
           }


           {
           //      Descriptor for ::DCJ::examples::Solver::setNumIterations
           int[] _p5 = {
             0x5 | 0x40000000
           };
           Class[] _c5 = {
             null
           };
           Class[] _e5 = {

           };
           String[] _exId5 = {

           };
               __ops[5] = new org.omg.CORBA.portable.OperationDescriptor("setNumIterations", _p5, _c5, _exId5, _e5, false);
           }


    }

    private static String _type_ids[] = {
        "IDL:DCJ/examples/Solver:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    //	IDL operations
    //	    Implementation of ::DCJ::examples::Solver::solveCurrent
    public boolean solveCurrent()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _e = _invoke(__ops[0], _n, _o);
           return (_n[0] == 0) ? false : true;
    }
    //	    Implementation of ::DCJ::examples::Solver::solve
    public boolean solve(DCJ.examples.ProblemSetHolder s, int numIters)
 {
           long   _n[] = new long[3];
           java.lang.Object _o[] = new java.lang.Object[3];
           java.lang.Object _e;
           _o[0] = s;
           _n[1] = (numIters & 0xFFFFFFFFL);
           _e = _invoke(__ops[1], _n, _o);
           return (_n[0] == 0) ? false : true;
    }
    //	    Implementation of ::DCJ::examples::Solver::getProblem
    public DCJ.examples.ProblemSet getProblem()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _o[0] = null;
           _e = _invoke(__ops[2], _n, _o);
           return DCJ.examples.ProblemSetHelper.narrow((org.omg.CORBA.Object) _o[0]);
    }
    //	    Implementation of ::DCJ::examples::Solver::setProblem
    public void setProblem(DCJ.examples.ProblemSetHolder p)
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _o[0] = p;
           _e = _invoke(__ops[3], _n, _o);
    }
    //	    Implementation of ::DCJ::examples::Solver::getNumIterations
    public int getNumIterations()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _e = _invoke(__ops[4], _n, _o);
           return (int) (_n[0] & 0xFFFFFFFFL);
    }
    //	    Implementation of ::DCJ::examples::Solver::setNumIterations
    public void setNumIterations(int i)
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _n[0] = (i & 0xFFFFFFFFL);
           _e = _invoke(__ops[5], _n, _o);
    }

};
