/*
 * File: ./Examples/_BankServerStub.java
 * From: BankServer.idl
 * Date: Sun Jun 15 14:12:50 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public class _BankServerStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements Examples.BankServer {

    public _BankServerStub(org.omg.CORBA.portable.Delegate d) {
          super(d);
    }

    public static final org.omg.CORBA.portable.OperationDescriptor __ops[] = new org.omg.CORBA.portable.OperationDescriptor[3];

    public static org.omg.CORBA.portable.OperationDescriptor[] _get_operations() {
        return __ops;
    }

    static {
           {
           //      Descriptor for ::Examples::BankServer::verifyPIN
           int[] _p0 = {
0x8, 0x3 | 0x40000000, 0x3 | 0x40000000
           };
           Class[] _c0 = {
null, null, null
           };
           Class[] _e0 = {

           };
           String[] _exId0 = {

           };
               __ops[0] = new org.omg.CORBA.portable.OperationDescriptor("verifyPIN", _p0, _c0, _exId0, _e0, false);
           }


           {
           //      Descriptor for ::Examples::BankServer::getAcctSpecifics
           int[] _p1 = {
             0x3 | 0x40000000, 0x12 | 0x40000000, 0x7 | 0x80000000, 0x8 | 0x80000000
           };
           Class[] _c1 = {
             null, null, null, null
           };
           Class[] _e1 = {

           };
           String[] _exId1 = {

           };
               __ops[1] = new org.omg.CORBA.portable.OperationDescriptor("getAcctSpecifics", _p1, _c1, _exId1, _e1, false);
           }


           {
           //      Descriptor for ::Examples::BankServer::processTransaction
           int[] _p2 = {
0x8, 0xe | 0x40000000, 0x3 | 0x40000000
           };
           Class[] _c2 = {
null, null, null
           };
           Class[] _e2 = {

           };
           String[] _exId2 = {

           };
               __ops[2] = new org.omg.CORBA.portable.OperationDescriptor("processTransaction", _p2, _c2, _exId2, _e2, false);
           }


    }

    private static String _type_ids[] = {
        "IDL:Examples/BankServer:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    //	IDL operations
    //	    Implementation of ::Examples::BankServer::verifyPIN
    public boolean verifyPIN(int acctNo, int pin)
 {
           long   _n[] = new long[3];
           java.lang.Object _o[] = new java.lang.Object[3];
           java.lang.Object _e;
           _n[1] = (acctNo & 0xFFFFFFFFL);
           _n[2] = (pin & 0xFFFFFFFFL);
           _e = _invoke(__ops[0], _n, _o);
           return (_n[0] == 0) ? false : true;
    }
    //	    Implementation of ::Examples::BankServer::getAcctSpecifics
    public void getAcctSpecifics(int acctNo, String customerName, org.omg.CORBA.DoubleHolder balance, org.omg.CORBA.BooleanHolder isChecking)
 {
           long   _n[] = new long[4];
           java.lang.Object _o[] = new java.lang.Object[4];
           java.lang.Object _e;
           _n[0] = (acctNo & 0xFFFFFFFFL);
           _o[0] = customerName;
           _o[1] = balance;
           _o[2] = isChecking;
           _e = _invoke(__ops[1], _n, _o);
    }
    //	    Implementation of ::Examples::BankServer::processTransaction
    public boolean processTransaction(Examples.Transaction t, int acctNo)
 {
           long   _n[] = new long[3];
           java.lang.Object _o[] = new java.lang.Object[3];
           java.lang.Object _e;
           _o[0] = t;
           _n[1] = (acctNo & 0xFFFFFFFFL);
           _e = _invoke(__ops[2], _n, _o);
           return (_n[0] == 0) ? false : true;
    }

};
