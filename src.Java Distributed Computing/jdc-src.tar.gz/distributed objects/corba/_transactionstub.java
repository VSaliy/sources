/*
 * File: ./Examples/_TransactionStub.java
 * From: BankServer.idl
 * Date: Sun Jun 15 14:12:50 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public class _TransactionStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements Examples.Transaction {

    public _TransactionStub(org.omg.CORBA.portable.Delegate d) {
          super(d);
    }

    public static final org.omg.CORBA.portable.OperationDescriptor __ops[] = new org.omg.CORBA.portable.OperationDescriptor[2];

    public static org.omg.CORBA.portable.OperationDescriptor[] _get_operations() {
        return __ops;
    }

    static {
           {
           //      Descriptor for ::Examples::Transaction::amount
           int[] _p0 = {
0x7
           };
           Class[] _c0 = {
null
           };
           Class[] _e0 = {

           };
           String[] _exId0 = {

           };
               __ops[0] = new org.omg.CORBA.portable.OperationDescriptor("amount", _p0, _c0, _exId0, _e0, false);
           }


           {
           //      Descriptor for ::Examples::Transaction::isDebit
           int[] _p1 = {
0x8
           };
           Class[] _c1 = {
null
           };
           Class[] _e1 = {

           };
           String[] _exId1 = {

           };
               __ops[1] = new org.omg.CORBA.portable.OperationDescriptor("isDebit", _p1, _c1, _exId1, _e1, false);
           }


    }

    private static String _type_ids[] = {
        "IDL:Examples/Transaction:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    //	IDL operations
    //	    Implementation of ::Examples::Transaction::amount
    public double amount()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _e = _invoke(__ops[0], _n, _o);
           return Double.longBitsToDouble(_n[0]);
    }
    //	    Implementation of ::Examples::Transaction::isDebit
    public boolean isDebit()
 {
           long   _n[] = new long[1];
           java.lang.Object _o[] = new java.lang.Object[1];
           java.lang.Object _e;
           _e = _invoke(__ops[1], _n, _o);
           return (_n[0] == 0) ? false : true;
    }

};
