/*
 * File: ./Examples/_BankServerImplBase.java
 * From: BankServer.idl
 * Date: Sun Jun 15 14:12:50 1997
 *   By: idltojava JavaIDL Wed Mar 5 17:02:26 1997
 */

package Examples;
public abstract class _BankServerImplBase extends org.omg.CORBA.portable.ObjectImpl implements Examples.BankServer, org.omg.CORBA.portable.Skeleton {
    static private org.omg.CORBA.portable.OperationDescriptor[][] _dispatch_table;
    static {
       _dispatch_table = new org.omg.CORBA.portable.OperationDescriptor[1][0];
       _dispatch_table[0] = Examples._BankServerStub._get_operations();
    }
    public org.omg.CORBA.portable.OperationDescriptor[][] _get_dispatch_table() {
          return _dispatch_table;
    }
    // Constructor
    public _BankServerImplBase() {
         super(null);
    }
    // Type strings for this class and its superclases
    private static String _type_ids[] = {
        "IDL:Examples/BankServer:1.0"
    };

    public String[] _get_ids() { return _type_ids; }

    // Dispatch call
    public java.lang.Object _execute(int intf, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)
          throws java.lang.Exception {

            return Examples._BankServerImplBase._execute(this, op, n, o, ctx);
    }
    public static java.lang.Object _execute(Examples.BankServer self, int op, long[] n, java.lang.Object[] o, org.omg.CORBA.Context ctx)             throws java.lang.Exception {

        switch (op) {
           case 0: // Examples.BankServer.verifyPIN
                  {
                      boolean __result = self.verifyPIN(
                        (int) (n[1] & 0xFFFFFFFFL),
                        (int) (n[2] & 0xFFFFFFFFL));
                        n[0] = (__result) ? 1 : 0;
                  }
                   break;
           case 1: // Examples.BankServer.getAcctSpecifics
                  {
                      self.getAcctSpecifics(
                        (int) (n[0] & 0xFFFFFFFFL),
                        (String)o[0],
                        (org.omg.CORBA.DoubleHolder)o[1],
                        (org.omg.CORBA.BooleanHolder)o[2]);
                  }
                   break;
           case 2: // Examples.BankServer.processTransaction
                  {
                      boolean __result = self.processTransaction(
                        (Examples.Transaction)o[0],
                        (int) (n[1] & 0xFFFFFFFFL));
                        n[0] = (__result) ? 1 : 0;
                  }
                   break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
  }
       return null;
    }
}
