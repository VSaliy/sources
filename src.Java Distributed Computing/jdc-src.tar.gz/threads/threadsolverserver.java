package dcj.examples;

import java.io.*;
import java.net.*;

class ThreadSolverServer extends SimpleServer
{
  public ThreadSolverServer() { super(3000); }
  public ThreadSolverServer(int port) { super(port); }
  
  public static void main(String argv[])
  {
    int port = 3000;
    
    System.out.println("Parsing arguments...");
    
    if (argv.length > 0)
      {
        int tmp = port;
        try
          {
            tmp = Integer.parseInt(argv[0]);
          }
        catch (NumberFormatException e) {}
        
        port = tmp;
      }
    
    System.out.println("Creating server...");
    ThreadSolverServer server = new ThreadSolverServer(port);
    System.out.println("ThreadSolverServer running on port " + port + "...");
    server.run();
  }

  // Override SimpleServer's serviceClient() method to spawn Solver threads
  // on each client connection.
  public void serviceClient(Socket clientConn)
  {
    System.out.println("ThreadSolverServer::serviceClient...");
    
    InputStream inStream = null;
    OutputStream outStream = null;
    
    try
      {
        inStream = clientConn.getInputStream();
        outStream = clientConn.getOutputStream();
      }
    catch (IOException e)
      {
        System.out.println("ThreadSolverServer: Error getting I/O streams.");
        System.exit(1);
      }

    System.out.println("Creating solver...");
    ThreadSolver ts = new ThreadSolver(inStream, outStream);
    System.out.println("Starting thread...");
    ts.start();
    try
      {
        sleep(1);
      }
    catch (InterruptedException e)
      {
        System.out.println("Couldn't sleep because we're interrupted...");
      }
    
    System.out.println("Suspending thread...");
    ts.suspend();
    try { sleep(1); }
    catch (InterruptedException e)
      {
	System.out.println("Couldn't sleep because we're interrupted...");
      }
    System.out.println("Resuming thread...");
    ts.resume();
  }
}
