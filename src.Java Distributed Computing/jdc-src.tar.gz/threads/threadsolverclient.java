package dcj.examples;

import java.lang.*;
import java.net.*;
import java.io.*;

public class ThreadSolverClient extends SimpleClient
{
  ProblemSet problem;
  
  public ThreadSolverClient(String host, int port, double pval)
  {
    super(host, port);
    problem = new ProblemSet();
    problem.Value(pval);
  }

  public static void main(String argv[])
  {
    if (argv.length < 3)
      {
        System.out.println("Usage: java ThreadSolverClient [host] [port] [problem]");
        System.exit(1);
      }
    
    String host = argv[0];
    int port = 3000;
    double pval = 0;
    try
      {
        port = Integer.parseInt(argv[1]);
        pval = Double.valueOf(argv[2]).doubleValue();
      }
    catch (NumberFormatException e)
      {}
    
    ThreadSolverClient client = new ThreadSolverClient(host, port, pval);
    System.out.println("Attaching client to " + host + ":" + port + "...");
    client.run();
  }
  
  public void run()
  {
    try
      {
        DataOutputStream dout =
          new DataOutputStream(serverConn.getOutputStream());
        DataInputStream din =
          new DataInputStream(serverConn.getInputStream());

        // Send a problem...
        System.out.println("Sending problem to server...");
        dout.writeChars("problem " + problem.Value() + " ");
        // ...and wait for a response
        boolean done = false;
        String result;
        
        while (!done)
          {
            System.out.println("Waiting for response...");
            result = din.readUTF();
	    System.out.println("Got a line = \"" + result + "\"");
            if (result.indexOf("interrupt") >= 0)
              {
                System.out.println("Solver has been interrupted.");
                //
                // Free up locked resources here...
                //
              }
            else if (result.indexOf("solution") >= 0)
              {
                System.out.println("Server returned: \"" + result + "\"");
                done = true;
              }
          }
      }
    catch (IOException e)
      {
        System.out.println("ThreadSolverClient: " + e);
        System.exit(1);
      }
  }
}
