package dcj.examples;

import java.io.*;
import java.net.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RunnableSolverServer
 * Example: 4-2
 * Description: A SimpleServer that starts an independent thread to
 *      service each client request.
 */

class RunnableSolverServer extends SimpleServer {
  public RunnableSolverServer() { super(3000); }
  public RunnableSolverServer(int port) { super(port); }

  public static void main(String argv[]) {
    int port = 3000;
    if (argv.length > 0) {
      try {
        port = Integer.parseInt(argv[0]);
      }
      catch (NumberFormatException e) {
        System.err.println("Bad port number given.");
        System.err.println("   Using default port.");
      }
    }

    RunnableSolverServer server = new RunnableSolverServer(port);
    System.out.println("RunnableSolverServer running on port " + port + "...");
    server.listen();
  }

  // Override SimpleServer's serviceClient() method to spawn Solver threads
  // on each client connection.
  public void serviceClient(Socket clientConn) {
    InputStream inStream = null;
    OutputStream outStream = null;

    try {
      inStream = clientConn.getInputStream();
      outStream = clientConn.getOutputStream();
    }
    catch (IOException e) {
      System.out.println("RunnableSolverServer: Error getting I/O streams.");
      System.exit(1);
    }

    RunnableSolver s = new RunnableSolver(inStream, outStream);
    Thread t = new Thread(s);
    t.start();
  }
}