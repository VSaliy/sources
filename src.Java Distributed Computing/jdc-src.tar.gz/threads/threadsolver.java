package dcj.examples;

import java.lang.Thread;
import java.io.*;

public class ThreadSolver extends Thread implements Solver
{
  // Protected implementation variables
  protected ProblemSet currProblem = null;
  protected OutputStream clientOut = null; // Destination for solutions
  protected InputStream clientIn = null;   // Source of problems
  
  // Constructors
  public ThreadSolver(InputStream cin, OutputStream cout)
  {
    super();
    clientIn = cin;
    clientOut = cout;
  }
  
  public boolean Solve()
  {
    boolean success = true;
    SimpleCmdInputStream sin = new SimpleCmdInputStream(clientIn);
    String inStr = null;
    try
      {
        System.out.println("Reading from client...");
        inStr = sin.readString();
      }
    catch (IOException e)
      {
        System.out.println("Error reading data from client.");
        return false;
      }
    
    if (inStr.compareTo("problem") == 0)
      {
        try
          {
            inStr = sin.readString();
          }
        catch (IOException e)
          {
            System.out.println("Error reading data from client.");
            return false;
          }
            
        System.out.println("Got \"" + inStr + "\" from client.");
        double problem = Double.valueOf(inStr).doubleValue();
        ProblemSet p = new ProblemSet();
        p.Value(problem);
        success = Solve(p);
      }
    else
      {
        System.out.println("Error reading problem from client.");
        return false;
      }
    
    return success;
  }
  
  public boolean Solve(ProblemSet s)
  {
    boolean success = true;
    
    if (s == null)
      {
        System.out.println("No problem to solve.");
        return false;
      }
    
    System.out.println("Problem value = " + s.Value());
    
    // Solve problem here...
    try
      {
        s.Solution(Math.sqrt(s.Value()));
      }
    catch (ArithmeticException e)
      {
        System.out.println("Badly-formed problem.");
        success = false;
      }
    
    System.out.println("Problem solution = " + s.Solution());
    System.out.println("Sending solution to output...");
    
    // Write the solution to the designated output destination
    try
      {
        DataOutputStream dout = new DataOutputStream(clientOut);
        dout.writeUTF("solution=" + s.Solution());
      }
    catch (IOException e)
      {
        System.out.println("Error writing results to output.");
        success = false;
      }
    
    return success;
  }
  
  public boolean Problem(ProblemSet s)
  { currProblem = s; return true; }
  
  public boolean Iterations(int dummy) // Not used on this solver
  { return false; }
  
  public void PrintResults(OutputStream os)
  {
    PrintStream pos = new PrintStream(os);
    pos.println("Problem solution: " + currProblem.Solution());
  }
  
  public void run()
  {
    Solve();
  }
  
  public void interrupt()
  {
    System.out.println("ThreadSolver::interrupt()...");
    
    DataOutputStream dout = new DataOutputStream(clientOut);
    try
      {
        dout.writeUTF("interrupt");
      }
    catch (IOException e)
      {
        System.out.println("ThreadSolver: Error notifying client.");
      }
  }
  
}

