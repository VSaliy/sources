package dcj.examples.dbase;

import java.sql.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: SchedTask
 * Example: 7-4
 * Description: Data pertaining to a task to be scheduled.
 */

class SchedTask extends DatabaseItem {
  int tid;
  int type;
  float size;

  SchedTask(int id) {
    tid = id;
    valid = updateFromDbase();
  }

  SchedTask(int t, float sz) {
    type = t;
    size = sz;
    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int cnt = s.executeUpdate("INSERT INTO task (tid, type, size) "
                  + "VALUES (tidseq.nextval, " + type + ", "
                  + size + ")");
      if (cnt < 1) {
        valid = false;
      }
      else {
        valid = true;
      }
    }
    catch (SQLException e) {
      valid = false;
    }
  }

  public int    getId()           { return tid; }

  public int    getType()         { return type; }
  public void   setType(int t)    { type = t; }

  public float  getSize()         { return size; }
  public void   setSize(float s)  { size = s; }

  public boolean updateFromDbase() {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT type, size FROM task WHERE tid = "
                       + tid);
      if (r.next()) {
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE task SET type = "
                                 + type + ", size = " + size
                                 + " WHERE tid = " + tid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }

  static public Vector getAllTasks() {
    Vector taskList = new Vector();

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT distinct(tid) FROM task");
      while (r.next()) {
        int id = r.getInt("tid");
        SchedTask task = new SchedTask(id);
        if (task.isValid()) {
          taskList.addElement(task);
        }
      }
    }
    catch (Exception e) {}

    return taskList;
  }
}