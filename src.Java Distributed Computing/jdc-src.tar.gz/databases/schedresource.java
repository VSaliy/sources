package dcj.examples.dbase;

import java.sql.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: SchedResource
 * Example: 7-3
 * Description: Data pertaining to a resource to be scheduled.
 */

class SchedResource extends DatabaseItem {
  int rid;
  String name;
  int type;
  float size;

  public SchedResource(int id) {
    rid = id;
    valid = updateFromDbase();
  }

  public SchedResource(String n, int t, float s) {
    // How is ID generated?
    try {
      Statement st = DatabaseItem.dbConn.createStatement();
      int rcnt = st.executeUpdate("INSERT INTO resource "
                   + "(rid, name, type, size) VALUES "
                   + "(ridseq.nextval, " + n + ", "
                   + t + ", " + s + ")");
      if (rcnt == 1)
        valid = true;
      else
        valid = false;
    }
    catch (SQLException e) {
      valid = false;
    }
  }

  public int    getId()           { return rid; }

  public String getName()         { return name; }
  public void   setName(String n) { name = n; updateToDbase(); }

  public int    getType()         { return type; }
  public void   setType(int t)    { type = t; updateToDbase(); }

  public float  getSize()         { return size; }
  public void   setSize(float s)  { size = s; updateToDbase(); }

  public boolean updateFromDbase() {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT name, type, size FROM resource WHERE rid = "
                       + rid);
      if (r.next()) {
        name = r.getString("name");
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE resource SET name = " + name
                                 + ", type = " + type + ", size = " + size
                                 + " WHERE rid = " + rid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }

  static public Vector getAllResources() {
    Vector resList = new Vector();
    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r = s.executeQuery("SELECT distinct(rid) FROM resource");
      while (r.next()) {
        int id = r.getInt("rid");
        SchedResource res = new SchedResource(id);
        if (res.isValid()) {
          resList.addElement(res);
        }
      }
    }
    catch (Exception e) {};

    return resList;
  }
}