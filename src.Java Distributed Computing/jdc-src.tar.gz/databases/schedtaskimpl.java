package dcj.examples.dbase;

import java.util.Vector;
import java.util.Date;
import java.sql.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

class SchedResourceImpl extends DatabaseItem
                        implements RMISchedResource {
  int rid;
  String name;
  int type;
  float size;

  SchedResourceImpl(int id) throws RemoteException {
    rid = id;
    valid = updateFromDbase();
  }

  SchedResourceImpl(String n, int t, float s)
    throws RemoteException {
    // How is ID generated?
    try {
      Statement st = DatabaseItem.dbConn.createStatement();
      int rcnt = st.executeUpdate("INSERT INTO resource "
                   "(rid, name, type, size) VALUES (ridSeq.nextVal, "
                   + n + ", " + t + ", " + s + ")");
      if (rcnt == 1)
        valid = true;
      else
        valid = false;
    }
    catch (Exception e) {
      valid = false;
    }
  }

  public int    getId() throws RemoteException
                  { return rid; }
  public String getName() throws RemoteException
                  { return name; }
  public void   setName(String n) throws RemoteException
                  { name = n; updateToDbase(); }
  public int    getType() throws RemoteException
                  { return type; }
  public void   setType(int t) throws RemoteException
                  { type = t; updateToDbase(); }
  public float  getSize() throws RemoteException
                  { return size; }
  public void   setSize(float s) throws RemoteException
                  { size = s; updateToDbase(); }

  public boolean updateFromDbase() throws RemoteException {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT name, type, size FROM resource WHERE rid = "
                       + rid);
      if (r.next()) {
        name = r.getString("name");
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() throws RemoteException {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE resource SET name = " + name
                                 + " type = " + type + " size = " + size
                                 + " WHERE rid = " + rid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }
}