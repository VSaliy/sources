package dcj.examples.dbase;

import java.util.Vector;
import java.util.Date;
import java.sql.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

abstract class DatabaseItemImpl extends UnicastRemoteObject
                     implements RMIDatabaseItem {
  public static Connection dbConn;
  boolean valid;

  public DatabaseItemImpl() throws RemoteException { super(); }
  public boolean isValid() throws RemoteException { return valid; }
}

class SchedResourceImpl extends DatabaseItemImpl implements RMISchedResource {
  int rid;
  String name;
  int type;
  float size;

  SchedResourceImpl(int id) throws RemoteException {
    rid = id;
    valid = updateFromDbase();
  }

  SchedResourceImpl(String n, int t, float s)
    throws RemoteException {
    // How is ID generated?
    try {
      Statement st = DatabaseItem.dbConn.createStatement();
      int rcnt = st.executeUpdate("INSERT INTO resource "  +
                   "(rid, name, type, size) VALUES (ridSeq.nextVal, "
                   + n + ", " + t + ", " + s + ")");
      if (rcnt == 1)
        valid = true;
      else
        valid = false;
    }
    catch (Exception e) {
      valid = false;
    }
  }

  public int    getId() throws RemoteException
                  { return rid; }
  public String getName() throws RemoteException
                  { return name; }
  public void   setName(String n) throws RemoteException
                  { name = n; updateToDbase(); }
  public int    getType() throws RemoteException
                  { return type; }
  public void   setType(int t) throws RemoteException
                  { type = t; updateToDbase(); }
  public float  getSize() throws RemoteException
                  { return size; }
  public void   setSize(float s) throws RemoteException
                  { size = s; updateToDbase(); }

  public boolean updateFromDbase() throws RemoteException {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT name, type, size FROM resource WHERE rid = "
                       + rid);
      if (r.next()) {
        name = r.getString("name");
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() throws RemoteException {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE resource SET name = " + name
                                 + " type = " + type + " size = " + size
                                 + " WHERE rid = " + rid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }
}

class SchedTaskImpl extends DatabaseItemImpl implements RMISchedTask {
  int tid;
  int type;
  float size;

  SchedTaskImpl(int id) throws RemoteException {
    tid = id;
    valid = updateFromDbase();
  }

  SchedTaskImpl(int t, float sz) throws RemoteException {
    type = t;
    size = sz;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int cnt = s.executeUpdate("INSERT INTO task VALUES "
                                + "(tidSeq.nextVal, " + type + ", " + size + ")");
      if (cnt < 1) {
        valid = false;
      }
      else {
        valid = true;
      }
    }
    catch (Exception e) {
      valid = false;
    }
  }

  public int    getId() throws RemoteException
                  { return tid; }
  public int    getType() throws RemoteException
                  { return type; }
  public void   setType(int t) throws RemoteException
                  { type = t; }
  public float  getSize() throws RemoteException
                  { return size; }
  public void   setSize(float s) throws RemoteException
                  { size = s; }

  public boolean updateFromDbase() throws RemoteException {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      ResultSet r =
        s.executeQuery("SELECT type, size FROM task WHERE tid = "
                       + tid);
      if (r.next()) {
        type = r.getInt("type");
        size = r.getFloat("size");
      }
      else {
        success = false;
      }

      s.close();
    }
    catch (SQLException e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() throws RemoteException {
    boolean success = true;

    try {
      Statement s = DatabaseItem.dbConn.createStatement();
      int numr = s.executeUpdate("UPDATE task SET type = "
                   + type + " size = " + size
                   + " WHERE tid = " + tid);
      if (numr < 1) {
        success = false;
      }
    }
    catch (SQLException s) {
      success = false;
    }

    return success;
  }
}

class TimeConstraintImpl extends DatabaseItemImpl implements RMITimeConstraint {
  int ctype;
  int task1;
  int task2;

  // This constructor is used to create a representation
  // of a constraint in the database.
  public TimeConstraintImpl(int type, int tid1, int tid2)
           throws RemoteException {
    ctype = type;
    task1 = tid1;
    task2 = tid2;
  }

  public int getTask1Id() throws RemoteException { return task1; }
  public int getTask2Id() throws RemoteException { return task2; }
  public int getType() throws RemoteException { return ctype; }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() throws RemoteException { return false; }
  public boolean updateToDbase() throws RemoteException { return false; }
}

class ResAssignmentImpl extends DatabaseItemImpl implements RMIResAssignment {
  int rid;
  int tid;
  Date timestamp;

  ResAssignmentImpl(int res, int task, Date time) throws RemoteException {
    rid = res;
    tid = task;
    timestamp = time;
  }

  public int  getResourceId() throws RemoteException
                { return rid; }
  public int  getTaskId() throws RemoteException
                { return tid; }
  public Date getTimeStamp() throws RemoteException
                { return timestamp; }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() throws RemoteException { return false; }
  public boolean updateToDbase() throws RemoteException { return false; }
}