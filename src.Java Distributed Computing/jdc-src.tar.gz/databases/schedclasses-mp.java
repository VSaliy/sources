package dcj.examples.dbase;

import dcj.util.message.*;
import java.sql.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Date;
import java.lang.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: MPSchedResource, etc.
 * Example: 7-7
 * Description: The data objects reimplemented to perform message-passing.
 */
abstract class MPSchedDbaseItem {
  static MessageHandler handler;
  boolean valid;

  public boolean isValid() { return valid; }

  protected abstract boolean updateToDbase();
  protected abstract boolean updateFromDbase();
}

class MPSchedResource extends MPSchedDbaseItem {
  int rid;
  String name;
  int type;
  float size;

  MPSchedResource(int id) {
    rid = id;
    valid = updateFromDbase();
  }

  MPSchedResource(String n, int t, float s) {
    name = n;
    type = t;
    size = s;
    valid = true;

    // Try creating this new resource in the database
    try {
      Message nrm = new Message("newresource");
      nrm.addArg(n);
      nrm.addArg(new Integer(t));
      nrm.addArg(new Float(s));
      MPSchedDbaseItem.handler.sendMsg(nrm);
      Message nrr = MPSchedDbaseItem.handler.readMsg();
      Integer tmpI = (Integer)nrr.getArg(0);
      rid = tmpI.intValue();
    }
    catch (Exception e) {
      valid = false;
    }
  }

  public int    getId()           { return rid; }

  public String getName()         { return name; }
  public void   setName(String n) { name = n; updateToDbase(); }

  public int    getType()         { return type; }
  public void   setType(int t)    { type = t; updateToDbase();}

  public float  getSize()         { return size; }
  public void   setSize(float s)  { size = s; updateToDbase(); }

  public boolean updateFromDbase() {
    boolean success = true;

    try {
      Message gm = new Message("resource");
      gm.addArg(new Integer(rid));
      MPSchedDbaseItem.handler.sendMsg(gm);
      Message gr = MPSchedDbaseItem.handler.readMsg();
      name = (String)gr.getArg(0);
      Integer tmp = (Integer)gr.getArg(1);
      type = tmp.intValue();
      Float ftmp = (Float)gr.getArg(2);
      size = ftmp.floatValue();
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() {
    boolean success = true;

    try {
      Message pm = new Message("putresource");
      pm.addArg(name);
      pm.addArg(new Integer(type));
      pm.addArg(new Float(size));
      MPSchedDbaseItem.handler.sendMsg(pm);
      Message rpm = MPSchedDbaseItem.handler.readMsg();
      String resp = (String)rpm.getArg(0);
      if (resp.compareTo("success") != 0) {
        success = false;
      }
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  static public Vector getAllResources() {
    Vector resList = new Vector();
    try {
      // Get list of all resource ids in database
      Message rm = new Message("getresids");
      MPSchedDbaseItem.handler.sendMsg(rm);
      Message rrm = MPSchedDbaseItem.handler.readMsg();

      // Create new resource object from each, causing a request for
      // the resource data from the server
      Vector ridList = rrm.argList();
      Enumeration e = ridList.elements();
      while (e.hasMoreElements()) {
        Integer tmpI = (Integer)e.nextElement();
        int rid = tmpI.intValue();
        MPSchedResource res = new MPSchedResource(rid);
        // Add resource to return set if valid
        if (res.isValid()) {
          resList.addElement(res);
        }
      }
    }
    catch (Exception e) {}

    return resList;
  }
}

class MPSchedTask extends MPSchedDbaseItem {
  int tid;
  int type;
  float size;

  MPSchedTask(int id) {
    tid = id;
    valid = updateFromDbase();
  }

  MPSchedTask(int t, float sz) {
    type = t;
    size = sz;
    valid = false;

    // Try creating this new task in the database
    try {
      Message ntm = new Message("newtask");
      ntm.addArg(new Integer(t));
      ntm.addArg(new Float(sz));
      MPSchedDbaseItem.handler.sendMsg(ntm);
      Message ntr = MPSchedDbaseItem.handler.readMsg();
      Integer tmpI = (Integer)ntr.getArg(0);
      int tid = tmpI.intValue();
    }
    catch (Exception e) {
      valid = false;
    }
  }

  public int    getId()           { return tid; }

  public int    getType()         { return type; }
  public void   setType(int t)    { type = t; updateToDbase(); }

  public float  getSize()         { return size; }
  public void   setSize(float s)  { size = s; updateToDbase(); }

  public boolean updateFromDbase() {
    boolean success = true;

    try {
      Message gtm = new Message("gettask");
      gtm.addArg(new Integer(tid));
      MPSchedDbaseItem.handler.sendMsg(gtm);
      Message gtr = MPSchedDbaseItem.handler.readMsg();
      Integer tmpI = (Integer)gtr.getArg(0);
      type = tmpI.intValue();
      Float tmpF = (Float)gtr.getArg(1);
      size = tmpF.floatValue();
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  public boolean updateToDbase() {
    boolean success = true;

    try {
      Message ptm = new Message("puttask");
      ptm.addArg(new Integer(tid));
      ptm.addArg(new Integer(type));
      ptm.addArg(new Float(size));
      MPSchedDbaseItem.handler.sendMsg(ptm);
      Message ptr = MPSchedDbaseItem.handler.readMsg();
      String resp = (String)ptr.getArg(0);
      if (resp.compareTo("success") != 0)
        success = false;
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  static public Vector getAllTasks() {
    Vector taskList = new Vector();
    try {
      Message gtm = new Message("gettaskids");
      MPSchedDbaseItem.handler.sendMsg(gtm);
      Message gtr = MPSchedDbaseItem.handler.readMsg();
      Vector tidList = gtr.argList();
      Enumeration e = tidList.elements();
      while (e.hasMoreElements()) {
        Integer tmpI = (Integer)e.nextElement();
        int tid = tmpI.intValue();
        MPSchedTask task = new MPSchedTask(tid);
        if (task.isValid())
          taskList.addElement(task);
      }
    }
    catch (Exception e) {}

    return taskList;
  }
}

class TimeConstraint extends MPSchedDbaseItem {
  int ctype;
  int task1;
  int task2;

  // This constructor is used to create a representation
  // of a constraint in the database.
  public TimeConstraint(int type, int tid1, int tid2) {
    ctype = type;
    task1 = tid1;
    task2 = tid2;

    // Create a new record in the database.
    try {
      Message ncm = new Message("newconstraint");
      ncm.addArg(new Integer(type));
      ncm.addArg(new Integer(tid1));
      ncm.addArg(new Integer(tid2));
      MPSchedDbaseItem.handler.sendMsg(ncm);
      Message ncr = MPSchedDbaseItem.handler.readMsg();
      String resp = (String)ncr.getArg(0);
      if (resp.compareTo("success") != 0)
        valid = false;
      else
        valid = true;
    }
    catch (Exception e) {
      valid = false;
    }
  }

  public int getTask1Id() { return task1; }
  public int getTask2Id() { return task2; }
  public int getType() { return ctype; }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() { return false; }
  public boolean updateToDbase() { return false; }

  public static Vector allConstraintsFor(int tid) {
    Vector constraints = new Vector();

    try {
      Message gcm = new Message("getconstraints");
      gcm.addArg(new Integer(tid));
      MPSchedDbaseItem.handler.sendMsg(gcm);
      Message gcr = MPSchedDbaseItem.handler.readMsg();
      int numC = gcr.argList().size() / 3;
      for (int i = 0; i < numC; i++) {
        Integer tmpI = (Integer)gcr.getArg(3*i);
        int type = tmpI.intValue();
        tmpI = (Integer)gcr.getArg(3*i + 1);
        int tid1 = tmpI.intValue();
        tmpI = (Integer)gcr.getArg(3*i + 2);
        int tid2 = tmpI.intValue();
        TimeConstraint tc = new TimeConstraint(type, tid1, tid2);
        constraints.addElement(tc);
      }
    }
    catch (Exception e) { }

    return constraints;
  }
}

class ResAssignment extends MPSchedDbaseItem {
  int rid;
  int tid;
  Date timestamp;

  // Constructor used to create a local representation of
  // a resource assignment
  protected ResAssignment(int res, int task, Date time) {
    rid = res;
    tid = task;
    timestamp = time;
  }

  public int  getResourceId() { return rid; }
  public int  getTaskId() { return tid; }
  public Date getTimeStamp() { return timestamp; }

  // Static "constructor" used to create new resource
  // assignment in the remote database.
  static public ResAssignment newResAssignment(int rid, int tid,
                                               Date time) {
    ResAssignment r;

    // Create a new record in the database.
    try {
      Message nram = new Message("newresassign");
      nram.addArg(new Integer(rid));
      nram.addArg(new Integer(tid));
      nram.addArg(time);
      MPSchedDbaseItem.handler.sendMsg(nram);
	  Message nrar = MPSchedDbaseItem.handler.readMsg();
      String resp = (String)nrar.getArg(0);
      if (resp.compareTo("success") == 0)
        r = new ResAssignment(rid, tid, time);
      else
        r = null;
    }
    catch (Exception e) {
      r = null;
    }

    return r;
  }

  static public Vector assignmentsFor(int rid) {
    Vector ras = new Vector();

    try {
      Message grm = new Message("getresassignids");
      grm.addArg(new Integer(rid));
      MPSchedDbaseItem.handler.sendMsg(grm);
      Message grr = MPSchedDbaseItem.handler.readMsg();
      int numRas = grr.argList().size() / 2;
      for (int i = 0; i < numRas; i++) {
        Integer tmpI = (Integer)grr.getArg(2*i);
        int tid = tmpI.intValue();
        String dstr = (String)grr.getArg(2*i + 1);
        Date time = new Date(dstr);
        ResAssignment ra = new ResAssignment(rid, tid, time);
        ras.addElement(ra);
      }
    }
    catch (Exception e) {}

    return ras;
  }

  // This class represents non-indexed table data, so we can't
  // load or update one uniquely from the database
  public boolean updateFromDbase() { return false; }
  public boolean updateToDbase() { return false; }
}
