package dcj.examples.dbase;

import java.rmi.*;
import java.util.Vector;
import java.util.Date;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMISchedDbase
 * Example: 7-9
 * Description: Interface for an RMI "factory" class that creates stubs for
 *      remote data objects.
 */

public abstract interface RMISchedDbase extends Remote {
  // Methods for creating/retrieving resources
  public RMISchedResource getResource(int rid)
                            throws RemoteException;
  public RMISchedResource newResource(String n, int t, float s)
                            throws RemoteException;
  public Vector getAllResources() throws RemoteException;

  // Methods for creating/retrieving tasks
  public RMISchedTask getTask(int id) throws RemoteException;
  public RMISchedTask newTask(int t, float sz)
                        throws RemoteException;
  public Vector getAllTasks() throws RemoteException;

  // Methods for creating/retrieving constraints
  public RMITimeConstraint newConstraint(int type, int t1, int t2)
                             throws RemoteException;
  public Vector constraintsFor(int tid) throws RemoteException;

  // Methods for creating/retrieving resource assignments
  public RMIResAssignment newResAssignment(int rid, int tid,
                                           Date time)
                            throws RemoteException;
  public Vector assignmentsFor(int rid) throws RemoteException;
}