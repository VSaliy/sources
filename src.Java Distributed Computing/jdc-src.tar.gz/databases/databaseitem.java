package dcj.examples.dbase;

import java.sql.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: DatabaseItem
 * Example: 7-2
 * Description: Base interface for application objects stored in a database.
 */

abstract class DatabaseItem {
  static Connection dbConn;
  boolean valid;

  public boolean isValid() { return valid; }

  public abstract boolean updateToDbase();
  public abstract boolean updateFromDbase();
}