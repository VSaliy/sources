package dcj.examples.dbase;

import java.util.Date;
import java.util.Vector;
import java.sql.*;
import java.rmi.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Classes: RMIDatabaseItem, RMISchedResource, etc.
 * Example: 7-8
 * Description: Interfaces for RMI versions of the data objects.
 */

interface RMIDatabaseItem extends Remote {
  public boolean updateFromDbase() throws RemoteException;
  public boolean updateToDbase() throws RemoteException;
}

interface RMISchedResource extends RMIDatabaseItem {
  public boolean isValid() throws RemoteException;

  public int    getId() throws RemoteException;
  public String getName() throws RemoteException;
  public void   setName(String n) throws RemoteException;
  public int    getType() throws RemoteException;
  public void   setType(int t) throws RemoteException;
  public float  getSize() throws RemoteException;
  public void   setSize(float s) throws RemoteException;
}

interface RMISchedTask extends RMIDatabaseItem {
  public boolean isValid() throws RemoteException;

  public int    getId() throws RemoteException;
  public int    getType() throws RemoteException;
  public void   setType(int t) throws RemoteException;
  public float  getSize() throws RemoteException;
  public void   setSize(float s) throws RemoteException;
}

interface RMITimeConstraint extends RMIDatabaseItem {
  public boolean isValid() throws RemoteException;

  public int getTask1Id() throws RemoteException;
  public int getTask2Id() throws RemoteException;
  public int getType() throws RemoteException;
}

interface RMIResAssignment extends RMIDatabaseItem {
  public boolean isValid() throws RemoteException;

  public int  getResourceId() throws RemoteException;
  public int  getTaskId() throws RemoteException;
  public Date getTimeStamp() throws RemoteException;
}