package dcj.examples.messageV2;

import java.io.*;
import dcj.examples.message.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessMessage, MoveMessage, etc.
 * Example: 6-7
 * Description: Updated versions of the chess messages, that handle
 *      heterogeneous arguments.
 */

abstract class ChessMessage extends BasicMessage {
  protected ChessPlayer player;

  public ChessMessage(ChessPlayer p) { player = p; }
  public ChessMessage()              { player = null; }
}

class MoveMessage extends ChessMessage {
  public MoveMessage(ChessPlayer p) {
    super(p);
    setId("move");
  }

  public MoveMessage(String from, String to, int checkFlag) {
    setId("move");
    addArg(from);
    addArg(to);
    addArg(new Integer(checkFlag));
  }

  public boolean Do() {
    boolean success = true;
    BasicMsgHandler handler = BasicMsgHandler.current;

    String from = (String)argList.elementAt(0);
    String to = (String)argList.elementAt(1);
    String checkStr = (String)argList.elementAt(2);
    int checkFlag = Integer.valueOf(checkStr).intValue();

    try {
      if (!player.acceptMove(from, to, checkFlag)) {
        handler.sendMsg(new RejectMoveMessage());
      }
      else {
        ConfirmMoveMessage ccmsg =
          new ConfirmMoveMessage(from, to, checkFlag);
        handler.sendMsg(ccmsg);

        // We accepted the opponent's move, now send them
        // our counter-move, unless they just mated us...
        if (checkFlag == ChessPlayer.CHECKMATE) {
          ConcedeMessage cmsg = new ConcedeMessage();
          handler.sendMsg(cmsg);
        }
        else {
          player.nextMove(from, to, checkFlag);
          MoveMessage mmsg = new MoveMessage(from, to, checkFlag);
          handler.sendMsg(mmsg);
        }
      }
    }
    catch (IOException e) {
      success = false;
    }
    return success;
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;

    DataInputStream din = new DataInputStream(ins);

    try {
      String from = din.readUTF();
      addArg(from);
      String to = din.readUTF();
      addArg(to);
      int checkFlag = din.readInt();
      addArg(new Integer(checkFlag));

      // Got all of our arguments, now watch for the
      // end-of-message token
      String temp = din.readUTF();
      while (temp.compareTo(endToken) != 0) {
        temp = din.readUTF();
      }
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  public boolean writeArgs(OutputStream outs) {
    boolean success = true;
    DataOutputStream dout = new DataOutputStream(outs);

    String from = (String) argList.elementAt(0);
    String to = (String)argList.elementAt(1);
    Integer tmpInt = (Integer)argList.elementAt(2);
    int checkFlag = tmpInt.intValue();

    try {
      dout.writeUTF(from);
      dout.writeUTF(to);
      dout.writeInt(checkFlag);
      dout.writeUTF(endToken);
    }
    catch (IOException e) {
      success = false;
    }
    return success;
  }
}

class ConfirmMoveMessage extends ChessMessage {
  public ConfirmMoveMessage(String from, String to, int checkFlag) {
    setId("confirm");
    addArg(from);
    addArg(to);
    addArg(new Integer(checkFlag));
  }

  public ConfirmMoveMessage(ChessPlayer p) {
    super(p);
    setId("confirm");
  }

  public boolean Do(BasicMsgHandler handler) {
    // Opponent accepted our last move, so record it on our
    // copy of the game board.
    String from = argList.elementAt(1);
    String to = argList.elementAt(2);
    String cmateStr = argList.elementAt(3);
    int checkOrMate = Integer.toInt(cmateStr);
    player.moveAccepted(from, to, checkOrMate);
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;

    DataInputStream din = new DataInputStream(ins);

    try {
      String from = din.readString();
      addArg(from);
      String to = din.readString();
      addArg(to);
      int checkFlag = din.readInt();
      addArg(new Integer(checkFlag));

      // Got all of our arguments, now watch for the
      // end-of-message token
      String temp = din.readString();
      while (temp.compareTo(endToken) != 0) {
        temp = din.readString();
      }
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }

  public void writeArgs(OutputStream outs) {
    DataOutputStream dout = new DataOutputStream(outs);
    String from = (String) argList.elementAt(1);
    String to = (String)argList.elementAt(2);
    Integer tmpInt = (Integer)argList.elementAt(3);
    int checkFlag = tmpInt.toInt();

    dout.writeUTF(from);
    dout.writeChar(tokenDelim.charAt(0));
    dout.writeUTF(to);
    dout.writeChar(tokenDelim.charAt(0));
    dout.writeInt(checkFlag);
    dout.writeChar(tokenDelim.charAt(0));
    dout.writeUTF(endToken);
    dout.writeChar(tokenDelim.charAt(0));
  }
}

class RejectMoveMessage extends ChessMessage {
  public RejectMoveMessage(ChessPlayer p) {
    super(p);
  }

  public boolean Do(BasicMsgHandler handler) {
    String newFrom;
    String newTo;
    int newCheckFlag;

    if (player.nextMove(newFrom, newTo, newCheckFlag)) {
      MoveMessage mmsg = new MoveMessage(player);
      mmsg.addArg(newFrom);
      mmsg.addArg(newTo);
      mmsg.addArg(new Integer(newCheckFlag));
      handler.sendMsg(mmsg);
    }
    else {
      // Our player didn't come up with another move, so
      // concede the game
      handler.sendMsg(new ConcedeMessage);
    }
  }
}

class ConcedeMessage extends ChessMessage {
  public ConcedeMessage() {
    setId("concede");
  }

  public ConcedeMessage(ChessPlayer p) {
    super(p);
    setId("concede");
  }

  public boolean Do() {
    player.conceded();
    return true;
  }
}
