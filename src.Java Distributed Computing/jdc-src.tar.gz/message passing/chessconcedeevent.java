package dcj.examples.message;

import java.util.EventObject;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: ChessConcedeEvent
 * Example: 6-16
 * Description: A chess "message" implemented as a Java event.  This message
 *      concedes the game to the receiving player.
 */

public class ChessConcedeEvent extends EventObject {
  // Just a placeholder class, no data or methods needed
  public ChessConcedeEvent(ChessPlayer src) {
    super(src);
  }
}