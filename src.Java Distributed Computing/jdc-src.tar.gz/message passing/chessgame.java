package dcj.examples.messageV1;

import java.lang.Thread;
import java.io.*;

class ChessGame {
  public static void main(String[] argv) {
    PipedInputStream win = null;
    PipedOutputStream wout = null;
    PipedInputStream bin = null;
    PipedOutputStream bout = null;

    System.out.println("Building piped streams...");

    try {
      win = new PipedInputStream();
      bin = new PipedInputStream();
      wout = new PipedOutputStream(bin);
      bout = new PipedOutputStream(win);
    }
    catch (IOException e) {
      System.out.println("Failed to create streams.");
      System.exit(1);
    }

    System.out.println("Building chess servers...");
    ChessServer white = new ChessServer(win, wout);
    ChessServer black = new ChessServer(bin, bout);
    Thread whiteThr = new Thread(white);
    Thread blackThr = new Thread(black);

    String from = "x";
    String to = "x";
    int checkFlag = ChessPlayer.NO_CHECK;
    if (white.getPlayer().nextMove(from, to, checkFlag)) {
      try {
        System.out.println("Sending first message...");
        white.sendMsg(new MoveMessage(from, to, checkFlag));
      }
      catch (IOException e) {
        System.out.println("Failed sending first message.");
      }

      try {
	  if (black.readMsg() != null)
          System.out.println("Black got it...");
        else
          System.out.println("Black didn't get it...");
      }
      catch (IOException e) {
        System.out.println("Failed reading message...");
      }
    }
    else {
      System.out.println("White didn't come up with a starting move.");
      System.exit(1);
    }

    System.out.println("Starting threads...");
    whiteThr.start();
    blackThr.start();

    System.out.println("Waiting for threads to die...");
    while (whiteThr.isAlive() && blackThr.isAlive()) {}
  }
}

    