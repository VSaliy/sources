import java.io.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: MoveMessage
 * Example: 6-9
 * Description: Updated version of the MoveMessage that uses ChessMove
 *      objects to transmit the move to the remote opponent.
 */

class MoveMessage extends ChessMessage {
  public MoveMessage(ChessPlayer p) {
    super(p);
    setId("move");
  }

  public MoveMessage(String from, String to, int checkFlag) {
    setId("move");
    ChessMove move = new ChessMove(from, to, checkFlag);
    addArg(move);
  }

  public String Do() {
    BasicMsgHandler handler = BasicMsgHandler.current;
    ChessMove move = (ChessMove)argList.elementAt(0);

    if (!player.acceptMove(move.from(), move.to(), move.checkFlag())) {
      handler.sendMsg(new RejectMoveMessage());
    }
    else {
      ConfirmMoveMessage ccmsg =
        new ConfirmMoveMessage(move.from(), move.to(), move.checkFlag());
      handler.sendMsg(ccmsg);

      // We accepted the opponent's move, now send them
      // our counter-move, unless they just mated us...
      if (checkFlag == ChessPlayer.CHECKMATE) {
        ConcedeMessage cmsg = new ConcedeMessage();
        handler.sendMsg(cmsg);
      }
      else {
        String from, to;
        int checkFlag;
        player.nextMove(from, to, checkFlag);
        MoveMessage mmsg = new MoveMessage(from, to, checkFlag);
        handler.sendMsg(mmsg);
      }
    }
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;

    DataInputStream din = new DataInputStream(ins);
    ObjectInputStream oin = new ObjectInputStream(ins);

    try {
      ChessMove move = (ChessMove)oin.readObject();
      addArg(move);

      // Got all of our arguments, now watch for the
      // end-of-message token
      String temp = din.readUTF();
      while (temp.compareTo(endToken) != 0) {
        temp = din.readUTF();
      }
    }
    catch (Exception e) {
      success = false;
    }

    return success;
  }


  public boolean writeArgs(OutputStream outs) {
    boolean success = true;
    DataOutputStream dout = new DataOutputStream(outs);
    ObjectOutputStream oout = new ObjectOutputStream(outs);
    ChessMove move = (ChessMove)argList.elementAt(0);

    try {
      oout.writeObject(move);
      dout.writeUTF(endToken);
    }
    catch (IOException e) {
      success = false;
    }
    return success;
  }
}