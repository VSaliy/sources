package dcj.examples.message;

import java.rmi.*;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMIChessMoveImpl
 * Example: 6-19
 * Description: Server implementation of the RMI-based chess move object.
 */

public class RMIChessMoveImpl
    implements RMIChessMove, Remote {
  String fromPos;
  String toPos;
  boolean checkFlag;

  public RMIChessMoveImpl() {
    fromPos = null;
    toPos = null;
    checkFlag = false;
  }

  public RMIChessMoveImpl(String from, String to, boolean ckFlag) {
    fromPos = from;
    toPos = to;
    checkFlag = ckFlag;
  }

  public String from() throws RemoteException {
    return fromPos;
  }

  public void setFrom(String f) throws RemoteException {
    fromPos = f;
  }

  public String to() throws RemoteException {
    return toPos;
  }

  public void setTo(String t) throws RemoteException {
    toPos = t;
  }

  public boolean checkFlag() throws RemoteException {
    return checkFlag;
  }

  public void setCheckFlag(boolean f) throws RemoteException {
    checkFlag = f;
  }
}