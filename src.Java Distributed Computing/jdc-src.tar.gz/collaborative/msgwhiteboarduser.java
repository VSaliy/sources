package dcj.examples.Collaborative;

import dcj.util.Collaborative.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Hashtable;
import java.util.Properties;
import java.io.IOException;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: MsgWhiteboardUser
 * Example: A-1
 * Description: Message-passing whiteboard user, suitable for use in applets
 *      on browsers without RMI support.
 */

class Msg {
  public Object data;
  public String tag;

  public Msg(Object o, String t) {
    data = o;
    tag = t;
  }
}

class CommHelper extends Thread {
  Collaborator collaborator;
  static Vector msgs = new Vector();

  public CommHelper(Collaborator c) {
    collaborator = c;
  }

  public static void addMsg(Object o, String t) {
    synchronized (msgs) {
      msgs.addElement(new Msg(o, t));
    }
  }

  public void run() {
    while (true) {
      try {
        Msg m = null;
        synchronized (msgs) {
          m = (Msg)msgs.elementAt(0);
          msgs.removeElementAt(0);
        }
        collaborator.broadcast(m.tag, m.data);
      }
      catch (Exception e) {}
    }
  }
}

public class MsgWhiteboardUser
    extends MessageCollaborator
    implements java.awt.event.MouseListener,
               java.awt.event.MouseMotionListener
{
  protected Hashtable lastPts = new Hashtable();
  protected Component whiteboard;
  protected Image buffer;

  public MsgWhiteboardUser(String name, Color color,
                           String host, int port) {
    super(host, port, name);
    getIdentity().setProperty("color", color);
    System.out.println("color = " + color.getRed()
                       + " " + color.getGreen() + " "
                       + color.getBlue());
    buildUI();
    CommHelper helper = new CommHelper(this);
    helper.start();
  }

  protected void buildUI() {
    Frame f = new Frame();
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    f.setLayout(gridbag);
    f.addNotify();
    c.fill = GridBagConstraints.BOTH;
    c.gridwidth = GridBagConstraints.REMAINDER;
    Canvas canvas1 = new java.awt.Canvas();
    canvas1.setSize(240,180);
    canvas1.setBackground(Color.white);
    gridbag.setConstraints(canvas1, c);
    f.add(canvas1);
    String name = null;
    try {
      name = getIdentity().getName();
    }
    catch (Exception e) {
      name = "unknown";
    }
    Label label1 = new java.awt.Label("Your name: " + name);
    label1.setSize(100,30);
    gridbag.setConstraints(label1, c);
    f.add(label1);
    f.setSize(240,210);
    f.show();
    whiteboard = canvas1;
    whiteboard.addMouseListener(this);
    whiteboard.addMouseMotionListener(this);
    buffer = whiteboard.createImage(f.getSize().width,
                                    f.getSize().height);
  }

  protected void nextLine(String agent, Point pt, Color c) {
    Graphics g = buffer.getGraphics();
    g.setColor(c);
    Point lastPt = (Point)lastPts.get(agent);
    g.drawLine(lastPt.x, lastPt.y, pt.x, pt.y);
    whiteboard.getGraphics().drawImage(buffer, 0, 0, whiteboard);
  }

  public void mousePressed(MouseEvent ev) {
    //System.out.println("Got mouse pressed");
    Point evPt = ev.getPoint();
    try {
      lastPts.put(getIdentity().getName(), evPt);
      CommHelper.addMsg(evPt, "start");
    }
    catch (Exception e) {}
  }

  public void mouseReleased(MouseEvent ev) {
    Point evPt = ev.getPoint();
    try {
      nextLine(getIdentity().getName(), evPt,
               (Color)getIdentity().getProperty("color"));
      lastPts.remove(getIdentity().getName());

      CommHelper.addMsg(evPt, "end");
    }
    catch (Exception e) {}
  }

  public void mouseDragged(MouseEvent ev) {
    //System.out.println("Got mouse drag");
    Point evPt = ev.getPoint();
    try {
      nextLine(getIdentity().getName(), evPt,
               (Color)getIdentity().getProperty("color"));
      lastPts.put(getIdentity().getName(), evPt);

      CommHelper.addMsg(evPt, "drag");
    }
    catch (Exception e) {
      //System.out.println("exception");
    }
    //System.out.println("Finished drag.");
  }

  public void mouseExited(MouseEvent ev) {}
  public void mouseMoved(MouseEvent ev) {}
  public void mouseClicked(MouseEvent ev) {}
  public void mouseEntered(MouseEvent ev) {}

  public boolean notify(String tag, Object data, Identity src)
      throws IOException {

    if (src.getName().compareTo(getIdentity().getName()) == 0) {
      return true;
    }
    //System.out.println("Got notified");
    Color origColor = null;
    Color agentColor = null;
    Graphics gr = buffer.getGraphics();
    try {
      agentColor = (Color)src.getProperty("color");
      if (agentColor != null) {
        //System.out.println("src color = " + agentColor.getRed()
          //                 + " " + agentColor.getGreen() + " "
            //               + agentColor.getBlue());
        gr.setColor(agentColor);
      }
      else {
        System.out.println("No agent color available.");
      }
    }
    catch (Exception exc) {
      System.out.println("Exception while switching colors.");
      exc.printStackTrace();
    }

    if (tag.compareTo("start") == 0) {
      lastPts.put(src.getName(), data);
    }
    else if (tag.compareTo("drag") == 0) {
      Point lastPt = (Point)lastPts.get(src.getName());
      Point currPt = (Point)data;
      gr.drawLine(lastPt.x, lastPt.y, currPt.x, currPt.y);
      lastPts.put(src.getName(), data);
    }
    else if (tag.compareTo("end") == 0) {
      Point lastPt = (Point)lastPts.get(src.getName());
      Point currPt = (Point)data;
      gr.drawLine(lastPt.x, lastPt.y, currPt.x, currPt.y);
      lastPts.remove(src.getName());
    }

    whiteboard.getGraphics().drawImage(buffer, 0, 0, whiteboard);

    return true;
  }
}