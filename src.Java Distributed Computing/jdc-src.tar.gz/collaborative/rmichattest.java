package dcj.util.Collaborative;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RMISecurityManager;
import java.util.Properties;

public class RMIChatTest {
  public static void main(String argv[]) {
    // Install a security manager
    System.setSecurityManager(new RMISecurityManager());
    try {
      String name = argv[0];
      String host = argv[1];
      String mname = argv[2];
      RMIChatClient client = new RMIChatClient(name, host, mname);
      while (true) {}
    }
    catch (Exception e) {
      System.out.println("Caught exception:");
      e.printStackTrace();
    }
  }
}