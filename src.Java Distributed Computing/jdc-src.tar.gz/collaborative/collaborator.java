package dcj.util.Collaborative;

import java.util.Properties;
import java.io.IOException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: Collaborator
 * Example: 9-3
 * Description: Interface for a participant in a remote collaboration.
 */

public interface Collaborator {
  public Identity getIdentity();

  // Connect to a mediator - subclasses dictate properties needed
  public boolean connect(Properties p);

  // Outgoing messages/data
  public boolean send(String tag, String msg, Identity dst)
      throws IOException;
  public boolean send(String tag, Object data, Identity dst)
      throws IOException;
  public boolean broadcast(String tag, String msg)
      throws IOException;
  public boolean broadcast(String tag, Object data)
      throws IOException;

  // Incoming messages/data
  public boolean notify(String tag, String msg, Identity src)
      throws IOException;
  public boolean notify(String tag, Object data, Identity src)
      throws IOException;
}