package dcj.util.Collaborative;

import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: RMIMediatorImpl
 * Example: 9-12
 * Description: Implementation of the RMI-based mediator.
 */

public class RMIMediatorImpl
    extends UnicastRemoteObject implements RMIMediator
{
  Hashtable clients = new Hashtable();
  Vector idList = new Vector();

  public RMIMediatorImpl() throws RemoteException {
    super();
  }

  public boolean register(Identity i, RMICollaborator c)
      throws RemoteException {
    System.out.println("Registering member " + i.getId()
                       + " as " + c.getIdentity().getName());
    clients.put(i, c);
    return true;
  }

  public Identity newMember() throws RemoteException {
    int max = -1;
    boolean found = true;
    Enumeration enum = idList.elements();
    while (enum.hasMoreElements()) {
	Identity id = (Identity)enum.nextElement();
      int i = id.getId();
      if (i > max) {
        max = i;
      }
    }

    Identity newId = new Identity(max + 1);
    synchronized (idList) {
      idList.addElement(newId);
    }
    return newId;
  }

  public boolean remove(Identity i) throws RemoteException {
    boolean success = true;
    synchronized (idList) {
      synchronized (clients) {
        if (idList.removeElement(i) && clients.remove(i) != null) {
          success = true;
        }
        else {
          success = false;
        }
      }
    }
    return success;
  }

  public Vector getMembers() throws RemoteException {
    synchronized (idList) {
      return (Vector)idList.clone();
    }
  }

  public boolean send(Identity to, Identity from,
                      String mtag, String msg)
      throws IOException, RemoteException {
    boolean success = false;
    RMICollaborator c = getMember(to);
    synchronized (c) {
      if (c != null) {
        success = c.notify(mtag, msg, from);
      }
    }

    return success;
  }

  public boolean send(Identity to, Identity from,
                      String mtag, Object data)
      throws IOException, RemoteException {
    boolean success = false;
    RMICollaborator c = getMember(to);
    synchronized (c) {
      if (c != null) {
        success = c.notify(mtag, data, from);
      }
    }
    return success;
  }

  public boolean broadcast(Identity from, String mtag,
                           String msg)
      throws IOException, RemoteException {
    System.out.println("Broadcasting...");
    boolean success = true;
    Enumeration ids;
    synchronized (clients) {
      ids = clients.keys();
    }
    RMICollaborator target = null;
    while (ids.hasMoreElements()) {
      Identity i = (Identity)ids.nextElement();
      synchronized (clients) {
        target = (RMICollaborator)clients.get(i);
      }
      synchronized (target) {
        if (target == null ||
            !target.notify(mtag, msg, from)) {
          success = false;
        }
      }
    }
    return success;
  }

  public boolean broadcast(Identity from, String mtag,
                           Object data)
      throws IOException, RemoteException {
    boolean success = true;
    Enumeration ids;
    synchronized (clients) {
      ids = clients.keys();
    }
    RMICollaborator target = null;
    while (ids.hasMoreElements()) {
      Identity i = (Identity)ids.nextElement();
      synchronized (clients) {
        target = (RMICollaborator)clients.get(i);
      }
      synchronized (target) {
        if (target == null ||
            !target.notify(mtag, data, from)) {
          success = false;
        }
      }
    }
    return success;
  }

  protected RMICollaborator getMember(Identity i) {
    Enumeration ids;
    synchronized (clients) {
      ids = clients.keys();
    }
    RMICollaborator c = null;
    Identity tmp;
    while (c == null && ids.hasMoreElements()) {
       tmp = (Identity)ids.nextElement();
       if (tmp.equals(i)) {
         synchronized (clients) {
           c = (RMICollaborator)clients.get(tmp);
         }
       }
    }
    return c;
  }

  public static void main(String argv[]) {
    // Install a security manager
    System.setSecurityManager(new RMISecurityManager());

    try {
      String name = "TheMediator";
      System.out.println("Registering RMIMediatorImpl as \""
                         + name + "\"");
      RMIMediatorImpl mediator = new RMIMediatorImpl();
      System.out.println("Created mediator, binding...");
      Naming.rebind(name, mediator);
      System.out.println("Remote mediator ready...");
    }
    catch (Exception e) {
      System.out.println("Caught exception while registering: "
                         + e);
    }
  }
}