package dcj.util.Collaborative;

public class MediatorTest {
  public static void main(String argv[]) {
    MessageMediator m = new MessageMediator();
    Thread mthread = new Thread(m);
    mthread.run();
  }
}