package dcj.util.Collaborative;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RMISecurityManager;

public class RMIMediatorTest {
  public static void main(String argv[]) {
    // Install a security manager
    System.setSecurityManager(new RMISecurityManager());

    try {
      String name = "TheMediator";
      System.out.println("Registering RMIMediatorImpl as \""
                         + name + "\"");
      RMIMediatorImpl mediator = new RMIMediatorImpl();
      System.out.println("Created mediator, binding...");
      Naming.rebind(name, mediator);
      System.out.println("Remote mediator ready...");
    }
    catch (Exception e) {
      System.out.println("Caught exception while registering: "
                         + e);
    }
  }
}