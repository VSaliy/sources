package dcj.util.Collaborative;

import java.io.*;
import java.util.Vector;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: CollaboratorMessage
 * Example: 9-8
 * Description: A message used by collaborators.
 */

public class CollaboratorMessage extends Message
{
  protected Collaborator collaborator = null;

  public CollaboratorMessage(Collaborator c) {
    collaborator = c;
  }

  public CollaboratorMessage(String mid) {
    super(mid);
  }

  public boolean Do()
  {
    boolean success = false;

    try {
      String mtype = messageID();
      Identity from = (Identity)getArg(0);
      try {
        String s = (String)getArg(1);
        collaborator.notify(mtype, s, from);
        success = true;
      }
      catch (ClassCastException cce) {
        // Argument isn't a string, so send it as an object
        Object oarg = getArg(1);
        collaborator.notify(mtype, oarg, from);
        success = true;
      }
    }
    catch (Exception e) {
      success = false;
    }
    return success;
  }

  // We want to handle all messages to the collaborator
  public boolean handles(String msgId) { return true; }

  public Message newCopy() {
    CollaboratorMessage copy;
    if (collaborator != null) {
      // Make a new CollaboratorMessage with the same Collaborator
      copy = new CollaboratorMessage(collaborator);
      copy.setId(messageID());
    }
    else {
      copy = new CollaboratorMessage(messageID());
    }
    return copy;
  }
}
