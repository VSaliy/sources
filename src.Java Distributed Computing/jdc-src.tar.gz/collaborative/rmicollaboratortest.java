package dcj.util.Collaborative;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.RMISecurityManager;
import java.util.Properties;

public class RMICollaboratorTest {
  public static void main(String argv[]) {
    // Install a security manager
    System.setSecurityManager(new RMISecurityManager());
    try {
      String name = argv[0];
      String host = argv[1];
      String mname = argv[2];
      Properties props = new Properties();
      props.put("host", host);
      props.put("mediatorName", mname);
      RMICollaboratorImpl c = new RMICollaboratorImpl(name);
      if (c.connect(props)) {
        System.out.println("Got mediator...");
        c.broadcast("msg", "hello world");
      }
    }
    catch (Exception e) {
      System.out.println("Caught exception:");
      e.printStackTrace();
    }
  }
}