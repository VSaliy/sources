package dcj.util.Collaborative;

import java.io.IOException;

public class CollaboratorTest {
  public static void main(String argv[]) {
    MessageCollaborator c =
      new MessageCollaborator(argv[1], Integer.valueOf(argv[2]).intValue(),
                              argv[0]);
    try {
      while (c.getIdentity() == null) {}
      c.broadcast("msg", "hello world");
    }
    catch (IOException e) {}
    while (c != null) {}
  }
}