package dcj.util.Collaborative;

import java.io.*;
import java.util.Vector;

public class Message
{
  protected String id;
  protected Vector argList;
  protected String endToken = "END";

  public Message() {
    id = "message";
    argList = new Vector();
  }

  public Message(String mid) {
    id = mid;
    argList = new Vector();
  }

  public void addArg(Object arg) {
    argList.addElement(arg);
  }

  public String messageID() {
    return id;
  }

  public void setId(String mid) {
    id = mid;
  }

  public Object getArg(int idx) {
    Object arg = null;
    if (idx < argList.size()) {
      arg = argList.elementAt(idx);
    }

    return arg;
  }

  public Vector argList() {
    Vector listCopy = (Vector)argList.clone();
    return listCopy;
  }

  public boolean readArgs(InputStream ins) {
    boolean success = true;
    
    // Read tokens until the "end-of-message" token is seen.
    try {
      DataInputStream din = new DataInputStream(ins);
      String token = din.readUTF();
      while (token.compareTo(endToken) != 0) {
        // If an object argument is coming, read with an ObjectInputStream
        if (token.compareTo("#OBJ") == 0) {
          // Next argument is a non-string Object
          ObjectInputStream oin = new ObjectInputStream(ins);
          Object oarg = oin.readObject();
          addArg(oarg);
        }
        else {
          // The string itself is the argument, so save it
          addArg(token);
        }
        token = din.readUTF();
      }
    }
    catch (Exception e) {
      // Failed to read complete argument list.
      success = false;
    }
    return success;
  }

  public boolean writeArgs(OutputStream outs) {
    int len = argList.size();
    boolean success = true;
    
    // Write each argument in order
    try {
      DataOutputStream dout = new DataOutputStream(outs);

      for (int i = 0; i < len; i++) {
        Object arg = argList.elementAt(i);
        try {
          String sarg = (String)arg;
          System.out.println("m: sending token \"" + sarg + "\"");
          dout.writeUTF(sarg);
        }
        catch (ClassCastException ce) {
          // Argument wasn't a string, so send it as an object
          System.out.println("m: sending object");
          dout.writeUTF("#OBJ");
          ObjectOutputStream oout = new ObjectOutputStream(outs);
          oout.writeObject(arg);
        }
        catch (Exception e) {
          // Something else went wrong, indicate failure
          success = false;
          System.out.println("m: Got exception writing args");
        }
      }

      // Finish with the end-of-message token
      dout.writeUTF(endToken);
    }
    catch (Exception e) {
      success = false;
    }
    return success;
  }

  public boolean Do()
  {
    return false;
  }

  public boolean handles(String msgId) { return false; }
  public Message newCopy() { return new Message(id); }
}

