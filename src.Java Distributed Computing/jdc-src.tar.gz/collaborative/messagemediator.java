package dcj.util.Collaborative;

import java.lang.Runnable;
import java.util.Vector;
import java.util.Enumeration;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: MessageMediator
 * Example: 9-5
 * Description: A mediator that uses message-passing for its communication.
 */

public class MessageMediator implements Mediator, Runnable {
  MessageHandler mhandler = new MessageHandler();
  ServerSocket socket = null;
  int port = 5009;

  public MessageMediator(int p) {
    initHandler();
    port = p;
  }

  public MessageMediator() {
    initHandler();
  }

  protected void initHandler() {
    // Add the mediator message "prototype" to the handler
    Message m = new MediatorMessage(this);
    mhandler.addMessageType(m);
  }

  public void run() {
    // Make the server socket
    try {
      socket = new ServerSocket(port);
    }
    catch (IOException e) {
      System.out.println("Failed to bind to port " + port);
      return;
    }

    System.out.println("Mediator running on port " + port);

    // Listen for new clients...
    while (true) {
      try {
        Socket clientConn = socket.accept();
        Identity i = newMember();
        mhandler.addAgent(i.getId(), clientConn.getInputStream(),
                          clientConn.getOutputStream());
        System.out.println("Got new connection...");
        Message imsg = new Message("identity");
        imsg.addArg(i);
        mhandler.sendMsg(imsg, i.getId());
      }
      catch (Exception e) {}
    }
  }

  public Identity newMember() {
    int id = mhandler.nextAgentId();
    Identity i = new Identity(id);
    return i;
  }

  public boolean remove(Identity i) {
    int id = i.getId();
    boolean success = mhandler.removeAgent(id);
    return success;
  }

  public Vector getMembers() {
    Vector members = new Vector();
    Vector ids = mhandler.getAgentIds();
    Enumeration e = ids.elements();
    while (e.hasMoreElements()) {
      Integer id = (Integer)e.nextElement();
      Identity i = new Identity(id.intValue());
      members.addElement(i);
    }
    return members;
  }

  public boolean send(Identity to, Identity from, String mtag, String s)
      throws IOException {
    boolean success = false;
    Message msg = new Message(mtag);
    msg.addArg(from);
    msg.addArg(s);
    return mhandler.sendMsg(msg, to.getId());
  }

  public boolean broadcast(Identity from, String mtag, String s)
      throws IOException {
    System.out.println("mm: Broadcasting message \"" + mtag + s + "\"");
    Message msg = new Message(mtag);
    msg.addArg(from);
    msg.addArg(s);
    return mhandler.sendMsg(msg);
  }

  public boolean send(Identity to, Identity from, String mtag, Object o)
      throws IOException {
    Message msg = new Message(mtag);
    msg.addArg(from);
    msg.addArg(o);
    return mhandler.sendMsg(msg, to.getId());
  }

  public boolean broadcast(Identity from, String mtag, Object o)
      throws IOException {
    Message msg = new Message(mtag);
    msg.addArg(from);
    msg.addArg(o);
    return mhandler.sendMsg(msg);
  }
}