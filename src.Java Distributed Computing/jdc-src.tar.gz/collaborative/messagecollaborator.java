package dcj.util.Collaborative;

import java.io.IOException;
import java.net.Socket;
import java.util.Properties;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: MessageCollaborator
 * Example: 9-7
 * Description: A colaborator that communicates using message-passing.
 */

public class MessageCollaborator implements Collaborator
{
  MessageHandler handler = new MessageHandler();
  Identity id = null;
  String name;

  public MessageCollaborator(String n) {
    initHandler();
    name = n;
  }

  public MessageCollaborator(String host, int port, String n) {
    initHandler();
    name = n;
    Properties p = new Properties();
    p.put("host", host);
    p.put("port", String.valueOf(port));
    connect(p);
  }

  protected void initHandler() {
    handler.addMessageType(new CollaboratorMessage(this));
  }

  public Identity getIdentity() { return id; }

  public boolean connect(Properties p) {
    boolean success = false;

    String host = p.getProperty("host");
    String itmp = p.getProperty("port");
    if (host != null && itmp != null) {
      try {
        int port = Integer.parseInt(itmp);
        // Make a socket connection to the mediator.
        Socket mConn = new Socket(host, port);
        int pid = handler.addAgent(mConn.getInputStream(),
                                  mConn.getOutputStream());
        System.out.println("Got socket to Mediator, id = "
                           + id + "...");
        // The mediator should send us an identity in a message...
        Message imsg = handler.readMsg(pid);
        System.out.println("Got message with id = " + imsg.messageID());
        if (imsg.messageID().compareTo("identity") == 0) {
          id = (Identity)imsg.getArg(0);
          id.setName(name);
          System.out.println("Got identity from mediator, id = "
                             + id.getId() + "...");
          success = true;
        }
        else {
          handler.removeAgent(pid);
          success = false;
        }
      }
      catch (Exception e) {
        success = false;
      }
    }
    else {
      success = false;
    }
    return success;
  }

  public boolean send(String tag, String msg, Identity dst)
      throws IOException {
    boolean success = false;
    Message m = new Message("send");
    m.addArg(getIdentity());
    m.addArg(dst);
    m.addArg(tag);
    m.addArg(msg);
    success = handler.sendMsg(m);

    return success;
  }

  public boolean send(String tag, Object data, Identity dst)
      throws IOException {
    boolean success = false;
    Message m = new Message("send");
    m.addArg(getIdentity());
    m.addArg(dst);
    m.addArg(tag);
    m.addArg("#OBJ");
    m.addArg(data);
    success = handler.sendMsg(m);
    return success;
  }

  public boolean broadcast(String tag, String msg)
      throws IOException {
    boolean success = false;
    Message m = new Message("broadcast");
    m.addArg(getIdentity());
    m.addArg(tag);
    m.addArg(msg);
    System.out.println("mc: Sending broadcast message \"" + tag + "\"");
    success = handler.sendMsg(m);
    System.out.println("mc: success = " + success);
    return success;
  }

  public boolean broadcast(String tag, Object data)
      throws IOException {
    boolean success = true;
    Message m = new Message("broadcast");
    m.addArg(getIdentity());
    m.addArg(tag);
    m.addArg("#OBJ");
    m.addArg(data);
    success = handler.sendMsg(m);
    return success;
  }

  public boolean notify(String tag, String msg, Identity src)
      throws IOException {
    System.out.println("Received \"" + tag + "\" message \""
                       + msg + "\" from " + src.getName());
    return true;
  }

  public boolean notify(String tag, Object data, Identity src)
      throws IOException {
    System.out.println("Received \"" + tag + "\" object \""
                       + data + "\" from " + src.getName());
    return true;
  }
}