package dcj.examples.Collaborative;

import dcj.util.Collaborative.*;
import java.awt.event.*;
import java.awt.*;
import java.util.Hashtable;
import java.util.Properties;
import java.io.IOException;
import java.rmi.RemoteException;

/**
 * Source code from "Java Distributed Computing", by Jim Farley.
 *
 * Class: WhiteboardUser
 * Example: 10-2
 * Description: A collaborator in an RMI-based shared whiteboard.
 */

public class WhiteboardUser
    extends RMICollaboratorImpl
    implements java.awt.event.MouseListener,
               java.awt.event.MouseMotionListener
{
  protected Hashtable lastPts = new Hashtable();
  protected Component whiteboard;
  protected Image buffer;

  public WhiteboardUser(String name, Color color,
                        String host, String mname)
      throws RemoteException {
    super(name, host, mname);
    getIdentity().setProperty("color", color);
    buildUI();
  }

  protected void buildUI() {
    Frame f = new Frame();
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    f.setLayout(gridbag);
    f.addNotify();
    c.fill = GridBagConstraints.BOTH;
    c.gridwidth = GridBagConstraints.REMAINDER;
    Canvas canvas1 = new java.awt.Canvas();
    canvas1.setSize(240,180);
    canvas1.setBackground(Color.white);
    gridbag.setConstraints(canvas1, c);
    f.add(canvas1);
    String name = null;
    try {
      name = getIdentity().getName();
    }
    catch (Exception e) {
      name = "unknown";
    }
    Label label1 = new java.awt.Label("Your name: " + name);
    label1.setSize(100,30);
    gridbag.setConstraints(label1, c);
    f.add(label1);
    f.setSize(240,210);
    f.show();
    whiteboard = canvas1;
    whiteboard.addMouseListener(this);
    whiteboard.addMouseMotionListener(this);
    buffer = whiteboard.createImage(f.getSize().width,
                                    f.getSize().height);
  }

  protected void nextLine(String agent, Point pt, Color c) {
    Graphics g = buffer.getGraphics();
    if (c != null)
      g.setColor(c);
    Point lastPt = (Point)lastPts.get(agent);
    g.drawLine(lastPt.x, lastPt.y, pt.x, pt.y);
    whiteboard.getGraphics().drawImage(buffer, 0, 0, whiteboard);
  }

  public void mousePressed(MouseEvent ev) {
    //System.out.println("Got mouse pressed");
    Point evPt = ev.getPoint();
    try {
      broadcast("start", evPt);
    }
    catch (Exception e) {}
  }

  public void mouseReleased(MouseEvent ev) {
    Point evPt = ev.getPoint();
    try {
      broadcast("end", evPt);
    }
    catch (Exception e) {}
  }

  public void mouseDragged(MouseEvent ev) {
    //System.out.println("Got mouse drag");
    Point evPt = ev.getPoint();
    try {
      broadcast("drag", evPt);
    }
    catch (Exception e) {
      //System.out.println("exception");
    }
    //System.out.println("Finished drag.");
  }

  public void mouseExited(MouseEvent ev) {}
  public void mouseMoved(MouseEvent ev) {}
  public void mouseClicked(MouseEvent ev) {}
  public void mouseEntered(MouseEvent ev) {}

  public boolean notify(String tag, Object data, Identity src)
      throws IOException, RemoteException {

    Color agentColor = null;
    try {
      agentColor = (Color)src.getProperty("color");
    }
    catch (Exception exc) {}

    if (tag.compareTo("start") == 0) {
      lastPts.put(src.getName(), data);
    }
    else if (tag.compareTo("drag") == 0) {
      nextLine(src.getName(), (Point)data, agentColor);
      lastPts.put(src.getName(), data);
    }
    else if (tag.compareTo("end") == 0) {
      nextLine(src.getName(), (Point)data, agentColor);
      lastPts.remove(src.getName());
    }

    return true;
  }
}