import java.awt.*;
import sql.*;
import java.util.regex.*;
import javax.swing.*;

public class DisplayQueryResults extends JFrame {
   static final String DRIVER = "com.mysql.jdbc.Driver";
   static final String DATABASE_URL = "jdbc:mysql://localhost/library";
   static final String USERNAME = "mike";
   static final String PASSWORD = "password";

   static final String DEFAULT_QUERY = "Select * from books";

   private ResultSetTableModel tableModel;
   private JTextArea queryArea;

   public DisplayQueryResults() {
      super("Displaying Query Results");

      try {
         tableModel = new ResultSetTableModel(DRIVER, DATABASE_URL, USERNAME,
                            PASSWORD, DEFAULT_QUERY);
         queryArea = new JTextArea(DEFAULT_QUERY, 3, 100);
         queryArea.setWrapStyleWord(true);
         queryArea.setLineWrap(true);

         JScrollPan scrollPane = new JScrollPane(queryArea, 
                                       ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                                       ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
         JButton submitButton = new JButton("Submit Query");
         Box boxNorth = Box.createHorizontalBox();
         boxNorth.add(scrollpane);
         boxNorth.add(submitButton);