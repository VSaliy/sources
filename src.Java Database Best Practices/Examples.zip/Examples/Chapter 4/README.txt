These files were compiled under JDK 1.3.1. You will need to make some
minor changes to get it to work under JDK 1.4. Unfortunately, my
server platform is FreeBSD and Sun has failed to do much to make a JDK
1.4 compiler available for this platform.
     -George Reese

