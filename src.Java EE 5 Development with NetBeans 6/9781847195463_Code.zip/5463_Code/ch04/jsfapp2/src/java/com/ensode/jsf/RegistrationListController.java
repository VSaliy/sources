/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ensode.jsf;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author heffel
 */
public class RegistrationListController {

    private List<RegistrationBean> registrationBeanList = null;

    /** Creates a new instance of RegistrationListController */
    public RegistrationListController() {
    }

    public String populateList() {
        registrationBeanList = new ArrayList<RegistrationBean>();

        registrationBeanList.add(populateBean("MS", "Carol", "Jones", 35));
        registrationBeanList.add(populateBean("MRS", "Glenda", "Murphy", 39));
        registrationBeanList.add(populateBean("MISS", "Stacy", "Clark", 36));
        registrationBeanList.add(populateBean("MR", "James", "Fox", 40));
        registrationBeanList.add(populateBean("DR", "Henry", "Bennett", 53));

        return "success";
    }

    public List<RegistrationBean> getRegistrationBeanList() {
        return registrationBeanList;
    }

    public void setRegistrationBeanList(List<RegistrationBean> registrationBeanList) {
        this.registrationBeanList = registrationBeanList;
    }

    private RegistrationBean populateBean(String salutation,
            String firstName, String lastName, Integer age) {
        RegistrationBean registrationBean;

        registrationBean = new RegistrationBean();
        registrationBean.setSalutation(salutation);
        registrationBean.setFirstName(firstName);
        registrationBean.setLastName(lastName);
        registrationBean.setAge(age);

        return registrationBean;
    }
}
