/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.UsState;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface UsStateFacadeLocal {

    void create(UsState usState);

    void edit(UsState usState);

    void remove(UsState usState);

    UsState find(Object id);

    List<UsState> findAll();

}
