/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.AddressType;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface AddressTypeFacadeLocal {

    void create(AddressType addressType);

    void edit(AddressType addressType);

    void remove(AddressType addressType);

    AddressType find(Object id);

    List<AddressType> findAll();

}
