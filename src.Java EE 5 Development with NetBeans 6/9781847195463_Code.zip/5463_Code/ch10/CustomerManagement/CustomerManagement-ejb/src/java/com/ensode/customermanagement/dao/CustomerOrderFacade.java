/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.CustomerOrder;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class CustomerOrderFacade implements CustomerOrderFacadeLocal {
    @PersistenceContext
    private EntityManager em;

    public void create(CustomerOrder customerOrder) {
        em.persist(customerOrder);
    }

    public void edit(CustomerOrder customerOrder) {
        em.merge(customerOrder);
    }

    public void remove(CustomerOrder customerOrder) {
        em.remove(em.merge(customerOrder));
    }

    public CustomerOrder find(Object id) {
        return em.find(CustomerOrder.class, id);
    }

    public List<CustomerOrder> findAll() {
        return em.createQuery("select object(o) from CustomerOrder as o").getResultList();
    }

}
