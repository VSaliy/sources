/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.UsCity;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface UsCityFacadeLocal {

    void create(UsCity usCity);

    void edit(UsCity usCity);

    void remove(UsCity usCity);

    UsCity find(Object id);

    List<UsCity> findAll();

}
