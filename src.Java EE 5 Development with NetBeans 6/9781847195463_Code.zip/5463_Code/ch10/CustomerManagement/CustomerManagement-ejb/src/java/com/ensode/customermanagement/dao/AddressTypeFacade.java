/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.AddressType;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class AddressTypeFacade implements AddressTypeFacadeLocal {
    @PersistenceContext
    private EntityManager em;

    public void create(AddressType addressType) {
        em.persist(addressType);
    }

    public void edit(AddressType addressType) {
        em.merge(addressType);
    }

    public void remove(AddressType addressType) {
        em.remove(em.merge(addressType));
    }

    public AddressType find(Object id) {
        return em.find(AddressType.class, id);
    }

    public List<AddressType> findAll() {
        return em.createQuery("select object(o) from AddressType as o").getResultList();
    }

}
