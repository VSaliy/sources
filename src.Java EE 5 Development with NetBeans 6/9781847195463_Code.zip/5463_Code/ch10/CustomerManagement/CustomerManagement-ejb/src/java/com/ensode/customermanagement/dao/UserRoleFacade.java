/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.UserRole;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class UserRoleFacade implements UserRoleFacadeLocal {
    @PersistenceContext
    private EntityManager em;

    public void create(UserRole userRole) {
        em.persist(userRole);
    }

    public void edit(UserRole userRole) {
        em.merge(userRole);
    }

    public void remove(UserRole userRole) {
        em.remove(em.merge(userRole));
    }

    public UserRole find(Object id) {
        return em.find(UserRole.class, id);
    }

    public List<UserRole> findAll() {
        return em.createQuery("select object(o) from UserRole as o").getResultList();
    }

}
