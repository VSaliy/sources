/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.Telephone;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class TelephoneFacade implements TelephoneFacadeLocal {
    @PersistenceContext
    private EntityManager em;

    public void create(Telephone telephone) {
        em.persist(telephone);
    }

    public void edit(Telephone telephone) {
        em.merge(telephone);
    }

    public void remove(Telephone telephone) {
        em.remove(em.merge(telephone));
    }

    public Telephone find(Object id) {
        return em.find(Telephone.class, id);
    }

    public List<Telephone> findAll() {
        return em.createQuery("select object(o) from Telephone as o").getResultList();
    }

}
