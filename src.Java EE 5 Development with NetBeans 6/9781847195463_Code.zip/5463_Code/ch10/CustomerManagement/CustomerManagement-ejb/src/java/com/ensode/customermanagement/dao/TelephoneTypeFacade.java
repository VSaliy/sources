/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.TelephoneType;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class TelephoneTypeFacade implements TelephoneTypeFacadeLocal {
    @PersistenceContext
    private EntityManager em;

    public void create(TelephoneType telephoneType) {
        em.persist(telephoneType);
    }

    public void edit(TelephoneType telephoneType) {
        em.merge(telephoneType);
    }

    public void remove(TelephoneType telephoneType) {
        em.remove(em.merge(telephoneType));
    }

    public TelephoneType find(Object id) {
        return em.find(TelephoneType.class, id);
    }

    public List<TelephoneType> findAll() {
        return em.createQuery("select object(o) from TelephoneType as o").getResultList();
    }

}
