/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.Telephone;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface TelephoneFacadeLocal {

    void create(Telephone telephone);

    void edit(Telephone telephone);

    void remove(Telephone telephone);

    Telephone find(Object id);

    List<Telephone> findAll();

}
