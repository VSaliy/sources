/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.TelephoneType;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface TelephoneTypeFacadeLocal {

    void create(TelephoneType telephoneType);

    void edit(TelephoneType telephoneType);

    void remove(TelephoneType telephoneType);

    TelephoneType find(Object id);

    List<TelephoneType> findAll();

}
