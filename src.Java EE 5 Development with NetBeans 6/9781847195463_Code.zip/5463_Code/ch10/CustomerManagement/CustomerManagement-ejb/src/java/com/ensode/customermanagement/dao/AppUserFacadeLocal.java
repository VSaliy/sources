/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.AppUser;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface AppUserFacadeLocal {

    void create(AppUser appUser);

    void edit(AppUser appUser);

    void remove(AppUser appUser);

    AppUser find(Object id);

    List<AppUser> findAll();

}
