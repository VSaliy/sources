/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.customermanagement.dao;

import com.ensode.customermanagement.entity.UsCity;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class UsCityFacade implements UsCityFacadeLocal {
    @PersistenceContext
    private EntityManager em;

    public void create(UsCity usCity) {
        em.persist(usCity);
    }

    public void edit(UsCity usCity) {
        em.merge(usCity);
    }

    public void remove(UsCity usCity) {
        em.remove(em.merge(usCity));
    }

    public UsCity find(Object id) {
        return em.find(UsCity.class, id);
    }

    public List<UsCity> findAll() {
        return em.createQuery("select object(o) from UsCity as o").getResultList();
    }

}
