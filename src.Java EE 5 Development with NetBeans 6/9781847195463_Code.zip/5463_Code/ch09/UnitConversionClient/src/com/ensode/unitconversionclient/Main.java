package com.ensode.unitconversionclient;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try { // Call Web Service Operation
            com.ensode.webservices.UnitConversionService service =
                    new com.ensode.webservices.UnitConversionService();
            com.ensode.webservices.UnitConversion port =
                    service.getUnitConversionPort();
            // TODO initialize WS operation arguments here
            double inches = 1.0d;
            // TODO process result here
            double result = port.inchesToCentimeters(inches);
            System.out.println("Result = " + result);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
