/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejb;

import javax.ejb.Local;

/**
 *
 * @author heffel
 */
@Local
public interface WeightUnitConversionLocal {

    double kilosToPounds(double kilo);

    double poundsToKilos(double pounds);
    
}
