/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ensode.ejb;

import javax.ejb.Stateless;

@Stateless
public class WeightUnitConversionBean implements WeightUnitConversionLocal {

    // Add business logic below. (Right-click in editor and choose
    // "EJB Methods > Add Business Method" or "Web Service > Add Operation")
    public double kilosToPounds(double kilos) {
        return kilos * 2.205;
    }

    public double poundsToKilos(double pounds) {
        return pounds / 2.205;
    }
}
