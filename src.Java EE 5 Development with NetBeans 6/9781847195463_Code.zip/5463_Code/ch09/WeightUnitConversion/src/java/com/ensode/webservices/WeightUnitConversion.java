package com.ensode.webservices;

import com.ensode.ejb.WeightUnitConversionLocal;
import javax.ejb.EJB;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.ejb.Stateless;

@WebService()
@Stateless()
public class WeightUnitConversion {
    @EJB
    private WeightUnitConversionLocal ejbRef;
    // Add business logic below. (Right-click in editor and choose
    // "Web Service > Add Operation"

    @WebMethod(operationName = "kilosToPounds")
    public double kilosToPounds(@WebParam(name = "kilo")
    double kilo) {
        return ejbRef.kilosToPounds(kilo);
    }

    @WebMethod(operationName = "poundsToKilos")
    public double poundsToKilos(@WebParam(name = "pounds")
    double pounds) {
        return ejbRef.poundsToKilos(pounds);
    }

}
