package com.ensode.webservices;

import javax.jws.WebService;

@WebService(serviceName = "WeightUnitConversionService", portName = "WeightUnitConversionPort", endpointInterface = "com.ensode.webservices.WeightUnitConversion", targetNamespace = "http://webservices.ensode.com/", wsdlLocation = "WEB-INF/wsdl/WeightUnitConversionServiceFromWSDL/localhost_8080/WeightUnitConversionService/WeightUnitConversion.wsdl")
public class WeightUnitConversionServiceFromWSDL implements WeightUnitConversion {

    public double kilosToPounds(double kilo) {
        //TODO implement this method
        throw new UnsupportedOperationException("Not implemented yet.");
    }

    public double poundsToKilos(double pounds) {
        //TODO implement this method
        throw new UnsupportedOperationException("Not implemented yet.");
    }
}
