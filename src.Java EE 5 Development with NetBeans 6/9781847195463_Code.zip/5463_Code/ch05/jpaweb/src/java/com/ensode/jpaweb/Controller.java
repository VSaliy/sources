package com.ensode.jpaweb;

public class Controller {

    private CustomerDAO customerDAO;
    private Customer customer;

    /** Creates a new instance of Controller */
    public Controller() {
    }

    public CustomerDAO getCustomerDAO() {
        return customerDAO;
    }

    public void setCustomerDAO(CustomerDAO customerDAO) {
        this.customerDAO = customerDAO;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String saveCustomer() {
        String returnVal;
        try {
            customerDAO.persist(customer);
            returnVal = "success";
        } catch (Exception e) {
            returnVal = "failure";
            e.printStackTrace();
        }

        System.out.println(this.getClass().getName() + ".saveCustomer()\nreturnVal = " + returnVal);
        return returnVal;
    }
}
