/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jsf;

import com.ensode.jpa.TelephoneType;
import com.ensode.jpacontroller.TelephoneTypeJpaController;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

/**
 *
 * @author heffel
 */
public class TelephoneTypeConverter implements Converter {

    public Object getAsObject(FacesContext facesContext, UIComponent component, String string) {
        if (string == null || string.length() == 0) {
            return null;
        }
        Integer id = new Integer(string);
        TelephoneTypeJpaController controller = (TelephoneTypeJpaController) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "telephoneTypeJpa");
        return controller.findTelephoneType(id);
    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
        if (object == null) {
            return null;
        }
        if (object instanceof TelephoneType) {
            TelephoneType o = (TelephoneType) object;
            return o.getTelephoneTypeId() == null ? "" : o.getTelephoneTypeId().toString();
        } else {
            throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: com.ensode.jpa.TelephoneType");
        }
    }

}
