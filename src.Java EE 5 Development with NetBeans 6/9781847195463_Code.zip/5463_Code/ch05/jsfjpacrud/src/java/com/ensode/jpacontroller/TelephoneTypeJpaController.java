/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.TelephoneType;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.Telephone;
import java.util.ArrayList;
import java.util.Collection;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class TelephoneTypeJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(TelephoneType telephoneType) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (telephoneType.getTelephoneCollection() == null) {
            telephoneType.setTelephoneCollection(new ArrayList<Telephone>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Telephone> attachedTelephoneCollection = new ArrayList<Telephone>();
            for (Telephone telephoneCollectionTelephoneToAttach : telephoneType.getTelephoneCollection()) {
                telephoneCollectionTelephoneToAttach = em.getReference(telephoneCollectionTelephoneToAttach.getClass(), telephoneCollectionTelephoneToAttach.getTelephoneId());
                attachedTelephoneCollection.add(telephoneCollectionTelephoneToAttach);
            }
            telephoneType.setTelephoneCollection(attachedTelephoneCollection);
            em.persist(telephoneType);
            for (Telephone telephoneCollectionTelephone : telephoneType.getTelephoneCollection()) {
                TelephoneType oldTelephoneTypeIdOfTelephoneCollectionTelephone = telephoneCollectionTelephone.getTelephoneTypeId();
                telephoneCollectionTelephone.setTelephoneTypeId(telephoneType);
                telephoneCollectionTelephone = em.merge(telephoneCollectionTelephone);
                if (oldTelephoneTypeIdOfTelephoneCollectionTelephone != null) {
                    oldTelephoneTypeIdOfTelephoneCollectionTelephone.getTelephoneCollection().remove(telephoneCollectionTelephone);
                    oldTelephoneTypeIdOfTelephoneCollectionTelephone = em.merge(oldTelephoneTypeIdOfTelephoneCollectionTelephone);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findTelephoneType(telephoneType.getTelephoneTypeId()) != null) {
                throw new PreexistingEntityException("TelephoneType " + telephoneType + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(TelephoneType telephoneType) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            TelephoneType persistentTelephoneType = em.find(TelephoneType.class, telephoneType.getTelephoneTypeId());
            Collection<Telephone> telephoneCollectionOld = persistentTelephoneType.getTelephoneCollection();
            Collection<Telephone> telephoneCollectionNew = telephoneType.getTelephoneCollection();
            List<Telephone> attachedTelephoneCollectionNew = new ArrayList<Telephone>();
            for (Telephone telephoneCollectionNewTelephoneToAttach : telephoneCollectionNew) {
                telephoneCollectionNewTelephoneToAttach = em.getReference(telephoneCollectionNewTelephoneToAttach.getClass(), telephoneCollectionNewTelephoneToAttach.getTelephoneId());
                attachedTelephoneCollectionNew.add(telephoneCollectionNewTelephoneToAttach);
            }
            telephoneCollectionNew = attachedTelephoneCollectionNew;
            telephoneType.setTelephoneCollection(telephoneCollectionNew);
            telephoneType = em.merge(telephoneType);
            for (Telephone telephoneCollectionOldTelephone : telephoneCollectionOld) {
                if (!telephoneCollectionNew.contains(telephoneCollectionOldTelephone)) {
                    telephoneCollectionOldTelephone.setTelephoneTypeId(null);
                    telephoneCollectionOldTelephone = em.merge(telephoneCollectionOldTelephone);
                }
            }
            for (Telephone telephoneCollectionNewTelephone : telephoneCollectionNew) {
                if (!telephoneCollectionOld.contains(telephoneCollectionNewTelephone)) {
                    TelephoneType oldTelephoneTypeIdOfTelephoneCollectionNewTelephone = telephoneCollectionNewTelephone.getTelephoneTypeId();
                    telephoneCollectionNewTelephone.setTelephoneTypeId(telephoneType);
                    telephoneCollectionNewTelephone = em.merge(telephoneCollectionNewTelephone);
                    if (oldTelephoneTypeIdOfTelephoneCollectionNewTelephone != null && !oldTelephoneTypeIdOfTelephoneCollectionNewTelephone.equals(telephoneType)) {
                        oldTelephoneTypeIdOfTelephoneCollectionNewTelephone.getTelephoneCollection().remove(telephoneCollectionNewTelephone);
                        oldTelephoneTypeIdOfTelephoneCollectionNewTelephone = em.merge(oldTelephoneTypeIdOfTelephoneCollectionNewTelephone);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = telephoneType.getTelephoneTypeId();
                if (findTelephoneType(id) == null) {
                    throw new NonexistentEntityException("The telephoneType with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            TelephoneType telephoneType;
            try {
                telephoneType = em.getReference(TelephoneType.class, id);
                telephoneType.getTelephoneTypeId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The telephoneType with id " + id + " no longer exists.", enfe);
            }
            Collection<Telephone> telephoneCollection = telephoneType.getTelephoneCollection();
            for (Telephone telephoneCollectionTelephone : telephoneCollection) {
                telephoneCollectionTelephone.setTelephoneTypeId(null);
                telephoneCollectionTelephone = em.merge(telephoneCollectionTelephone);
            }
            em.remove(telephoneType);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<TelephoneType> findTelephoneTypeEntities() {
        return findTelephoneTypeEntities(true, -1, -1);
    }

    public List<TelephoneType> findTelephoneTypeEntities(int maxResults, int firstResult) {
        return findTelephoneTypeEntities(false, maxResults, firstResult);
    }

    private List<TelephoneType> findTelephoneTypeEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from TelephoneType as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public TelephoneType findTelephoneType(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(TelephoneType.class, id);
        } finally {
            em.close();
        }
    }

    public int getTelephoneTypeCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from TelephoneType as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
