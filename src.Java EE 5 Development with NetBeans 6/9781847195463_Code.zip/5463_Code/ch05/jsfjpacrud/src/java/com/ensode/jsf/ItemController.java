/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jsf;

import com.ensode.jpa.Item;
import com.ensode.jpacontroller.ItemJpaController;
import com.ensode.jsf.util.PagingInfo;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import com.ensode.jsf.util.JsfUtil;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;

/**
 *
 * @author heffel
 */
public class ItemController {

    public ItemController() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        jpaController = (ItemJpaController) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "itemJpa");
        pagingInfo = new PagingInfo();
        converter = new ItemConverter();
    }
    private Item item = null;
    private List<Item> itemItems = null;
    private ItemJpaController jpaController = null;
    private ItemConverter converter = null;
    private PagingInfo pagingInfo = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(jpaController.getItemCount());
        }
        return pagingInfo;
    }

    public SelectItem[] getItemItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(jpaController.findItemEntities(), false);
    }

    public SelectItem[] getItemItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(jpaController.findItemEntities(), true);
    }

    public Item getItem() {
        if (item == null) {
            item = (Item) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentItem", converter, null);
        }
        if (item == null) {
            item = new Item();
        }
        return item;
    }

    public String listSetup() {
        reset(true);
        return "item_list";
    }

    public String createSetup() {
        reset(false);
        item = new Item();
        return "item_create";
    }

    public String create() {
        try {
            jpaController.create(item);
            JsfUtil.addSuccessMessage("Item was successfully created.");
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("item_detail");
    }

    public String editSetup() {
        return scalarSetup("item_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        item = (Item) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentItem", converter, null);
        if (item == null) {
            String requestItemString = JsfUtil.getRequestParameter("jsfcrud.currentItem");
            JsfUtil.addErrorMessage("The item with id " + requestItemString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String itemString = converter.getAsString(FacesContext.getCurrentInstance(), null, item);
        String currentItemString = JsfUtil.getRequestParameter("jsfcrud.currentItem");
        if (itemString == null || itemString.length() == 0 || !itemString.equals(currentItemString)) {
            String outcome = editSetup();
            if ("item_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit item. Try again.");
            }
            return outcome;
        }
        try {
            jpaController.edit(item);
            JsfUtil.addSuccessMessage("Item was successfully updated.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return listSetup();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String destroy() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentItem");
        Integer id = new Integer(idAsString);
        try {
            jpaController.destroy(id);
            JsfUtil.addSuccessMessage("Item was successfully deleted.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return relatedOrListOutcome();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
        if (relatedControllerOutcome != null) {
            return relatedControllerOutcome;
        }
        return listSetup();
    }

    public List<Item> getItemItems() {
        if (itemItems == null) {
            getPagingInfo();
            itemItems = jpaController.findItemEntities(pagingInfo.getBatchSize(), pagingInfo.getFirstItem());
        }
        return itemItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "item_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "item_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        item = null;
        itemItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        Item newItem = new Item();
        String newItemString = converter.getAsString(FacesContext.getCurrentInstance(), null, newItem);
        String itemString = converter.getAsString(FacesContext.getCurrentInstance(), null, item);
        if (!newItemString.equals(itemString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }

}
