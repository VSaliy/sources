/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.Customer;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.CustomerOrder;
import java.util.ArrayList;
import java.util.Collection;
import com.ensode.jpa.Address;
import com.ensode.jpa.Telephone;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class CustomerJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Customer customer) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (customer.getCustomerOrderCollection() == null) {
            customer.setCustomerOrderCollection(new ArrayList<CustomerOrder>());
        }
        if (customer.getAddressCollection() == null) {
            customer.setAddressCollection(new ArrayList<Address>());
        }
        if (customer.getTelephoneCollection() == null) {
            customer.setTelephoneCollection(new ArrayList<Telephone>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<CustomerOrder> attachedCustomerOrderCollection = new ArrayList<CustomerOrder>();
            for (CustomerOrder customerOrderCollectionCustomerOrderToAttach : customer.getCustomerOrderCollection()) {
                customerOrderCollectionCustomerOrderToAttach = em.getReference(customerOrderCollectionCustomerOrderToAttach.getClass(), customerOrderCollectionCustomerOrderToAttach.getCustomerOrderId());
                attachedCustomerOrderCollection.add(customerOrderCollectionCustomerOrderToAttach);
            }
            customer.setCustomerOrderCollection(attachedCustomerOrderCollection);
            List<Address> attachedAddressCollection = new ArrayList<Address>();
            for (Address addressCollectionAddressToAttach : customer.getAddressCollection()) {
                addressCollectionAddressToAttach = em.getReference(addressCollectionAddressToAttach.getClass(), addressCollectionAddressToAttach.getAddressId());
                attachedAddressCollection.add(addressCollectionAddressToAttach);
            }
            customer.setAddressCollection(attachedAddressCollection);
            List<Telephone> attachedTelephoneCollection = new ArrayList<Telephone>();
            for (Telephone telephoneCollectionTelephoneToAttach : customer.getTelephoneCollection()) {
                telephoneCollectionTelephoneToAttach = em.getReference(telephoneCollectionTelephoneToAttach.getClass(), telephoneCollectionTelephoneToAttach.getTelephoneId());
                attachedTelephoneCollection.add(telephoneCollectionTelephoneToAttach);
            }
            customer.setTelephoneCollection(attachedTelephoneCollection);
            em.persist(customer);
            for (CustomerOrder customerOrderCollectionCustomerOrder : customer.getCustomerOrderCollection()) {
                Customer oldCustomerIdOfCustomerOrderCollectionCustomerOrder = customerOrderCollectionCustomerOrder.getCustomerId();
                customerOrderCollectionCustomerOrder.setCustomerId(customer);
                customerOrderCollectionCustomerOrder = em.merge(customerOrderCollectionCustomerOrder);
                if (oldCustomerIdOfCustomerOrderCollectionCustomerOrder != null) {
                    oldCustomerIdOfCustomerOrderCollectionCustomerOrder.getCustomerOrderCollection().remove(customerOrderCollectionCustomerOrder);
                    oldCustomerIdOfCustomerOrderCollectionCustomerOrder = em.merge(oldCustomerIdOfCustomerOrderCollectionCustomerOrder);
                }
            }
            for (Address addressCollectionAddress : customer.getAddressCollection()) {
                Customer oldCustomerIdOfAddressCollectionAddress = addressCollectionAddress.getCustomerId();
                addressCollectionAddress.setCustomerId(customer);
                addressCollectionAddress = em.merge(addressCollectionAddress);
                if (oldCustomerIdOfAddressCollectionAddress != null) {
                    oldCustomerIdOfAddressCollectionAddress.getAddressCollection().remove(addressCollectionAddress);
                    oldCustomerIdOfAddressCollectionAddress = em.merge(oldCustomerIdOfAddressCollectionAddress);
                }
            }
            for (Telephone telephoneCollectionTelephone : customer.getTelephoneCollection()) {
                Customer oldCustomerIdOfTelephoneCollectionTelephone = telephoneCollectionTelephone.getCustomerId();
                telephoneCollectionTelephone.setCustomerId(customer);
                telephoneCollectionTelephone = em.merge(telephoneCollectionTelephone);
                if (oldCustomerIdOfTelephoneCollectionTelephone != null) {
                    oldCustomerIdOfTelephoneCollectionTelephone.getTelephoneCollection().remove(telephoneCollectionTelephone);
                    oldCustomerIdOfTelephoneCollectionTelephone = em.merge(oldCustomerIdOfTelephoneCollectionTelephone);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findCustomer(customer.getCustomerId()) != null) {
                throw new PreexistingEntityException("Customer " + customer + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Customer customer) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Customer persistentCustomer = em.find(Customer.class, customer.getCustomerId());
            Collection<CustomerOrder> customerOrderCollectionOld = persistentCustomer.getCustomerOrderCollection();
            Collection<CustomerOrder> customerOrderCollectionNew = customer.getCustomerOrderCollection();
            Collection<Address> addressCollectionOld = persistentCustomer.getAddressCollection();
            Collection<Address> addressCollectionNew = customer.getAddressCollection();
            Collection<Telephone> telephoneCollectionOld = persistentCustomer.getTelephoneCollection();
            Collection<Telephone> telephoneCollectionNew = customer.getTelephoneCollection();
            List<CustomerOrder> attachedCustomerOrderCollectionNew = new ArrayList<CustomerOrder>();
            for (CustomerOrder customerOrderCollectionNewCustomerOrderToAttach : customerOrderCollectionNew) {
                customerOrderCollectionNewCustomerOrderToAttach = em.getReference(customerOrderCollectionNewCustomerOrderToAttach.getClass(), customerOrderCollectionNewCustomerOrderToAttach.getCustomerOrderId());
                attachedCustomerOrderCollectionNew.add(customerOrderCollectionNewCustomerOrderToAttach);
            }
            customerOrderCollectionNew = attachedCustomerOrderCollectionNew;
            customer.setCustomerOrderCollection(customerOrderCollectionNew);
            List<Address> attachedAddressCollectionNew = new ArrayList<Address>();
            for (Address addressCollectionNewAddressToAttach : addressCollectionNew) {
                addressCollectionNewAddressToAttach = em.getReference(addressCollectionNewAddressToAttach.getClass(), addressCollectionNewAddressToAttach.getAddressId());
                attachedAddressCollectionNew.add(addressCollectionNewAddressToAttach);
            }
            addressCollectionNew = attachedAddressCollectionNew;
            customer.setAddressCollection(addressCollectionNew);
            List<Telephone> attachedTelephoneCollectionNew = new ArrayList<Telephone>();
            for (Telephone telephoneCollectionNewTelephoneToAttach : telephoneCollectionNew) {
                telephoneCollectionNewTelephoneToAttach = em.getReference(telephoneCollectionNewTelephoneToAttach.getClass(), telephoneCollectionNewTelephoneToAttach.getTelephoneId());
                attachedTelephoneCollectionNew.add(telephoneCollectionNewTelephoneToAttach);
            }
            telephoneCollectionNew = attachedTelephoneCollectionNew;
            customer.setTelephoneCollection(telephoneCollectionNew);
            customer = em.merge(customer);
            for (CustomerOrder customerOrderCollectionOldCustomerOrder : customerOrderCollectionOld) {
                if (!customerOrderCollectionNew.contains(customerOrderCollectionOldCustomerOrder)) {
                    customerOrderCollectionOldCustomerOrder.setCustomerId(null);
                    customerOrderCollectionOldCustomerOrder = em.merge(customerOrderCollectionOldCustomerOrder);
                }
            }
            for (CustomerOrder customerOrderCollectionNewCustomerOrder : customerOrderCollectionNew) {
                if (!customerOrderCollectionOld.contains(customerOrderCollectionNewCustomerOrder)) {
                    Customer oldCustomerIdOfCustomerOrderCollectionNewCustomerOrder = customerOrderCollectionNewCustomerOrder.getCustomerId();
                    customerOrderCollectionNewCustomerOrder.setCustomerId(customer);
                    customerOrderCollectionNewCustomerOrder = em.merge(customerOrderCollectionNewCustomerOrder);
                    if (oldCustomerIdOfCustomerOrderCollectionNewCustomerOrder != null && !oldCustomerIdOfCustomerOrderCollectionNewCustomerOrder.equals(customer)) {
                        oldCustomerIdOfCustomerOrderCollectionNewCustomerOrder.getCustomerOrderCollection().remove(customerOrderCollectionNewCustomerOrder);
                        oldCustomerIdOfCustomerOrderCollectionNewCustomerOrder = em.merge(oldCustomerIdOfCustomerOrderCollectionNewCustomerOrder);
                    }
                }
            }
            for (Address addressCollectionOldAddress : addressCollectionOld) {
                if (!addressCollectionNew.contains(addressCollectionOldAddress)) {
                    addressCollectionOldAddress.setCustomerId(null);
                    addressCollectionOldAddress = em.merge(addressCollectionOldAddress);
                }
            }
            for (Address addressCollectionNewAddress : addressCollectionNew) {
                if (!addressCollectionOld.contains(addressCollectionNewAddress)) {
                    Customer oldCustomerIdOfAddressCollectionNewAddress = addressCollectionNewAddress.getCustomerId();
                    addressCollectionNewAddress.setCustomerId(customer);
                    addressCollectionNewAddress = em.merge(addressCollectionNewAddress);
                    if (oldCustomerIdOfAddressCollectionNewAddress != null && !oldCustomerIdOfAddressCollectionNewAddress.equals(customer)) {
                        oldCustomerIdOfAddressCollectionNewAddress.getAddressCollection().remove(addressCollectionNewAddress);
                        oldCustomerIdOfAddressCollectionNewAddress = em.merge(oldCustomerIdOfAddressCollectionNewAddress);
                    }
                }
            }
            for (Telephone telephoneCollectionOldTelephone : telephoneCollectionOld) {
                if (!telephoneCollectionNew.contains(telephoneCollectionOldTelephone)) {
                    telephoneCollectionOldTelephone.setCustomerId(null);
                    telephoneCollectionOldTelephone = em.merge(telephoneCollectionOldTelephone);
                }
            }
            for (Telephone telephoneCollectionNewTelephone : telephoneCollectionNew) {
                if (!telephoneCollectionOld.contains(telephoneCollectionNewTelephone)) {
                    Customer oldCustomerIdOfTelephoneCollectionNewTelephone = telephoneCollectionNewTelephone.getCustomerId();
                    telephoneCollectionNewTelephone.setCustomerId(customer);
                    telephoneCollectionNewTelephone = em.merge(telephoneCollectionNewTelephone);
                    if (oldCustomerIdOfTelephoneCollectionNewTelephone != null && !oldCustomerIdOfTelephoneCollectionNewTelephone.equals(customer)) {
                        oldCustomerIdOfTelephoneCollectionNewTelephone.getTelephoneCollection().remove(telephoneCollectionNewTelephone);
                        oldCustomerIdOfTelephoneCollectionNewTelephone = em.merge(oldCustomerIdOfTelephoneCollectionNewTelephone);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = customer.getCustomerId();
                if (findCustomer(id) == null) {
                    throw new NonexistentEntityException("The customer with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Customer customer;
            try {
                customer = em.getReference(Customer.class, id);
                customer.getCustomerId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The customer with id " + id + " no longer exists.", enfe);
            }
            Collection<CustomerOrder> customerOrderCollection = customer.getCustomerOrderCollection();
            for (CustomerOrder customerOrderCollectionCustomerOrder : customerOrderCollection) {
                customerOrderCollectionCustomerOrder.setCustomerId(null);
                customerOrderCollectionCustomerOrder = em.merge(customerOrderCollectionCustomerOrder);
            }
            Collection<Address> addressCollection = customer.getAddressCollection();
            for (Address addressCollectionAddress : addressCollection) {
                addressCollectionAddress.setCustomerId(null);
                addressCollectionAddress = em.merge(addressCollectionAddress);
            }
            Collection<Telephone> telephoneCollection = customer.getTelephoneCollection();
            for (Telephone telephoneCollectionTelephone : telephoneCollection) {
                telephoneCollectionTelephone.setCustomerId(null);
                telephoneCollectionTelephone = em.merge(telephoneCollectionTelephone);
            }
            em.remove(customer);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Customer> findCustomerEntities() {
        return findCustomerEntities(true, -1, -1);
    }

    public List<Customer> findCustomerEntities(int maxResults, int firstResult) {
        return findCustomerEntities(false, maxResults, firstResult);
    }

    private List<Customer> findCustomerEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from Customer as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Customer findCustomer(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Customer.class, id);
        } finally {
            em.close();
        }
    }

    public int getCustomerCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from Customer as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
