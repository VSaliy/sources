/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jsf;

import com.ensode.jpa.AppUser;
import com.ensode.jpacontroller.AppUserJpaController;
import com.ensode.jsf.util.PagingInfo;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import com.ensode.jsf.util.JsfUtil;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;

/**
 *
 * @author heffel
 */
public class AppUserController {

    public AppUserController() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        jpaController = (AppUserJpaController) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "appUserJpa");
        pagingInfo = new PagingInfo();
        converter = new AppUserConverter();
    }
    private AppUser appUser = null;
    private List<AppUser> appUserItems = null;
    private AppUserJpaController jpaController = null;
    private AppUserConverter converter = null;
    private PagingInfo pagingInfo = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(jpaController.getAppUserCount());
        }
        return pagingInfo;
    }

    public SelectItem[] getAppUserItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(jpaController.findAppUserEntities(), false);
    }

    public SelectItem[] getAppUserItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(jpaController.findAppUserEntities(), true);
    }

    public AppUser getAppUser() {
        if (appUser == null) {
            appUser = (AppUser) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentAppUser", converter, null);
        }
        if (appUser == null) {
            appUser = new AppUser();
        }
        return appUser;
    }

    public String listSetup() {
        reset(true);
        return "appUser_list";
    }

    public String createSetup() {
        reset(false);
        appUser = new AppUser();
        return "appUser_create";
    }

    public String create() {
        try {
            jpaController.create(appUser);
            JsfUtil.addSuccessMessage("AppUser was successfully created.");
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("appUser_detail");
    }

    public String editSetup() {
        return scalarSetup("appUser_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        appUser = (AppUser) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentAppUser", converter, null);
        if (appUser == null) {
            String requestAppUserString = JsfUtil.getRequestParameter("jsfcrud.currentAppUser");
            JsfUtil.addErrorMessage("The appUser with id " + requestAppUserString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String appUserString = converter.getAsString(FacesContext.getCurrentInstance(), null, appUser);
        String currentAppUserString = JsfUtil.getRequestParameter("jsfcrud.currentAppUser");
        if (appUserString == null || appUserString.length() == 0 || !appUserString.equals(currentAppUserString)) {
            String outcome = editSetup();
            if ("appUser_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit appUser. Try again.");
            }
            return outcome;
        }
        try {
            jpaController.edit(appUser);
            JsfUtil.addSuccessMessage("AppUser was successfully updated.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return listSetup();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String destroy() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentAppUser");
        Integer id = new Integer(idAsString);
        try {
            jpaController.destroy(id);
            JsfUtil.addSuccessMessage("AppUser was successfully deleted.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return relatedOrListOutcome();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
        if (relatedControllerOutcome != null) {
            return relatedControllerOutcome;
        }
        return listSetup();
    }

    public List<AppUser> getAppUserItems() {
        if (appUserItems == null) {
            getPagingInfo();
            appUserItems = jpaController.findAppUserEntities(pagingInfo.getBatchSize(), pagingInfo.getFirstItem());
        }
        return appUserItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "appUser_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "appUser_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        appUser = null;
        appUserItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        AppUser newAppUser = new AppUser();
        String newAppUserString = converter.getAsString(FacesContext.getCurrentInstance(), null, newAppUser);
        String appUserString = converter.getAsString(FacesContext.getCurrentInstance(), null, appUser);
        if (!newAppUserString.equals(appUserString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }

}
