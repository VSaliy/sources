/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.Address;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.AddressType;
import com.ensode.jpa.Customer;
import com.ensode.jpa.UsState;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class AddressJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Address address) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            AddressType addressTypeId = address.getAddressTypeId();
            if (addressTypeId != null) {
                addressTypeId = em.getReference(addressTypeId.getClass(), addressTypeId.getAddressTypeId());
                address.setAddressTypeId(addressTypeId);
            }
            Customer customerId = address.getCustomerId();
            if (customerId != null) {
                customerId = em.getReference(customerId.getClass(), customerId.getCustomerId());
                address.setCustomerId(customerId);
            }
            UsState usStateId = address.getUsStateId();
            if (usStateId != null) {
                usStateId = em.getReference(usStateId.getClass(), usStateId.getUsStateId());
                address.setUsStateId(usStateId);
            }
            em.persist(address);
            if (addressTypeId != null) {
                addressTypeId.getAddressCollection().add(address);
                addressTypeId = em.merge(addressTypeId);
            }
            if (customerId != null) {
                customerId.getAddressCollection().add(address);
                customerId = em.merge(customerId);
            }
            if (usStateId != null) {
                usStateId.getAddressCollection().add(address);
                usStateId = em.merge(usStateId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findAddress(address.getAddressId()) != null) {
                throw new PreexistingEntityException("Address " + address + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Address address) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Address persistentAddress = em.find(Address.class, address.getAddressId());
            AddressType addressTypeIdOld = persistentAddress.getAddressTypeId();
            AddressType addressTypeIdNew = address.getAddressTypeId();
            Customer customerIdOld = persistentAddress.getCustomerId();
            Customer customerIdNew = address.getCustomerId();
            UsState usStateIdOld = persistentAddress.getUsStateId();
            UsState usStateIdNew = address.getUsStateId();
            if (addressTypeIdNew != null) {
                addressTypeIdNew = em.getReference(addressTypeIdNew.getClass(), addressTypeIdNew.getAddressTypeId());
                address.setAddressTypeId(addressTypeIdNew);
            }
            if (customerIdNew != null) {
                customerIdNew = em.getReference(customerIdNew.getClass(), customerIdNew.getCustomerId());
                address.setCustomerId(customerIdNew);
            }
            if (usStateIdNew != null) {
                usStateIdNew = em.getReference(usStateIdNew.getClass(), usStateIdNew.getUsStateId());
                address.setUsStateId(usStateIdNew);
            }
            address = em.merge(address);
            if (addressTypeIdOld != null && !addressTypeIdOld.equals(addressTypeIdNew)) {
                addressTypeIdOld.getAddressCollection().remove(address);
                addressTypeIdOld = em.merge(addressTypeIdOld);
            }
            if (addressTypeIdNew != null && !addressTypeIdNew.equals(addressTypeIdOld)) {
                addressTypeIdNew.getAddressCollection().add(address);
                addressTypeIdNew = em.merge(addressTypeIdNew);
            }
            if (customerIdOld != null && !customerIdOld.equals(customerIdNew)) {
                customerIdOld.getAddressCollection().remove(address);
                customerIdOld = em.merge(customerIdOld);
            }
            if (customerIdNew != null && !customerIdNew.equals(customerIdOld)) {
                customerIdNew.getAddressCollection().add(address);
                customerIdNew = em.merge(customerIdNew);
            }
            if (usStateIdOld != null && !usStateIdOld.equals(usStateIdNew)) {
                usStateIdOld.getAddressCollection().remove(address);
                usStateIdOld = em.merge(usStateIdOld);
            }
            if (usStateIdNew != null && !usStateIdNew.equals(usStateIdOld)) {
                usStateIdNew.getAddressCollection().add(address);
                usStateIdNew = em.merge(usStateIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = address.getAddressId();
                if (findAddress(id) == null) {
                    throw new NonexistentEntityException("The address with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Address address;
            try {
                address = em.getReference(Address.class, id);
                address.getAddressId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The address with id " + id + " no longer exists.", enfe);
            }
            AddressType addressTypeId = address.getAddressTypeId();
            if (addressTypeId != null) {
                addressTypeId.getAddressCollection().remove(address);
                addressTypeId = em.merge(addressTypeId);
            }
            Customer customerId = address.getCustomerId();
            if (customerId != null) {
                customerId.getAddressCollection().remove(address);
                customerId = em.merge(customerId);
            }
            UsState usStateId = address.getUsStateId();
            if (usStateId != null) {
                usStateId.getAddressCollection().remove(address);
                usStateId = em.merge(usStateId);
            }
            em.remove(address);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Address> findAddressEntities() {
        return findAddressEntities(true, -1, -1);
    }

    public List<Address> findAddressEntities(int maxResults, int firstResult) {
        return findAddressEntities(false, maxResults, firstResult);
    }

    private List<Address> findAddressEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from Address as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Address findAddress(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Address.class, id);
        } finally {
            em.close();
        }
    }

    public int getAddressCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from Address as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
