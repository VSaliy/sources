/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.CustomerOrder;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.Customer;
import com.ensode.jpa.Item;
import java.util.ArrayList;
import java.util.Collection;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class CustomerOrderJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(CustomerOrder customerOrder) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (customerOrder.getItemCollection() == null) {
            customerOrder.setItemCollection(new ArrayList<Item>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Customer customerId = customerOrder.getCustomerId();
            if (customerId != null) {
                customerId = em.getReference(customerId.getClass(), customerId.getCustomerId());
                customerOrder.setCustomerId(customerId);
            }
            List<Item> attachedItemCollection = new ArrayList<Item>();
            for (Item itemCollectionItemToAttach : customerOrder.getItemCollection()) {
                itemCollectionItemToAttach = em.getReference(itemCollectionItemToAttach.getClass(), itemCollectionItemToAttach.getItemId());
                attachedItemCollection.add(itemCollectionItemToAttach);
            }
            customerOrder.setItemCollection(attachedItemCollection);
            em.persist(customerOrder);
            if (customerId != null) {
                customerId.getCustomerOrderCollection().add(customerOrder);
                customerId = em.merge(customerId);
            }
            for (Item itemCollectionItem : customerOrder.getItemCollection()) {
                itemCollectionItem.getCustomerOrderCollection().add(customerOrder);
                itemCollectionItem = em.merge(itemCollectionItem);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findCustomerOrder(customerOrder.getCustomerOrderId()) != null) {
                throw new PreexistingEntityException("CustomerOrder " + customerOrder + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(CustomerOrder customerOrder) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            CustomerOrder persistentCustomerOrder = em.find(CustomerOrder.class, customerOrder.getCustomerOrderId());
            Customer customerIdOld = persistentCustomerOrder.getCustomerId();
            Customer customerIdNew = customerOrder.getCustomerId();
            Collection<Item> itemCollectionOld = persistentCustomerOrder.getItemCollection();
            Collection<Item> itemCollectionNew = customerOrder.getItemCollection();
            if (customerIdNew != null) {
                customerIdNew = em.getReference(customerIdNew.getClass(), customerIdNew.getCustomerId());
                customerOrder.setCustomerId(customerIdNew);
            }
            List<Item> attachedItemCollectionNew = new ArrayList<Item>();
            for (Item itemCollectionNewItemToAttach : itemCollectionNew) {
                itemCollectionNewItemToAttach = em.getReference(itemCollectionNewItemToAttach.getClass(), itemCollectionNewItemToAttach.getItemId());
                attachedItemCollectionNew.add(itemCollectionNewItemToAttach);
            }
            itemCollectionNew = attachedItemCollectionNew;
            customerOrder.setItemCollection(itemCollectionNew);
            customerOrder = em.merge(customerOrder);
            if (customerIdOld != null && !customerIdOld.equals(customerIdNew)) {
                customerIdOld.getCustomerOrderCollection().remove(customerOrder);
                customerIdOld = em.merge(customerIdOld);
            }
            if (customerIdNew != null && !customerIdNew.equals(customerIdOld)) {
                customerIdNew.getCustomerOrderCollection().add(customerOrder);
                customerIdNew = em.merge(customerIdNew);
            }
            for (Item itemCollectionOldItem : itemCollectionOld) {
                if (!itemCollectionNew.contains(itemCollectionOldItem)) {
                    itemCollectionOldItem.getCustomerOrderCollection().remove(customerOrder);
                    itemCollectionOldItem = em.merge(itemCollectionOldItem);
                }
            }
            for (Item itemCollectionNewItem : itemCollectionNew) {
                if (!itemCollectionOld.contains(itemCollectionNewItem)) {
                    itemCollectionNewItem.getCustomerOrderCollection().add(customerOrder);
                    itemCollectionNewItem = em.merge(itemCollectionNewItem);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = customerOrder.getCustomerOrderId();
                if (findCustomerOrder(id) == null) {
                    throw new NonexistentEntityException("The customerOrder with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            CustomerOrder customerOrder;
            try {
                customerOrder = em.getReference(CustomerOrder.class, id);
                customerOrder.getCustomerOrderId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The customerOrder with id " + id + " no longer exists.", enfe);
            }
            Customer customerId = customerOrder.getCustomerId();
            if (customerId != null) {
                customerId.getCustomerOrderCollection().remove(customerOrder);
                customerId = em.merge(customerId);
            }
            Collection<Item> itemCollection = customerOrder.getItemCollection();
            for (Item itemCollectionItem : itemCollection) {
                itemCollectionItem.getCustomerOrderCollection().remove(customerOrder);
                itemCollectionItem = em.merge(itemCollectionItem);
            }
            em.remove(customerOrder);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<CustomerOrder> findCustomerOrderEntities() {
        return findCustomerOrderEntities(true, -1, -1);
    }

    public List<CustomerOrder> findCustomerOrderEntities(int maxResults, int firstResult) {
        return findCustomerOrderEntities(false, maxResults, firstResult);
    }

    private List<CustomerOrder> findCustomerOrderEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from CustomerOrder as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public CustomerOrder findCustomerOrder(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(CustomerOrder.class, id);
        } finally {
            em.close();
        }
    }

    public int getCustomerOrderCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from CustomerOrder as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
