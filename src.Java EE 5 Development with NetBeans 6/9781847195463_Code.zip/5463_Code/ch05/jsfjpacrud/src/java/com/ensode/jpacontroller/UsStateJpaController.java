/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.UsState;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.Address;
import java.util.ArrayList;
import java.util.Collection;
import com.ensode.jpa.UsCity;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class UsStateJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(UsState usState) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (usState.getAddressCollection() == null) {
            usState.setAddressCollection(new ArrayList<Address>());
        }
        if (usState.getUsCityCollection() == null) {
            usState.setUsCityCollection(new ArrayList<UsCity>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Address> attachedAddressCollection = new ArrayList<Address>();
            for (Address addressCollectionAddressToAttach : usState.getAddressCollection()) {
                addressCollectionAddressToAttach = em.getReference(addressCollectionAddressToAttach.getClass(), addressCollectionAddressToAttach.getAddressId());
                attachedAddressCollection.add(addressCollectionAddressToAttach);
            }
            usState.setAddressCollection(attachedAddressCollection);
            List<UsCity> attachedUsCityCollection = new ArrayList<UsCity>();
            for (UsCity usCityCollectionUsCityToAttach : usState.getUsCityCollection()) {
                usCityCollectionUsCityToAttach = em.getReference(usCityCollectionUsCityToAttach.getClass(), usCityCollectionUsCityToAttach.getUsCityId());
                attachedUsCityCollection.add(usCityCollectionUsCityToAttach);
            }
            usState.setUsCityCollection(attachedUsCityCollection);
            em.persist(usState);
            for (Address addressCollectionAddress : usState.getAddressCollection()) {
                UsState oldUsStateIdOfAddressCollectionAddress = addressCollectionAddress.getUsStateId();
                addressCollectionAddress.setUsStateId(usState);
                addressCollectionAddress = em.merge(addressCollectionAddress);
                if (oldUsStateIdOfAddressCollectionAddress != null) {
                    oldUsStateIdOfAddressCollectionAddress.getAddressCollection().remove(addressCollectionAddress);
                    oldUsStateIdOfAddressCollectionAddress = em.merge(oldUsStateIdOfAddressCollectionAddress);
                }
            }
            for (UsCity usCityCollectionUsCity : usState.getUsCityCollection()) {
                UsState oldUsStateIdOfUsCityCollectionUsCity = usCityCollectionUsCity.getUsStateId();
                usCityCollectionUsCity.setUsStateId(usState);
                usCityCollectionUsCity = em.merge(usCityCollectionUsCity);
                if (oldUsStateIdOfUsCityCollectionUsCity != null) {
                    oldUsStateIdOfUsCityCollectionUsCity.getUsCityCollection().remove(usCityCollectionUsCity);
                    oldUsStateIdOfUsCityCollectionUsCity = em.merge(oldUsStateIdOfUsCityCollectionUsCity);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findUsState(usState.getUsStateId()) != null) {
                throw new PreexistingEntityException("UsState " + usState + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(UsState usState) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UsState persistentUsState = em.find(UsState.class, usState.getUsStateId());
            Collection<Address> addressCollectionOld = persistentUsState.getAddressCollection();
            Collection<Address> addressCollectionNew = usState.getAddressCollection();
            Collection<UsCity> usCityCollectionOld = persistentUsState.getUsCityCollection();
            Collection<UsCity> usCityCollectionNew = usState.getUsCityCollection();
            List<Address> attachedAddressCollectionNew = new ArrayList<Address>();
            for (Address addressCollectionNewAddressToAttach : addressCollectionNew) {
                addressCollectionNewAddressToAttach = em.getReference(addressCollectionNewAddressToAttach.getClass(), addressCollectionNewAddressToAttach.getAddressId());
                attachedAddressCollectionNew.add(addressCollectionNewAddressToAttach);
            }
            addressCollectionNew = attachedAddressCollectionNew;
            usState.setAddressCollection(addressCollectionNew);
            List<UsCity> attachedUsCityCollectionNew = new ArrayList<UsCity>();
            for (UsCity usCityCollectionNewUsCityToAttach : usCityCollectionNew) {
                usCityCollectionNewUsCityToAttach = em.getReference(usCityCollectionNewUsCityToAttach.getClass(), usCityCollectionNewUsCityToAttach.getUsCityId());
                attachedUsCityCollectionNew.add(usCityCollectionNewUsCityToAttach);
            }
            usCityCollectionNew = attachedUsCityCollectionNew;
            usState.setUsCityCollection(usCityCollectionNew);
            usState = em.merge(usState);
            for (Address addressCollectionOldAddress : addressCollectionOld) {
                if (!addressCollectionNew.contains(addressCollectionOldAddress)) {
                    addressCollectionOldAddress.setUsStateId(null);
                    addressCollectionOldAddress = em.merge(addressCollectionOldAddress);
                }
            }
            for (Address addressCollectionNewAddress : addressCollectionNew) {
                if (!addressCollectionOld.contains(addressCollectionNewAddress)) {
                    UsState oldUsStateIdOfAddressCollectionNewAddress = addressCollectionNewAddress.getUsStateId();
                    addressCollectionNewAddress.setUsStateId(usState);
                    addressCollectionNewAddress = em.merge(addressCollectionNewAddress);
                    if (oldUsStateIdOfAddressCollectionNewAddress != null && !oldUsStateIdOfAddressCollectionNewAddress.equals(usState)) {
                        oldUsStateIdOfAddressCollectionNewAddress.getAddressCollection().remove(addressCollectionNewAddress);
                        oldUsStateIdOfAddressCollectionNewAddress = em.merge(oldUsStateIdOfAddressCollectionNewAddress);
                    }
                }
            }
            for (UsCity usCityCollectionOldUsCity : usCityCollectionOld) {
                if (!usCityCollectionNew.contains(usCityCollectionOldUsCity)) {
                    usCityCollectionOldUsCity.setUsStateId(null);
                    usCityCollectionOldUsCity = em.merge(usCityCollectionOldUsCity);
                }
            }
            for (UsCity usCityCollectionNewUsCity : usCityCollectionNew) {
                if (!usCityCollectionOld.contains(usCityCollectionNewUsCity)) {
                    UsState oldUsStateIdOfUsCityCollectionNewUsCity = usCityCollectionNewUsCity.getUsStateId();
                    usCityCollectionNewUsCity.setUsStateId(usState);
                    usCityCollectionNewUsCity = em.merge(usCityCollectionNewUsCity);
                    if (oldUsStateIdOfUsCityCollectionNewUsCity != null && !oldUsStateIdOfUsCityCollectionNewUsCity.equals(usState)) {
                        oldUsStateIdOfUsCityCollectionNewUsCity.getUsCityCollection().remove(usCityCollectionNewUsCity);
                        oldUsStateIdOfUsCityCollectionNewUsCity = em.merge(oldUsStateIdOfUsCityCollectionNewUsCity);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usState.getUsStateId();
                if (findUsState(id) == null) {
                    throw new NonexistentEntityException("The usState with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UsState usState;
            try {
                usState = em.getReference(UsState.class, id);
                usState.getUsStateId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usState with id " + id + " no longer exists.", enfe);
            }
            Collection<Address> addressCollection = usState.getAddressCollection();
            for (Address addressCollectionAddress : addressCollection) {
                addressCollectionAddress.setUsStateId(null);
                addressCollectionAddress = em.merge(addressCollectionAddress);
            }
            Collection<UsCity> usCityCollection = usState.getUsCityCollection();
            for (UsCity usCityCollectionUsCity : usCityCollection) {
                usCityCollectionUsCity.setUsStateId(null);
                usCityCollectionUsCity = em.merge(usCityCollectionUsCity);
            }
            em.remove(usState);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<UsState> findUsStateEntities() {
        return findUsStateEntities(true, -1, -1);
    }

    public List<UsState> findUsStateEntities(int maxResults, int firstResult) {
        return findUsStateEntities(false, maxResults, firstResult);
    }

    private List<UsState> findUsStateEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from UsState as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public UsState findUsState(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(UsState.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsStateCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from UsState as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
