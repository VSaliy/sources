/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.UsCity;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.UsState;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class UsCityJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(UsCity usCity) throws PreexistingEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UsState usStateId = usCity.getUsStateId();
            if (usStateId != null) {
                usStateId = em.getReference(usStateId.getClass(), usStateId.getUsStateId());
                usCity.setUsStateId(usStateId);
            }
            em.persist(usCity);
            if (usStateId != null) {
                usStateId.getUsCityCollection().add(usCity);
                usStateId = em.merge(usStateId);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findUsCity(usCity.getUsCityId()) != null) {
                throw new PreexistingEntityException("UsCity " + usCity + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(UsCity usCity) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UsCity persistentUsCity = em.find(UsCity.class, usCity.getUsCityId());
            UsState usStateIdOld = persistentUsCity.getUsStateId();
            UsState usStateIdNew = usCity.getUsStateId();
            if (usStateIdNew != null) {
                usStateIdNew = em.getReference(usStateIdNew.getClass(), usStateIdNew.getUsStateId());
                usCity.setUsStateId(usStateIdNew);
            }
            usCity = em.merge(usCity);
            if (usStateIdOld != null && !usStateIdOld.equals(usStateIdNew)) {
                usStateIdOld.getUsCityCollection().remove(usCity);
                usStateIdOld = em.merge(usStateIdOld);
            }
            if (usStateIdNew != null && !usStateIdNew.equals(usStateIdOld)) {
                usStateIdNew.getUsCityCollection().add(usCity);
                usStateIdNew = em.merge(usStateIdNew);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usCity.getUsCityId();
                if (findUsCity(id) == null) {
                    throw new NonexistentEntityException("The usCity with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UsCity usCity;
            try {
                usCity = em.getReference(UsCity.class, id);
                usCity.getUsCityId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usCity with id " + id + " no longer exists.", enfe);
            }
            UsState usStateId = usCity.getUsStateId();
            if (usStateId != null) {
                usStateId.getUsCityCollection().remove(usCity);
                usStateId = em.merge(usStateId);
            }
            em.remove(usCity);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<UsCity> findUsCityEntities() {
        return findUsCityEntities(true, -1, -1);
    }

    public List<UsCity> findUsCityEntities(int maxResults, int firstResult) {
        return findUsCityEntities(false, maxResults, firstResult);
    }

    private List<UsCity> findUsCityEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from UsCity as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public UsCity findUsCity(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(UsCity.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsCityCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from UsCity as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
