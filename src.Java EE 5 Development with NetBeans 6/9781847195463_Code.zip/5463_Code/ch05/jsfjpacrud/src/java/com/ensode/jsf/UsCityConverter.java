/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jsf;

import com.ensode.jpa.UsCity;
import com.ensode.jpacontroller.UsCityJpaController;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

/**
 *
 * @author heffel
 */
public class UsCityConverter implements Converter {

    public Object getAsObject(FacesContext facesContext, UIComponent component, String string) {
        if (string == null || string.length() == 0) {
            return null;
        }
        Integer id = new Integer(string);
        UsCityJpaController controller = (UsCityJpaController) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "usCityJpa");
        return controller.findUsCity(id);
    }

    public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
        if (object == null) {
            return null;
        }
        if (object instanceof UsCity) {
            UsCity o = (UsCity) object;
            return o.getUsCityId() == null ? "" : o.getUsCityId().toString();
        } else {
            throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: com.ensode.jpa.UsCity");
        }
    }

}
