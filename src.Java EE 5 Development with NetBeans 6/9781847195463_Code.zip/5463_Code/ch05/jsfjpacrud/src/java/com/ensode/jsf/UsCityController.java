/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jsf;

import com.ensode.jpa.UsCity;
import com.ensode.jpacontroller.UsCityJpaController;
import com.ensode.jsf.util.PagingInfo;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import com.ensode.jsf.util.JsfUtil;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;

/**
 *
 * @author heffel
 */
public class UsCityController {

    public UsCityController() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        jpaController = (UsCityJpaController) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "usCityJpa");
        pagingInfo = new PagingInfo();
        converter = new UsCityConverter();
    }
    private UsCity usCity = null;
    private List<UsCity> usCityItems = null;
    private UsCityJpaController jpaController = null;
    private UsCityConverter converter = null;
    private PagingInfo pagingInfo = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(jpaController.getUsCityCount());
        }
        return pagingInfo;
    }

    public SelectItem[] getUsCityItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(jpaController.findUsCityEntities(), false);
    }

    public SelectItem[] getUsCityItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(jpaController.findUsCityEntities(), true);
    }

    public UsCity getUsCity() {
        if (usCity == null) {
            usCity = (UsCity) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentUsCity", converter, null);
        }
        if (usCity == null) {
            usCity = new UsCity();
        }
        return usCity;
    }

    public String listSetup() {
        reset(true);
        return "usCity_list";
    }

    public String createSetup() {
        reset(false);
        usCity = new UsCity();
        return "usCity_create";
    }

    public String create() {
        try {
            jpaController.create(usCity);
            JsfUtil.addSuccessMessage("UsCity was successfully created.");
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("usCity_detail");
    }

    public String editSetup() {
        return scalarSetup("usCity_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        usCity = (UsCity) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentUsCity", converter, null);
        if (usCity == null) {
            String requestUsCityString = JsfUtil.getRequestParameter("jsfcrud.currentUsCity");
            JsfUtil.addErrorMessage("The usCity with id " + requestUsCityString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String usCityString = converter.getAsString(FacesContext.getCurrentInstance(), null, usCity);
        String currentUsCityString = JsfUtil.getRequestParameter("jsfcrud.currentUsCity");
        if (usCityString == null || usCityString.length() == 0 || !usCityString.equals(currentUsCityString)) {
            String outcome = editSetup();
            if ("usCity_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit usCity. Try again.");
            }
            return outcome;
        }
        try {
            jpaController.edit(usCity);
            JsfUtil.addSuccessMessage("UsCity was successfully updated.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return listSetup();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String destroy() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentUsCity");
        Integer id = new Integer(idAsString);
        try {
            jpaController.destroy(id);
            JsfUtil.addSuccessMessage("UsCity was successfully deleted.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return relatedOrListOutcome();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
        if (relatedControllerOutcome != null) {
            return relatedControllerOutcome;
        }
        return listSetup();
    }

    public List<UsCity> getUsCityItems() {
        if (usCityItems == null) {
            getPagingInfo();
            usCityItems = jpaController.findUsCityEntities(pagingInfo.getBatchSize(), pagingInfo.getFirstItem());
        }
        return usCityItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "usCity_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "usCity_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        usCity = null;
        usCityItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        UsCity newUsCity = new UsCity();
        String newUsCityString = converter.getAsString(FacesContext.getCurrentInstance(), null, newUsCity);
        String usCityString = converter.getAsString(FacesContext.getCurrentInstance(), null, usCity);
        if (!newUsCityString.equals(usCityString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }

}
