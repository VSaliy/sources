/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.UserRole;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.AppUser;
import java.util.ArrayList;
import java.util.Collection;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class UserRoleJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(UserRole userRole) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (userRole.getAppUserCollection() == null) {
            userRole.setAppUserCollection(new ArrayList<AppUser>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<AppUser> attachedAppUserCollection = new ArrayList<AppUser>();
            for (AppUser appUserCollectionAppUserToAttach : userRole.getAppUserCollection()) {
                appUserCollectionAppUserToAttach = em.getReference(appUserCollectionAppUserToAttach.getClass(), appUserCollectionAppUserToAttach.getAppUserId());
                attachedAppUserCollection.add(appUserCollectionAppUserToAttach);
            }
            userRole.setAppUserCollection(attachedAppUserCollection);
            em.persist(userRole);
            for (AppUser appUserCollectionAppUser : userRole.getAppUserCollection()) {
                appUserCollectionAppUser.getUserRoleCollection().add(userRole);
                appUserCollectionAppUser = em.merge(appUserCollectionAppUser);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findUserRole(userRole.getRoleId()) != null) {
                throw new PreexistingEntityException("UserRole " + userRole + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(UserRole userRole) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UserRole persistentUserRole = em.find(UserRole.class, userRole.getRoleId());
            Collection<AppUser> appUserCollectionOld = persistentUserRole.getAppUserCollection();
            Collection<AppUser> appUserCollectionNew = userRole.getAppUserCollection();
            List<AppUser> attachedAppUserCollectionNew = new ArrayList<AppUser>();
            for (AppUser appUserCollectionNewAppUserToAttach : appUserCollectionNew) {
                appUserCollectionNewAppUserToAttach = em.getReference(appUserCollectionNewAppUserToAttach.getClass(), appUserCollectionNewAppUserToAttach.getAppUserId());
                attachedAppUserCollectionNew.add(appUserCollectionNewAppUserToAttach);
            }
            appUserCollectionNew = attachedAppUserCollectionNew;
            userRole.setAppUserCollection(appUserCollectionNew);
            userRole = em.merge(userRole);
            for (AppUser appUserCollectionOldAppUser : appUserCollectionOld) {
                if (!appUserCollectionNew.contains(appUserCollectionOldAppUser)) {
                    appUserCollectionOldAppUser.getUserRoleCollection().remove(userRole);
                    appUserCollectionOldAppUser = em.merge(appUserCollectionOldAppUser);
                }
            }
            for (AppUser appUserCollectionNewAppUser : appUserCollectionNew) {
                if (!appUserCollectionOld.contains(appUserCollectionNewAppUser)) {
                    appUserCollectionNewAppUser.getUserRoleCollection().add(userRole);
                    appUserCollectionNewAppUser = em.merge(appUserCollectionNewAppUser);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = userRole.getRoleId();
                if (findUserRole(id) == null) {
                    throw new NonexistentEntityException("The userRole with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            UserRole userRole;
            try {
                userRole = em.getReference(UserRole.class, id);
                userRole.getRoleId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The userRole with id " + id + " no longer exists.", enfe);
            }
            Collection<AppUser> appUserCollection = userRole.getAppUserCollection();
            for (AppUser appUserCollectionAppUser : appUserCollection) {
                appUserCollectionAppUser.getUserRoleCollection().remove(userRole);
                appUserCollectionAppUser = em.merge(appUserCollectionAppUser);
            }
            em.remove(userRole);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<UserRole> findUserRoleEntities() {
        return findUserRoleEntities(true, -1, -1);
    }

    public List<UserRole> findUserRoleEntities(int maxResults, int firstResult) {
        return findUserRoleEntities(false, maxResults, firstResult);
    }

    private List<UserRole> findUserRoleEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from UserRole as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public UserRole findUserRole(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(UserRole.class, id);
        } finally {
            em.close();
        }
    }

    public int getUserRoleCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from UserRole as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
