/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.Item;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.CustomerOrder;
import java.util.ArrayList;
import java.util.Collection;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class ItemJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Item item) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (item.getCustomerOrderCollection() == null) {
            item.setCustomerOrderCollection(new ArrayList<CustomerOrder>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<CustomerOrder> attachedCustomerOrderCollection = new ArrayList<CustomerOrder>();
            for (CustomerOrder customerOrderCollectionCustomerOrderToAttach : item.getCustomerOrderCollection()) {
                customerOrderCollectionCustomerOrderToAttach = em.getReference(customerOrderCollectionCustomerOrderToAttach.getClass(), customerOrderCollectionCustomerOrderToAttach.getCustomerOrderId());
                attachedCustomerOrderCollection.add(customerOrderCollectionCustomerOrderToAttach);
            }
            item.setCustomerOrderCollection(attachedCustomerOrderCollection);
            em.persist(item);
            for (CustomerOrder customerOrderCollectionCustomerOrder : item.getCustomerOrderCollection()) {
                customerOrderCollectionCustomerOrder.getItemCollection().add(item);
                customerOrderCollectionCustomerOrder = em.merge(customerOrderCollectionCustomerOrder);
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findItem(item.getItemId()) != null) {
                throw new PreexistingEntityException("Item " + item + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Item item) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Item persistentItem = em.find(Item.class, item.getItemId());
            Collection<CustomerOrder> customerOrderCollectionOld = persistentItem.getCustomerOrderCollection();
            Collection<CustomerOrder> customerOrderCollectionNew = item.getCustomerOrderCollection();
            List<CustomerOrder> attachedCustomerOrderCollectionNew = new ArrayList<CustomerOrder>();
            for (CustomerOrder customerOrderCollectionNewCustomerOrderToAttach : customerOrderCollectionNew) {
                customerOrderCollectionNewCustomerOrderToAttach = em.getReference(customerOrderCollectionNewCustomerOrderToAttach.getClass(), customerOrderCollectionNewCustomerOrderToAttach.getCustomerOrderId());
                attachedCustomerOrderCollectionNew.add(customerOrderCollectionNewCustomerOrderToAttach);
            }
            customerOrderCollectionNew = attachedCustomerOrderCollectionNew;
            item.setCustomerOrderCollection(customerOrderCollectionNew);
            item = em.merge(item);
            for (CustomerOrder customerOrderCollectionOldCustomerOrder : customerOrderCollectionOld) {
                if (!customerOrderCollectionNew.contains(customerOrderCollectionOldCustomerOrder)) {
                    customerOrderCollectionOldCustomerOrder.getItemCollection().remove(item);
                    customerOrderCollectionOldCustomerOrder = em.merge(customerOrderCollectionOldCustomerOrder);
                }
            }
            for (CustomerOrder customerOrderCollectionNewCustomerOrder : customerOrderCollectionNew) {
                if (!customerOrderCollectionOld.contains(customerOrderCollectionNewCustomerOrder)) {
                    customerOrderCollectionNewCustomerOrder.getItemCollection().add(item);
                    customerOrderCollectionNewCustomerOrder = em.merge(customerOrderCollectionNewCustomerOrder);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = item.getItemId();
                if (findItem(id) == null) {
                    throw new NonexistentEntityException("The item with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            Item item;
            try {
                item = em.getReference(Item.class, id);
                item.getItemId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The item with id " + id + " no longer exists.", enfe);
            }
            Collection<CustomerOrder> customerOrderCollection = item.getCustomerOrderCollection();
            for (CustomerOrder customerOrderCollectionCustomerOrder : customerOrderCollection) {
                customerOrderCollectionCustomerOrder.getItemCollection().remove(item);
                customerOrderCollectionCustomerOrder = em.merge(customerOrderCollectionCustomerOrder);
            }
            em.remove(item);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Item> findItemEntities() {
        return findItemEntities(true, -1, -1);
    }

    public List<Item> findItemEntities(int maxResults, int firstResult) {
        return findItemEntities(false, maxResults, firstResult);
    }

    private List<Item> findItemEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from Item as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Item findItem(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Item.class, id);
        } finally {
            em.close();
        }
    }

    public int getItemCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from Item as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
