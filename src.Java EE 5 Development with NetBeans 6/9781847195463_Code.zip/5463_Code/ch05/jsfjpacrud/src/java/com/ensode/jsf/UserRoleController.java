/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jsf;

import com.ensode.jpa.UserRole;
import com.ensode.jpacontroller.UserRoleJpaController;
import com.ensode.jsf.util.PagingInfo;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import javax.faces.FacesException;
import com.ensode.jsf.util.JsfUtil;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.model.SelectItem;

/**
 *
 * @author heffel
 */
public class UserRoleController {

    public UserRoleController() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        jpaController = (UserRoleJpaController) facesContext.getApplication().getELResolver().getValue(facesContext.getELContext(), null, "userRoleJpa");
        pagingInfo = new PagingInfo();
        converter = new UserRoleConverter();
    }
    private UserRole userRole = null;
    private List<UserRole> userRoleItems = null;
    private UserRoleJpaController jpaController = null;
    private UserRoleConverter converter = null;
    private PagingInfo pagingInfo = null;

    public PagingInfo getPagingInfo() {
        if (pagingInfo.getItemCount() == -1) {
            pagingInfo.setItemCount(jpaController.getUserRoleCount());
        }
        return pagingInfo;
    }

    public SelectItem[] getUserRoleItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(jpaController.findUserRoleEntities(), false);
    }

    public SelectItem[] getUserRoleItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(jpaController.findUserRoleEntities(), true);
    }

    public UserRole getUserRole() {
        if (userRole == null) {
            userRole = (UserRole) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentUserRole", converter, null);
        }
        if (userRole == null) {
            userRole = new UserRole();
        }
        return userRole;
    }

    public String listSetup() {
        reset(true);
        return "userRole_list";
    }

    public String createSetup() {
        reset(false);
        userRole = new UserRole();
        return "userRole_create";
    }

    public String create() {
        try {
            jpaController.create(userRole);
            JsfUtil.addSuccessMessage("UserRole was successfully created.");
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return listSetup();
    }

    public String detailSetup() {
        return scalarSetup("userRole_detail");
    }

    public String editSetup() {
        return scalarSetup("userRole_edit");
    }

    private String scalarSetup(String destination) {
        reset(false);
        userRole = (UserRole) JsfUtil.getObjectFromRequestParameter("jsfcrud.currentUserRole", converter, null);
        if (userRole == null) {
            String requestUserRoleString = JsfUtil.getRequestParameter("jsfcrud.currentUserRole");
            JsfUtil.addErrorMessage("The userRole with id " + requestUserRoleString + " no longer exists.");
            return relatedOrListOutcome();
        }
        return destination;
    }

    public String edit() {
        String userRoleString = converter.getAsString(FacesContext.getCurrentInstance(), null, userRole);
        String currentUserRoleString = JsfUtil.getRequestParameter("jsfcrud.currentUserRole");
        if (userRoleString == null || userRoleString.length() == 0 || !userRoleString.equals(currentUserRoleString)) {
            String outcome = editSetup();
            if ("userRole_edit".equals(outcome)) {
                JsfUtil.addErrorMessage("Could not edit userRole. Try again.");
            }
            return outcome;
        }
        try {
            jpaController.edit(userRole);
            JsfUtil.addSuccessMessage("UserRole was successfully updated.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return listSetup();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return detailSetup();
    }

    public String destroy() {
        String idAsString = JsfUtil.getRequestParameter("jsfcrud.currentUserRole");
        Integer id = new Integer(idAsString);
        try {
            jpaController.destroy(id);
            JsfUtil.addSuccessMessage("UserRole was successfully deleted.");
        } catch (NonexistentEntityException ne) {
            JsfUtil.addErrorMessage(ne.getLocalizedMessage());
            return relatedOrListOutcome();
        } catch (Exception e) {
            JsfUtil.ensureAddErrorMessage(e, "A persistence error occurred.");
            return null;
        }
        return relatedOrListOutcome();
    }

    private String relatedOrListOutcome() {
        String relatedControllerOutcome = relatedControllerOutcome();
        if (relatedControllerOutcome != null) {
            return relatedControllerOutcome;
        }
        return listSetup();
    }

    public List<UserRole> getUserRoleItems() {
        if (userRoleItems == null) {
            getPagingInfo();
            userRoleItems = jpaController.findUserRoleEntities(pagingInfo.getBatchSize(), pagingInfo.getFirstItem());
        }
        return userRoleItems;
    }

    public String next() {
        reset(false);
        getPagingInfo().nextPage();
        return "userRole_list";
    }

    public String prev() {
        reset(false);
        getPagingInfo().previousPage();
        return "userRole_list";
    }

    private String relatedControllerOutcome() {
        String relatedControllerString = JsfUtil.getRequestParameter("jsfcrud.relatedController");
        String relatedControllerTypeString = JsfUtil.getRequestParameter("jsfcrud.relatedControllerType");
        if (relatedControllerString != null && relatedControllerTypeString != null) {
            FacesContext context = FacesContext.getCurrentInstance();
            Object relatedController = context.getApplication().getELResolver().getValue(context.getELContext(), null, relatedControllerString);
            try {
                Class<?> relatedControllerType = Class.forName(relatedControllerTypeString);
                Method detailSetupMethod = relatedControllerType.getMethod("detailSetup");
                return (String) detailSetupMethod.invoke(relatedController);
            } catch (ClassNotFoundException e) {
                throw new FacesException(e);
            } catch (NoSuchMethodException e) {
                throw new FacesException(e);
            } catch (IllegalAccessException e) {
                throw new FacesException(e);
            } catch (InvocationTargetException e) {
                throw new FacesException(e);
            }
        }
        return null;
    }

    private void reset(boolean resetFirstItem) {
        userRole = null;
        userRoleItems = null;
        pagingInfo.setItemCount(-1);
        if (resetFirstItem) {
            pagingInfo.setFirstItem(0);
        }
    }

    public void validateCreate(FacesContext facesContext, UIComponent component, Object value) {
        UserRole newUserRole = new UserRole();
        String newUserRoleString = converter.getAsString(FacesContext.getCurrentInstance(), null, newUserRole);
        String userRoleString = converter.getAsString(FacesContext.getCurrentInstance(), null, userRole);
        if (!newUserRoleString.equals(userRoleString)) {
            createSetup();
        }
    }

    public Converter getConverter() {
        return converter;
    }

}
