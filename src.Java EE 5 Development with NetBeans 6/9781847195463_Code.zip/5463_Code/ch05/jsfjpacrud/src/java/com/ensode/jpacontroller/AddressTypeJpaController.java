/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.jpacontroller;

import com.ensode.jpa.AddressType;
import com.ensode.jpacontroller.exceptions.NonexistentEntityException;
import com.ensode.jpacontroller.exceptions.PreexistingEntityException;
import com.ensode.jpacontroller.exceptions.RollbackFailureException;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import com.ensode.jpa.Address;
import java.util.ArrayList;
import java.util.Collection;
import javax.transaction.UserTransaction;

/**
 *
 * @author heffel
 */
public class AddressTypeJpaController {
    @Resource
    private UserTransaction utx = null;
    @PersistenceUnit(unitName = "jsfjpacrudPU")
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(AddressType addressType) throws PreexistingEntityException, RollbackFailureException, Exception {
        if (addressType.getAddressCollection() == null) {
            addressType.setAddressCollection(new ArrayList<Address>());
        }
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            List<Address> attachedAddressCollection = new ArrayList<Address>();
            for (Address addressCollectionAddressToAttach : addressType.getAddressCollection()) {
                addressCollectionAddressToAttach = em.getReference(addressCollectionAddressToAttach.getClass(), addressCollectionAddressToAttach.getAddressId());
                attachedAddressCollection.add(addressCollectionAddressToAttach);
            }
            addressType.setAddressCollection(attachedAddressCollection);
            em.persist(addressType);
            for (Address addressCollectionAddress : addressType.getAddressCollection()) {
                AddressType oldAddressTypeIdOfAddressCollectionAddress = addressCollectionAddress.getAddressTypeId();
                addressCollectionAddress.setAddressTypeId(addressType);
                addressCollectionAddress = em.merge(addressCollectionAddress);
                if (oldAddressTypeIdOfAddressCollectionAddress != null) {
                    oldAddressTypeIdOfAddressCollectionAddress.getAddressCollection().remove(addressCollectionAddress);
                    oldAddressTypeIdOfAddressCollectionAddress = em.merge(oldAddressTypeIdOfAddressCollectionAddress);
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            if (findAddressType(addressType.getAddressTypeId()) != null) {
                throw new PreexistingEntityException("AddressType " + addressType + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(AddressType addressType) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            AddressType persistentAddressType = em.find(AddressType.class, addressType.getAddressTypeId());
            Collection<Address> addressCollectionOld = persistentAddressType.getAddressCollection();
            Collection<Address> addressCollectionNew = addressType.getAddressCollection();
            List<Address> attachedAddressCollectionNew = new ArrayList<Address>();
            for (Address addressCollectionNewAddressToAttach : addressCollectionNew) {
                addressCollectionNewAddressToAttach = em.getReference(addressCollectionNewAddressToAttach.getClass(), addressCollectionNewAddressToAttach.getAddressId());
                attachedAddressCollectionNew.add(addressCollectionNewAddressToAttach);
            }
            addressCollectionNew = attachedAddressCollectionNew;
            addressType.setAddressCollection(addressCollectionNew);
            addressType = em.merge(addressType);
            for (Address addressCollectionOldAddress : addressCollectionOld) {
                if (!addressCollectionNew.contains(addressCollectionOldAddress)) {
                    addressCollectionOldAddress.setAddressTypeId(null);
                    addressCollectionOldAddress = em.merge(addressCollectionOldAddress);
                }
            }
            for (Address addressCollectionNewAddress : addressCollectionNew) {
                if (!addressCollectionOld.contains(addressCollectionNewAddress)) {
                    AddressType oldAddressTypeIdOfAddressCollectionNewAddress = addressCollectionNewAddress.getAddressTypeId();
                    addressCollectionNewAddress.setAddressTypeId(addressType);
                    addressCollectionNewAddress = em.merge(addressCollectionNewAddress);
                    if (oldAddressTypeIdOfAddressCollectionNewAddress != null && !oldAddressTypeIdOfAddressCollectionNewAddress.equals(addressType)) {
                        oldAddressTypeIdOfAddressCollectionNewAddress.getAddressCollection().remove(addressCollectionNewAddress);
                        oldAddressTypeIdOfAddressCollectionNewAddress = em.merge(oldAddressTypeIdOfAddressCollectionNewAddress);
                    }
                }
            }
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = addressType.getAddressTypeId();
                if (findAddressType(id) == null) {
                    throw new NonexistentEntityException("The addressType with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException, RollbackFailureException, Exception {
        EntityManager em = null;
        try {
            utx.begin();
            em = getEntityManager();
            AddressType addressType;
            try {
                addressType = em.getReference(AddressType.class, id);
                addressType.getAddressTypeId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The addressType with id " + id + " no longer exists.", enfe);
            }
            Collection<Address> addressCollection = addressType.getAddressCollection();
            for (Address addressCollectionAddress : addressCollection) {
                addressCollectionAddress.setAddressTypeId(null);
                addressCollectionAddress = em.merge(addressCollectionAddress);
            }
            em.remove(addressType);
            utx.commit();
        } catch (Exception ex) {
            try {
                utx.rollback();
            } catch (Exception re) {
                throw new RollbackFailureException("An error occurred attempting to roll back the transaction.", re);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<AddressType> findAddressTypeEntities() {
        return findAddressTypeEntities(true, -1, -1);
    }

    public List<AddressType> findAddressTypeEntities(int maxResults, int firstResult) {
        return findAddressTypeEntities(false, maxResults, firstResult);
    }

    private List<AddressType> findAddressTypeEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            Query q = em.createQuery("select object(o) from AddressType as o");
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public AddressType findAddressType(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(AddressType.class, id);
        } finally {
            em.close();
        }
    }

    public int getAddressTypeCount() {
        EntityManager em = getEntityManager();
        try {
            return ((Long) em.createQuery("select count(o) from AddressType as o").getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
