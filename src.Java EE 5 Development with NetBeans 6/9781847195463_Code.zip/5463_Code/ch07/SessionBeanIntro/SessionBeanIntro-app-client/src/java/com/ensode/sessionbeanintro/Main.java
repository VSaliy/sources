/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ensode.sessionbeanintro;

import com.ensode.sessionbeanintro.ejb.EchoRemote;
import javax.ejb.EJB;
import javax.swing.JOptionPane;

/**
 *
 * @author heffel
 */
public class Main {

    @EJB
    private static EchoRemote echoBean;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        JOptionPane.showMessageDialog(null, echoBean.echo(
                "I hate hello world examples!"));
    }
}
