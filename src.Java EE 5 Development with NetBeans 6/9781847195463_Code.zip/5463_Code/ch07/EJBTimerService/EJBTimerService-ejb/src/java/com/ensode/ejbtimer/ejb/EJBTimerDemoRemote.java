/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ensode.ejbtimer.ejb;

import java.io.Serializable;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface EJBTimerDemoRemote {

    void startTimer(Serializable info);

    void stopTimer(Serializable info);
}
