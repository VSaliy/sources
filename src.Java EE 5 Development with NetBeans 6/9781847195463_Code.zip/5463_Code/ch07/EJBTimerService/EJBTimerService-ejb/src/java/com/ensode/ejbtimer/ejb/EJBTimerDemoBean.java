/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ensode.ejbtimer.ejb;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

/**
 *
 * @author heffel
 */
@Stateless
public class EJBTimerDemoBean implements EJBTimerDemoRemote {

    @Resource
    TimerService timerService;

    public void startTimer(Serializable info) {
        System.out.println("Starting timer " + info);
        timerService.createTimer(0, 5000, info);
    }

    public void stopTimer(Serializable info) {
        System.out.println("Stopping timer " + info);
        Collection<Timer> timers = timerService.getTimers();
        for (Timer timer : timers) {
            if (timer.getInfo().equals(info)) {
                timer.cancel();
                break;
            }
        }
    }

    @Timeout
    public void executeOnTimeout(Timer timer) {
        System.out.println(this.getClass().getName() +
                ".executeOnTimeout() invoked at" + new Date() +
                "by timer " + timer.getInfo());
    }
}
