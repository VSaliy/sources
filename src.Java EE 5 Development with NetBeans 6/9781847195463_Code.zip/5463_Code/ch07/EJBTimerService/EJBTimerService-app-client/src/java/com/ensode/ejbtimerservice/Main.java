/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ensode.ejbtimerservice;

import com.ensode.ejbtimer.ejb.EJBTimerDemoRemote;
import javax.ejb.EJB;

/**
 *
 * @author heffel
 */
public class Main {

    @EJB
    private static EJBTimerDemoRemote eJBTimerDemoBean;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        eJBTimerDemoBean.startTimer("first");
        Thread.sleep(2000);
        eJBTimerDemoBean.startTimer("second");
        Thread.sleep(15000);
        eJBTimerDemoBean.stopTimer("first");
        Thread.sleep(10000);
        eJBTimerDemoBean.stopTimer("second");
    }
}
