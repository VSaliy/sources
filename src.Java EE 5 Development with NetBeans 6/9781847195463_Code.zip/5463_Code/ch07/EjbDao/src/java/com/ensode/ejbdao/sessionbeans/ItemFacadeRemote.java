/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.Item;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface ItemFacadeRemote {

    void create(Item item);

    void edit(Item item);

    void remove(Item item);

    Item find(Object id);

    List<Item> findAll();

}
