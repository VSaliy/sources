/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.TelephoneType;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface TelephoneTypeFacadeRemote {

    void create(TelephoneType telephoneType);

    void edit(TelephoneType telephoneType);

    void remove(TelephoneType telephoneType);

    TelephoneType find(Object id);

    List<TelephoneType> findAll();

}
