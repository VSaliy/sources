/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.Telephone;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface TelephoneFacadeRemote {

    void create(Telephone telephone);

    void edit(Telephone telephone);

    void remove(Telephone telephone);

    Telephone find(Object id);

    List<Telephone> findAll();

}
