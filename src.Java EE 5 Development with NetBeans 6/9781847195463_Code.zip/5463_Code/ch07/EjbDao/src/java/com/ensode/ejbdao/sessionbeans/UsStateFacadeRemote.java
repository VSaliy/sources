/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.UsState;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface UsStateFacadeRemote {

    void create(UsState usState);

    void edit(UsState usState);

    void remove(UsState usState);

    UsState find(Object id);

    List<UsState> findAll();

}
