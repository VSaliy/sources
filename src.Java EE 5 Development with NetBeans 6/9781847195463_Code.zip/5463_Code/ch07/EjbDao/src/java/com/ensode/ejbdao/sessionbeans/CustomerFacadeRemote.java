/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.Customer;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface CustomerFacadeRemote {

    void create(Customer customer);

    void edit(Customer customer);

    void remove(Customer customer);

    Customer find(Object id);

    List<Customer> findAll();

}
