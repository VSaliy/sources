/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.UsState;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class UsStateFacade implements UsStateFacadeRemote {
    @PersistenceContext
    private EntityManager em;

    public void create(UsState usState) {
        em.persist(usState);
    }

    public void edit(UsState usState) {
        em.merge(usState);
    }

    public void remove(UsState usState) {
        em.remove(em.merge(usState));
    }

    public UsState find(Object id) {
        return em.find(com.ensode.ejbdao.entities.UsState.class, id);
    }

    public List<UsState> findAll() {
        return em.createQuery("select object(o) from UsState as o").getResultList();
    }

}
