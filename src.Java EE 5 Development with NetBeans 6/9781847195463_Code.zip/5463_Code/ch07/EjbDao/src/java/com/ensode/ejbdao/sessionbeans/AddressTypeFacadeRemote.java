/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.AddressType;
import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author heffel
 */
@Remote
public interface AddressTypeFacadeRemote {

    void create(AddressType addressType);

    void edit(AddressType addressType);

    void remove(AddressType addressType);

    AddressType find(Object id);

    List<AddressType> findAll();

}
