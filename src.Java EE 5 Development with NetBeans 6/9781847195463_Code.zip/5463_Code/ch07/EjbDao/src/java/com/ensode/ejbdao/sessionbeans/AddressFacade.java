/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.Address;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class AddressFacade implements AddressFacadeRemote {
    @PersistenceContext
    private EntityManager em;

    public void create(Address address) {
        em.persist(address);
    }

    public void edit(Address address) {
        em.merge(address);
    }

    public void remove(Address address) {
        em.remove(em.merge(address));
    }

    public Address find(Object id) {
        return em.find(com.ensode.ejbdao.entities.Address.class, id);
    }

    public List<Address> findAll() {
        return em.createQuery("select object(o) from Address as o").getResultList();
    }

}
