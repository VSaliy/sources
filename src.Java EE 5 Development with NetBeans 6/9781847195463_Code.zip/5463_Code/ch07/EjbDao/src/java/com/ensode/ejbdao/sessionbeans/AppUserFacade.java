/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ensode.ejbdao.sessionbeans;

import com.ensode.ejbdao.entities.AppUser;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author heffel
 */
@Stateless
public class AppUserFacade implements AppUserFacadeRemote {
    @PersistenceContext
    private EntityManager em;

    public void create(AppUser appUser) {
        em.persist(appUser);
    }

    public void edit(AppUser appUser) {
        em.merge(appUser);
    }

    public void remove(AppUser appUser) {
        em.remove(em.merge(appUser));
    }

    public AppUser find(Object id) {
        return em.find(com.ensode.ejbdao.entities.AppUser.class, id);
    }

    public List<AppUser> findAll() {
        return em.createQuery("select object(o) from AppUser as o").getResultList();
    }

}
