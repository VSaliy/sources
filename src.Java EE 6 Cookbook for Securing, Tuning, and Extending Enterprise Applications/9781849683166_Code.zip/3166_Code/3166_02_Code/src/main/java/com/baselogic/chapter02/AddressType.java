package com.baselogic.chapter02;

/**
 * [Title]
 *
 * @author Mick Knutson (<a href="http://www.baselogic.com">http://www.baselogic.com</a>)
 * @since 2011
 */
public enum AddressType {
    BUSINESS,
    RESIDENTIAL,
    SECOND_HOME
}
