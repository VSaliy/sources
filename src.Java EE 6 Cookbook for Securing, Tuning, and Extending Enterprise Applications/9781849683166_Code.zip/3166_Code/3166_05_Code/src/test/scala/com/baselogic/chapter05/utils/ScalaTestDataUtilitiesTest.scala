package com.baselogic.chapter05.utils

import org.scalatest.junit.AssertionsForJUnit
import org.junit.Assert._
import org.junit.Test
import org.junit.Before
import java.util.Calendar
import java.text.SimpleDateFormat

object ScalaCheckDataUtilitiesTest extends AssertionsForJUnit {

  @Before def initialize() {
  }

  @Test def verifyEasy() {
      var calendar: Calendar = Calendar.getInstance
      calendar.add(Calendar.DATE, -1)
      var format: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd")
      var expected: String = format.format(calendar.getTime)
      var result: String = DateUtilities.getYesterdayDate

      assertEquals(expected, result)
  }

}