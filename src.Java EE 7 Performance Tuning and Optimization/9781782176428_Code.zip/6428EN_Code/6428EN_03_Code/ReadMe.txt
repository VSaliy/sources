The author's note while submitting the FD for this chapter:

Now "6428EN_03_wink_recording.zip" is no longer in the chapter resources so you might need to delete it from your repository.