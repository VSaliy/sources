The .jmx files are the files we used in JMeter in chapter 10 to do load test comparison between REST and SOAP web service.
You can use them by the following steps:
1- Run JMeter
2- File --> Open --> and select any of these files
3- Point to the correct .csv files from "CSV config data - load user ID(s)" elements to the included files: testids.csv
4- Run the required services : mySQL and Glassfish server
5- Execute the test plans.
