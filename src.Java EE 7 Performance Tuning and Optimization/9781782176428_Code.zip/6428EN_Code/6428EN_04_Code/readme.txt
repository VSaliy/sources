These are three projects:
1. HighCPU 
2. SimpleApplet

Both 1,2 are NetBeans projects , you need to Open from inside NetBeans 7.x
- File select -->Open Project.

3. HighCPU-Eclipse
This folder contains an Eclipse project inside, we can import into Eclipse workspace and open.