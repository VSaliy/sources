This is a NetBeans project, that need to be imported from insdie NetBeans.
The project inside the folder "Project before fixing" is the project you need to start with as, and the other project inside the folder "Project after fixing" is the project you need to use to see the performance improvments made for this application.

1) Open NetBeans 7.x
2) From File select -->Open Project 
Navigate to this project folder "ExcellentSurvey" and select it.
3) The project will open.
4) Open MySQL administration.
5) Create the user test/test if not already created.
6) Import the database script by restore.
7) grant all required access to the test user on this new schema "survey" schema.
8) You can now run the project from NetBeans over glassfish server V4.0
