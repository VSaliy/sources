These text files are thread dumps that can be open by any text editor.
You would better open them using Thread Dump Analyzer (TDA) tool to be much more readible.