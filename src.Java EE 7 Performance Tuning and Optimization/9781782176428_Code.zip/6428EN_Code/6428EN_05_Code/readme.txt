"ExampleTwo" is a NetBeans project, that need to be imported from insdie NetBeans or diploy the war file in destination folder.

1) Open NetBeans 7.x
2) From File select -->Open Project 
Navigate to this project folder and select it.
3) The project will open.
4) Open MySQL administration.
5) Create the user test/test (if not already created in chapter 3)
6) Import the database script by restore.
7) You can now run the project from NetBeans over glassfish server V4.0
