/*-- 

 Copyright (C) 2001 Brett McLaughlin.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "Java and XML" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact brett@newInstance.com.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed for the
      'Java and XML' book, by Brett McLaughlin (O'Reilly & Associates)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE JDOM AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */
package javaxml2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import javax.xml.parsers.DocumentBuilder;

// SAX and DOM imports
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

// SOAP imports
import org.apache.soap.Constants;
import org.apache.soap.Envelope;
import org.apache.soap.SOAPException;
import org.apache.soap.messaging.Message;
import org.apache.soap.transport.SOAPTransport;
import org.apache.soap.util.xml.XMLParserUtils;

/**
 * <p>
 *  <code>CDOrderer</code> is a web services client. It uses SOAP
 *    messaging to send a message to the <i>cd-order-service</i>.
 * </p>
 */
public class CDOrderer {

    /**
     * <p>
     *  This will take a SOAP message, and send it to the
     *    <i>cd-order-service</i> which should reside at the supplied
     *    URL.
     * </p>
     *
     * @param serviceURL the URL the web service is running on.
     * @param msgFilename the file to read the SOAP message from.
     * @throws <code>IOException</code> - when file access errors occur.
     * @throws <code>SAXException</code> - when file parsing errors occur.
     * @throws <code>SOAPException</code> - when errors occuring in
     *         accessing the SOAP service.
     */
    public void order(URL serviceURL, String msgFilename) 
        throws IOException, SAXException, SOAPException {

        // Parse the XML message
        FileReader reader = new FileReader(msgFilename);
        DocumentBuilder builder = XMLParserUtils.getXMLDocBuilder();
        Document doc = builder.parse(new InputSource(reader));
        if (doc == null) {
            throw new SOAPException(Constants.FAULT_CODE_CLIENT, 
                "Error parsing XML message.");
        }

        // Create the message envelope
        Envelope msgEnvelope = Envelope.unmarshall(doc.getDocumentElement());

        // Send the message
        Message msg = new Message();
        msg.send(serviceURL, "urn:cd-order-service", msgEnvelope);

        // Handle the response
        SOAPTransport transport = msg.getSOAPTransport();
        BufferedReader resReader = transport.receive();

        String line;
        while ((line = resReader.readLine()) != null) {
            System.out.println(line);
        }
    }

    /**
     * <p>Provide a static entry point.</p>
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java javaxml2.CDOrderer " +
                "[XML Message Filename]");
            return;
        }

        try {
            URL serviceURL = 
                new URL("http://localhost:8080/soap/servlet/messagerouter");

            CDOrderer orderer = new CDOrderer();
            orderer.order(serviceURL, args[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}