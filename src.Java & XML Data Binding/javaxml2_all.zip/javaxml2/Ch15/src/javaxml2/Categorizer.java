/*-- 

 Copyright (C) 2001 Brett McLaughlin.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "Java and XML" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact brett@newInstance.com.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed for the
      'Java and XML' book, by Brett McLaughlin (O'Reilly & Associates)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE JDOM AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */
package javaxml2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

// JAXB Classes
import javax.xml.bind.UnmarshalException;

// JAXB Generated Classes
import javaxml2.jaxb.Catalog;
import javaxml2.jaxb.Item;

/**
 * <p>
 *  <code>Categorizer</code> uses JAXB to construct a catalog
 *    of tapes and videos, and organizes them by their categories.
 * </p>
 */
public class Categorizer {

    /**
     * <p>
     *  This will load the catalog from the supplied XML file, break
     *    the catalog up by category, and write out new, categorized
     *    XML sub-catalogs.
     * </p>
     *
     * @param catalogFile <code>File</code> to read catalog from.
     * @throws <code>IOException</code> - when file access errors occur.
     */
    public void categorize(File catalogFile) throws IOException, 
        UnmarshalException {

        // Convert from XML to Java
        FileInputStream fis = new FileInputStream(catalogFile);
        Catalog catalog = new Catalog();
        try {
            catalog = Catalog.unmarshal(fis);
        } finally {
            fis.close();
        }

        // Create new catalogs for the different categories
        Catalog fingerpickingCatalog = new Catalog();
        Catalog flatpickingCatalog = new Catalog();
        Catalog mandolinCatalog = new Catalog();

        List items = catalog.getItem();
        for (Iterator i = items.iterator(); i.hasNext(); ) {
            Item item = (Item)i.next();
            String teacher = item.getTeacher();
            if ((teacher.equals("Doc Watson")) ||
                (teacher.equals("Steve Kaufman"))) {
                flatpickingCatalog.getItem().add(item);
            } else if (teacher.equals("David Wilcox")) {
                fingerpickingCatalog.getItem().add(item);
            } else if ((teacher.equals("Sam Bush")) ||
                       (teacher.equals("Chris Thile"))) {
                mandolinCatalog.getItem().add(item);
            }
        }

        // Write back out to XML
        FileOutputStream fingerOutput = 
            new FileOutputStream(new File("fingerpickingCatalog.xml"));
        FileOutputStream flatpickOutput = 
            new FileOutputStream(new File("flatpickingCatalog.xml"));
        FileOutputStream mandolinOutput = 
            new FileOutputStream(new File("mandolinCatalog.xml"));
        try {
            // Validate the catalogs
            fingerpickingCatalog.validate();
            flatpickingCatalog.validate();
            mandolinCatalog.validate();

            // Output the catalogs
            fingerpickingCatalog.marshal(fingerOutput);
            flatpickingCatalog.marshal(flatpickOutput);
            mandolinCatalog.marshal(mandolinOutput);
        } finally {
            fingerOutput.close();
            flatpickOutput.close();
            mandolinOutput.close();
        }
    }

    /**
     * <p>Provide a static entry point.</p>
     */
    public static void main(String[] args) {
        try {
            if (args.length != 1) {
                System.out.println("Usage: java javaxml2.Categorizer " +
                    "[XML Catalog Filename]");
                return;
            }

            // Get access to XML catalog
            File catalogFile = new File(args[0]);
            Categorizer categorizer = new Categorizer();
            categorizer.categorize(catalogFile);
            
        } catch (Exception e) {
            e.printStackTrace();
        }        
    }

}