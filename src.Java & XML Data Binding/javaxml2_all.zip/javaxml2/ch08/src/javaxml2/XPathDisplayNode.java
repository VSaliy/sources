/*-- 

 Copyright (C) 2001 Brett McLaughlin.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "Java and XML" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact brett@newInstance.com.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed for the
      'Java and XML' book, by Brett McLaughlin (O'Reilly & Associates)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE JDOM AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */
package javaxml2;

import java.util.Vector;
import java.util.List;
import java.util.Iterator;
import java.util.Stack;

// JDOM imports
import org.jdom.Attribute;
import org.jdom.Element;
import org.jdom.Namespace;

/**
 * <code><b>XPathDisplayNode</b></code> is a wrapper for 
 *   <code>{@link JDOMNode}</code>s to display the XPath path
 *   to the decorated node.
 */
public class XPathDisplayNode {

    /** The JDOMNode this xpath is based on */
    JDOMNode node;
	
    /**
     * <p>Constructor to wrap a node.</p> 
     * 
     * @param node <code>{@link JDOMNode}</code> to wrap.
     */
    public XPathDisplayNode(JDOMNode node) {
        this.node = node;
    }

    /**
     * <p>This creates an XPath expression representing this element node
     *   relative to the supplied <code>currentNode</code>.</p>
     * 
     * @param currentNode <code>JDOMNode</code> representing "start"
     *        location.
     * @return <code>String</code> - the XPath expression
     */
    private String getElementXPath(JDOMNode currentNode) {
        StringBuffer buf = new StringBuffer("/")
            .append(currentNode.getQName());
        Element current = (Element)currentNode.getNode();
        Element parent = current.getParent();

        // See if we're at the root element
        if (parent == null ) {
            return buf.toString();
        }

        // Check for other siblings of the same name and namespace
        Namespace ns = current.getNamespace();
        List siblings = parent.getChildren(current.getName(), ns);
		
        int total = 0;
        Iterator i = siblings.iterator();
        while (i.hasNext()) {
            total++;
            if (current == i.next()) {
                break;
            }
        }

        // No selector needed if this is the only element
        if ((total == 1) && (!i.hasNext())) {
            return buf.toString();
        }

        return buf.append("[")
                  .append(String.valueOf(total))
                  .append("]").toString();
    }

    /**
     * <p>This returns the complete XPath expression for this
     *  node.</p>
     * 
     * @return <code>String</code> - complete XPath.
     */
    public String getXPath() {
        // Handle elements
        if (node.getNode() instanceof Element) {
            JDOMNode parent = node.getParentNode();

            // If this is null, we're at the root
            if (parent == null) {
                return "/" + node.getQName();
            }

            // Otherwise, build a path back to the root
            Stack stack = new Stack();
            stack.add(node);
            do {
                stack.add(parent);
                parent = parent.getParentNode();
            } while (parent != null);

            // Build the path
            StringBuffer xpath = new StringBuffer();
            while (!stack.isEmpty()) {
                xpath.append(getElementXPath((JDOMNode)stack.pop()));
            }
            return xpath.toString();
        }	
		
        // Handle attributes
        if (node.getNode() instanceof Attribute) {
            Attribute attribute = (Attribute)node.getNode();
            JDOMNode parent = node.getParentNode();
            StringBuffer xpath = new StringBuffer("//")
                .append(parent.getQName())
                .append("[@")
                .append(node.getQName())
                .append("='")
                .append(attribute.getValue())
                .append("']");

            return xpath.toString();
        }

        // Handle text
        if (node.getNode() instanceof String) {
            StringBuffer xpath = new StringBuffer(
                new XPathDisplayNode(node.getParentNode()).getXPath())
                    .append("[child::text()]");
            return xpath.toString();
        }
					
        // Other node types could follow here
        return "Node type not supported yet.";
    }
}
