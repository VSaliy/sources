/*-- 

 Copyright (C) 2001 Brett McLaughlin.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "Java and XML" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact brett@newInstance.com.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed for the
      'Java and XML' book, by Brett McLaughlin (O'Reilly & Associates)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE JDOM AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */
package javaxml2;

import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;
import org.apache.soap.Constants;
import org.apache.soap.Fault;
import org.apache.soap.SOAPException;
import org.apache.soap.encoding.SOAPMappingRegistry;
import org.apache.soap.encoding.soapenc.BeanSerializer;
import org.apache.soap.rpc.Call;
import org.apache.soap.rpc.Parameter;
import org.apache.soap.rpc.Response;
import org.apache.soap.util.xml.QName;

/**
 * <p>
 *  <code>CDLister</code> is a web services client. It connects
 *    to the <i>cd-catalog-demo</i> service and lists the currently
 *    available CDs.
 * </p>
 */
public class CDLister {

    /**
     * <p>
     *  This will connect to the provided <code>URL</code> and attempt
     *    to use the <i>cd-catalog-demo</i> web service to get a listing
     *    of currently available CDs. It then outputs that list to
     *    <code>System.out</code>.
     * </p>
     *
     * @param url <code>URL</code> where web service is running.
     * @throws <code>SOAPException</code> - when errors in accessing
     *         the web service occur.
     */
    public void list(URL url) throws SOAPException {
        System.out.println("Listing current CD catalog.");

        // Map the CD type so SOAP can use it
        SOAPMappingRegistry registry = new SOAPMappingRegistry();
        BeanSerializer serializer = new BeanSerializer();
        registry.mapTypes(Constants.NS_URI_SOAP_ENC,
            new QName("urn:cd-catalog-demo", "cd"),
            CD.class, serializer, serializer);   

        // Build the Call object
        Call call = new Call();
        call.setSOAPMappingRegistry(registry);
        call.setTargetObjectURI("urn:cd-catalog");
        call.setMethodName("list");
        call.setEncodingStyleURI(Constants.NS_URI_SOAP_ENC);

        // No parameters needed

        // Invoke the call
        Response response;
        response = call.invoke(url, "");

        if (!response.generatedFault()) {
            Parameter returnValue = response.getReturnValue();
            Hashtable catalog = (Hashtable)returnValue.getValue();
            Enumeration e = catalog.keys();
            while (e.hasMoreElements()) {
                String title = (String)e.nextElement();
                CD cd = (CD)catalog.get(title);
                System.out.println("  '" + cd.getTitle() + "' by " + cd.getArtist() +
                    " on the label " + cd.getLabel());
            }
        } else {
            Fault fault = response.getFault();
            System.out.println("Error encountered: " + fault.getFaultString());

            Vector entries = fault.getDetailEntries();
            for (Iterator i = entries.iterator(); i.hasNext(); ) {
                org.w3c.dom.Element entry = (org.w3c.dom.Element)i.next();
                System.out.println(entry.getFirstChild().getNodeValue());
            }
        }
    }

    /**
     * <p>Provide a static entry point.</p>
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java javaxml2.CDAdder [SOAP server URL]");
            return;
        }

        try {
            // URL for SOAP server to connect to
            URL url = new URL(args[0]);

            // List the current CDs
            CDLister lister = new CDLister();
            lister.list(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}