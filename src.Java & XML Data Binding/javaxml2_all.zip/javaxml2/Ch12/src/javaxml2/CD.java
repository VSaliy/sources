/*-- 

 Copyright (C) 2001 Brett McLaughlin.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "Java and XML" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact brett@newInstance.com.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed for the
      'Java and XML' book, by Brett McLaughlin (O'Reilly & Associates)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE JDOM AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */
package javaxml2;

/**
 * <p>
 *  <code>CD</code> is an object representation of a musical CD.
 * </p>
 */
public class CD {

    /** The title of this CD */
    private String title;

    /** The artist performing on the CD */
    private String artist;

    /** The label of the CD */
    private String label;

    /**
     * <p>Default constructor.</p>
     */
    public CD() {
        // Default constructor
    }

    /**
     * <p>
     *  This creates a new CD with the supplied title, artist, and
     *    label.
     * </p>
     *
     * @param title the title of the CD.
     * @param the CD's musical artist.
     * @param the label the CD is put out on.
     */
    public CD(String title, String artist, String label) {
        this.title = title;
        this.artist = artist;
        this.label = label;
    }

    /** 
     * <p> This returns the title of this CD.</p>
     *
     * @return <code>String</code> - the title of the CD.
     */
    public String getTitle() { 
        return title;
    }

    /**
     * <p>This will set the title of this CD.</p>
     *
     * @param title the title for the CD.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * <p>This returns the musical artist for this CD.</p>
     *
     * @return <code>String</code> - the artist of this CD.
     */
    public String getArtist() {
        return artist;
    }

    /**
     * <p>This will set the artist for this CD.</p>
     *
     * @param artist the artist for this CD.
     */
    public void setArtist(String artist) {
        this.artist = artist;
    }

    /**
     * <p>This returns the label for this CD.</p>
     *
     * @return <code>String</code> - this CD's label.
     */
    public String getLabel() {
        return label;
    }
 
    /**
     * <p>This will set the label of this CD.</p>
     *
     * @param label the label for this CD.
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * <p>This overrides the default behavior of <code>toString()</code>
     *   and provides the basic information about this CD instance.</p>
     *
     * @return <code>String</code> - textual representation of this CD.
     */
    public String toString() {
        return "'" + title + "' by " + artist + ", on " +
            label;
    }
}